"""Точка входа для Android (python-for-android / buildozer ищет main.py в корне).
На ПК по-прежнему запускай run.py или start.py."""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

import pygame

pygame.init()
try:
    info = pygame.display.Info()
    w, h = max(info.current_w, info.current_h), min(info.current_w, info.current_h)
    if w > 0 and h > 0:
        # Высота кадра фиксирована (700), ширина — по пропорциям экрана телефона
        os.environ["ZV_WIDTH"] = str(max(1000, min(1560, round(700 * w / h))))
except Exception:
    pass

from game.main import run  # noqa: E402

run()
