import math
import pygame

class Bullet:
    def __init__(self, x, y, angle, speed, damage, pierce, color, is_enemy=False):
        self.x = x
        self.y = y
        self.start_x = x
        self.start_y = y
        self.vx = math.cos(angle) * speed
        self.vy = math.sin(angle) * speed
        self.damage = damage
        self.pierce = pierce
        self.color = color
        self.is_enemy = is_enemy
        self.life = 1.0
        self.radius = 3
        self.hit_targets = set()
        self.walls_hit = set()

    def update(self, dt):
        self.x += self.vx * dt
        self.y += self.vy * dt
        self.life -= dt
        return self.life > 0

    def draw(self, surf, cam_x, cam_y):
        x = int(self.x - cam_x)
        y = int(self.y - cam_y)
        
        length = 16 if not self.is_enemy else 12
        angle = math.atan2(self.vy, self.vx)
        ex = int(x - math.cos(angle) * length)
        ey = int(y - math.sin(angle) * length)
        
        base_color = (176, 138, 78) if not self.is_enemy else (170, 72, 62)
        pygame.draw.line(surf, base_color, (x, y), (ex, ey), 2)
        pygame.draw.line(surf, (226, 200, 150), (x, y), (int(x - math.cos(angle) * 5), int(y - math.sin(angle) * 5)), 1)
