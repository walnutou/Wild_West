import sys
import pygame
from .config import WIDTH, HEIGHT, FPS, SAND, MOBILE, TOUCH
from .game import Game


def run():
    pygame.init()
    flags = pygame.DOUBLEBUF
    if MOBILE:
        # Телефон: SDL сам масштабирует логический кадр на весь экран
        flags = pygame.SCALED | pygame.FULLSCREEN
    screen = pygame.display.set_mode((WIDTH, HEIGHT), flags)
    screen.fill(SAND)
    pygame.display.flip()
    pygame.display.set_caption("Дикий Запад: Кровавый Вихрь")
    clock = pygame.time.Clock()
    game = Game()

    while True:
        dt = min(clock.tick(FPS) / 1000.0, 0.05)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            game.handle_event(event)

        # Курсор нужен в меню, в бою его заменяет прицел
        pygame.mouse.set_visible(not TOUCH and (game.state != "playing" or game.admin_open))
        game.update(dt)
        game.draw(screen)
        pygame.display.flip()
