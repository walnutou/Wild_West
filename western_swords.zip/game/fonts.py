import pygame
from pathlib import Path

_SIZES = {"sm": 16, "md": 22, "lg": 32, "xl": 52, "xxl": 76}
_cache = {}
_TTF = Path(__file__).resolve().parent.parent / "assets" / "fonts" / "DejaVuSans-Bold.ttf"


def get(name):
    """Шрифт лежит в assets/fonts — на Android системных шрифтов нет."""
    if name not in _cache:
        size = _SIZES[name]
        font = None
        if _TTF.exists():
            try:
                font = pygame.font.Font(str(_TTF), size)
            except Exception:
                font = None
        if font is None:
            try:
                font = pygame.font.SysFont("dejavusans,liberationsans,ubuntu,arial", size, bold=True)
            except Exception:
                font = pygame.font.Font(None, size + 6)
        _cache[name] = font
    return _cache[name]
