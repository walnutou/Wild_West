"""Атмосфера ужаса: тьма с фонарём, туман, виньетка, гроза, сердцебиение, дыхание,
шорохи и вой вдалеке. Всё процедурное, без внешних картинок."""
import math
import random
import pygame
from .config import WIDTH, HEIGHT, MOBILE
from . import sounds


def _soft_blob(r, rgb, a_max):
    s = pygame.Surface((r * 2, r * 2), pygame.SRCALPHA)
    for rr in range(r, 0, -2):
        a = int(a_max * (1 - rr / r) ** 1.5)
        pygame.draw.circle(s, (*rgb, a), (r, r), rr)
    return s


def _make_fog(size=512):
    tile = pygame.Surface((size, size), pygame.SRCALPHA)
    blobs = [_soft_blob(r, (150, 160, 184), 38) for r in (50, 70, 90, 110)]
    for _ in range(60):
        b = random.choice(blobs)
        x, y = random.randint(0, size), random.randint(0, size)
        for ox in (-size, 0, size):
            for oy in (-size, 0, size):
                tile.blit(b, (x + ox - b.get_width() // 2, y + oy - b.get_height() // 2))
    return tile


def _make_vignette(rgb, strength):
    w, h = 64, 44
    small = pygame.Surface((w, h), pygame.SRCALPHA)
    for yy in range(h):
        for xx in range(w):
            nx, ny = (xx + 0.5) / w * 2 - 1, (yy + 0.5) / h * 2 - 1
            r = math.hypot(nx * 0.95, ny * 1.15)
            a = max(0.0, min(1.0, (r - 0.45) / 0.85)) ** 1.5
            small.set_at((xx, yy), (*rgb, int(strength * a)))
    return pygame.transform.smoothscale(small, (WIDTH, HEIGHT))


def _make_cone(length, half_angle, strength):
    L = length
    mask = pygame.Surface((2 * L, 2 * L), pygame.SRCALPHA)
    layers = 14
    for i in range(layers):
        t = i / (layers - 1)
        h = half_angle * (1.0 - 0.62 * t)
        ln = L * (0.55 + 0.45 * (1 - t) ** 0.6)
        pts = [(L, L)]
        for k in range(13):
            a = -h + 2 * h * k / 12
            pts.append((L + math.cos(a) * ln, L + math.sin(a) * ln))
        tmp = pygame.Surface((2 * L, 2 * L), pygame.SRCALPHA)
        pygame.draw.polygon(tmp, (0, 0, 0, int(strength / layers * 1.35)), pts)
        mask.blit(tmp, (0, 0), special_flags=pygame.BLEND_RGBA_ADD)
    small = pygame.transform.smoothscale(mask, (L // 2, L // 2))
    return pygame.transform.smoothscale(small, (2 * L, 2 * L))


class Atmosphere:
    def __init__(self):
        self.t = 0.0
        self.fog = _make_fog()
        self.vig = _make_vignette((0, 0, 0), 235)
        self.vig_red = _make_vignette((150, 0, 0), 255)
        L = 380
        self.cones = [_make_cone(L, 0.42, 255), _make_cone(L, 0.42, 190), _make_cone(L, 0.40, 120)]
        self.cone_L = L
        self.cone_level = 0
        self.flick_t = random.uniform(2, 6)
        self.flick_left = 0.0
        self.flash = 0.0
        self.flash2 = 0.0
        self.lightning_timer = random.uniform(25, 60)
        self.thunder_delay = None
        self.stinger_timer = random.uniform(30, 70)
        self.howl_timer = random.uniform(25, 60)
        self.heart_timer = 0.0
        self.heart_pulse = 0.0
        self.breath_timer = 0.0
        self.danger = 0.0
        self.low_hp = 0.0
        self.last_hp = None
        self.prev_spin = 0.0
        self.dark = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)

    # ------------------------------------------------------------ логика
    def update(self, game, dt):
        self.t += dt
        p = game.player
        if self.last_hp is None:
            self.last_hp = p.hp

        # фонарь иногда мигает, когда рядом зомби
        self.flick_t -= dt
        if self.flick_t <= 0:
            self.flick_left = random.uniform(0.05, 0.28)
            self.flick_t = random.uniform(2.0, 7.0) / (1.0 + 2.0 * self.danger)
        if self.flick_left > 0:
            self.flick_left -= dt
            self.cone_level = random.choice((1, 2, 2, 0))
        else:
            self.cone_level = 0

        # гроза
        self.lightning_timer -= dt
        if self.lightning_timer <= 0:
            self.lightning_timer = random.uniform(35, 90)
            self.flash = 1.0
            self.flash2 = 0.0
            self._flash2_in = random.uniform(0.12, 0.22)
            self.thunder_delay = random.uniform(0.5, 3.5)
        self.flash = max(0.0, self.flash - dt * 3.5)
        if getattr(self, "_flash2_in", None) is not None:
            self._flash2_in -= dt
            if self._flash2_in <= 0:
                self.flash2 = 0.7
                self.flash = max(self.flash, 0.7)
                self._flash2_in = None
        if self.thunder_delay is not None:
            self.thunder_delay -= dt
            if self.thunder_delay <= 0:
                sounds.play("thunder", 0.85, random.uniform(-0.5, 0.5))
                game.shake = max(game.shake, 0.1)
                self.thunder_delay = None

        # редкие жуткие звуки
        self.stinger_timer -= dt
        if self.stinger_timer <= 0:
            self.stinger_timer = random.uniform(40, 90)
            sounds.play("stinger", 0.5, random.uniform(-0.8, 0.8))
        self.howl_timer -= dt
        if self.howl_timer <= 0:
            self.howl_timer = random.uniform(30, 75)
            sounds.play("howl", 0.4, random.uniform(-0.9, 0.9))

        # опасность: ближайший зомби и здоровье
        dmin = 99999.0
        for z in game.zombies:
            d = abs(z.x - p.x) + abs(z.y - p.y)
            if d < dmin:
                dmin = d
        self.danger = max(0.0, min(1.0, 1.0 - dmin * 0.8 / 700.0))
        self.low_hp = max(0.0, 1.0 - p.hp / p.max_hp) ** 1.4

        inten = min(1.0, self.danger * 0.85 + self.low_hp * 0.9)
        self.heart_pulse = max(0.0, self.heart_pulse - dt * 3.0)
        if inten > 0.12:
            self.heart_timer -= dt
            if self.heart_timer <= 0:
                self.heart_timer = 60.0 / (58 + 95 * inten)
                self.heart_pulse = 1.0
                sounds.play("heartbeat", 0.3 + 0.6 * inten)
        if p.exhausted or (p.stamina < 25):
            self.breath_timer -= dt
            if self.breath_timer <= 0:
                self.breath_timer = 1.7
                sounds.play("breath", 0.55)
        if p.hp < self.last_hp - 14:
            sounds.play("tinnitus", 0.3)
        self.last_hp = p.hp

        # петли: ветер, дрон, бензопила
        gust = 0.6 + 0.4 * math.sin(game.wind_t * 0.35) + 0.2 * math.sin(game.wind_t * 1.1)
        sounds.set_loop(0, 0.22 + 0.2 * gust)
        sounds.set_loop(1, 0.18 + 0.35 * self.danger + 0.2 * self.low_hp)
        spin = p.chainsaw_spin if p.active_melee == "chainsaw" else 0.0
        if spin > 0.02 and self.prev_spin <= 0.02:
            sounds.play("saw_start", 0.7)
        self.prev_spin = spin
        sounds.set_loop(2, 0.4 if 0.02 < spin < 0.9 else 0.0)
        sounds.set_loop(3, 0.65 * spin if spin >= 0.9 else 0.3 * spin)

    def update_menu(self, game, dt):
        """Фон главного меню: гроза, ветер, далёкие звуки."""
        self.t += dt
        self.lightning_timer -= dt
        if self.lightning_timer <= 0:
            self.lightning_timer = random.uniform(10, 22)
            self.flash = 1.0
            self._flash2_in = random.uniform(0.12, 0.22)
            self.thunder_delay = random.uniform(0.4, 2.0)
        self.flash = max(0.0, self.flash - dt * 3.5)
        if getattr(self, "_flash2_in", None) is not None:
            self._flash2_in -= dt
            if self._flash2_in <= 0:
                self.flash = max(self.flash, 0.7)
                self._flash2_in = None
        if self.thunder_delay is not None:
            self.thunder_delay -= dt
            if self.thunder_delay <= 0:
                sounds.play("thunder", 0.8, random.uniform(-0.5, 0.5))
                self.thunder_delay = None
        self.howl_timer -= dt
        if self.howl_timer <= 0:
            self.howl_timer = random.uniform(18, 40)
            sounds.play("howl", 0.4, random.uniform(-0.9, 0.9))
        self.heart_pulse = 0.0
        self.danger = 0.2
        self.low_hp = 0.0
        sounds.set_loop(0, 0.38)
        sounds.set_loop(1, 0.32)
        sounds.set_loop(2, 0.0)
        sounds.set_loop(3, 0.0)

    def draw_menu(self, surf, game, cx, cy):
        dark = self.dark
        dark.fill((6, 6, 18, int(214 * (1.0 - 0.75 * self.flash))))
        for b in game.solid_buildings:
            rad = int(150 * (0.9 + 0.1 * math.sin(self.t * 6 + b["x"])))
            sx, sy = int(b["x"] - cx), int(b["y"] + b["h"] / 2 - cy)
            m = game._light_mask(rad)
            dark.blit(m, (sx - rad, sy - rad), special_flags=pygame.BLEND_RGBA_SUB)
        # фонари на улице
        for lx in (1700, 2000, 2300):
            rad = int(170 * (0.92 + 0.08 * math.sin(self.t * 9 + lx)))
            m = game._light_mask(rad)
            dark.blit(m, (int(lx - cx) - rad, int(1740 - cy) - rad), special_flags=pygame.BLEND_RGBA_SUB)
        surf.blit(dark, (0, 0))

    # ------------------------------------------------------------ рисование
    def draw_fog(self, surf, cx, cy):
        if MOBILE:
            return
        size = self.fog.get_width()
        for k, (par, sp) in enumerate(((0.55, (10, 3)), (0.8, (-16, 5)))):
            ox = int(-(cx * par + self.t * sp[0]) % size)
            oy = int(-(cy * par + self.t * sp[1]) % size)
            x = ox - size
            while x < WIDTH:
                y = oy - size
                while y < HEIGHT:
                    surf.blit(self.fog, (x, y))
                    y += size
                x += size

    def draw_lighting(self, surf, game, cx, cy):
        dark = self.dark
        cfg = game.cfg
        dawn = min(1.0, game.dawn_t / cfg["goal_time"]) if game.mode == "dawn" else 0.0
        base_a = int(cfg["dark"] * (1.0 - 0.55 * dawn) * (1.0 - 0.8 * max(self.flash, 0.0)))
        dark.fill((6, 6, 18, base_a))

        def light(wx, wy, rad):
            sx, sy = int(wx - cx), int(wy - cy)
            if sx < -rad or sy < -rad or sx > WIDTH + rad or sy > HEIGHT + rad:
                return
            m = game._light_mask(rad)
            dark.blit(m, (sx - rad, sy - rad), special_flags=pygame.BLEND_RGBA_SUB)

        p = game.player
        mx, my = game.aim_screen()
        aim = math.atan2(my + game.camera.y - p.y, mx + game.camera.x - p.x)
        flick = 1.0 + 0.04 * math.sin(self.t * 23.0) + random.uniform(-0.02, 0.02)
        lit = cfg["flash"] and game.flash_on
        light(p.x, p.y, int((135 if lit else 78) * flick))
        # фонарь: конус света вперёд (в «Кошмаре» фонаря нет)
        if lit:
            cone = self.cones[self.cone_level]
            rot = pygame.transform.rotate(cone, -math.degrees(aim))
            dark.blit(rot, (int(p.x - cx) - rot.get_width() // 2, int(p.y - cy) - rot.get_height() // 2),
                      special_flags=pygame.BLEND_RGBA_SUB)
        if p.muzzle_flash > 0:
            light(p.x + math.cos(aim) * 60, p.y + math.sin(aim) * 60, 220)
        from . import decor
        for b in game.solid_buildings:
            light(b["x"], b["y"] + b["h"] / 2, int(105 * (0.9 + 0.1 * math.sin(self.t * 7 + b["x"]))))
            if decor.inside_building(p.x, p.y, b):
                light(b["x"], b["y"], 230)
        for f in game.hit_flashes:
            light(f["x"], f["y"], 26 + 34 * (f["life"] / f["max"]))
        surf.blit(dark, (0, 0))

    def draw_post(self, surf, game, menu=False):
        surf.blit(self.vig, (0, 0))
        if menu:
            if self.flash > 0.02:
                ov = pygame.Surface((WIDTH, HEIGHT))
                ov.fill((170, 190, 255))
                ov.set_alpha(int(110 * self.flash))
                surf.blit(ov, (0, 0))
            return
        if game.mode == "dawn":
            prog = min(1.0, game.dawn_t / game.cfg["goal_time"])
            if prog > 0.55:
                ov = pygame.Surface((WIDTH, HEIGHT))
                ov.fill((255, 150, 70))
                ov.set_alpha(int(80 * ((prog - 0.55) / 0.45) ** 1.5))
                surf.blit(ov, (0, 0))
        red = min(1.0, self.low_hp * 0.8 + self.heart_pulse * (self.danger * 0.5 + self.low_hp * 0.5))
        if red > 0.02:
            self.vig_red.set_alpha(int(140 * red))
            surf.blit(self.vig_red, (0, 0))
        if self.flash > 0.02:
            ov = pygame.Surface((WIDTH, HEIGHT))
            ov.fill((170, 190, 255))
            ov.set_alpha(int(110 * self.flash))
            surf.blit(ov, (0, 0))
