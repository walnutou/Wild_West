import os
# Телефон: логическая высота 700, ширина подстраивается под экран (ZV_WIDTH задаёт main.py)
WIDTH, HEIGHT = int(os.environ.get("ZV_WIDTH", 1000)), 700
# Мобильный режим: сенсорное управление и облегчённая графика
MOBILE = ("ANDROID_ARGUMENT" in os.environ) or os.environ.get("ZV_MOBILE") == "1"
TOUCH = MOBILE or os.environ.get("ZV_TOUCH") == "1"
WORLD_W, WORLD_H = 4000, 4000
FPS = 60

SAND   = (206, 172, 116)
SAND_D = (184, 150,  96)
WOOD   = (122,  84,  54)
WOOD_L = (146, 104,  68)
CACT   = ( 74, 122,  64)

PLAYER_SPEED  = 280.0
PLAYER_RADIUS = 15
PLAYER_MAX_HP = 150

WEAPONS = {
    "pistol":  {"name": "Пистолет",  "mag": 5,  "reload": 1.3, "dmg": 30,  "rate": 0.4, "speed": 800,  "spread": 0.0,  "count": 1, "pierce": 0, "color": (255, 220, 100)},
    "revolver":{"name": "Револьвер", "mag": 6,  "reload": 2.2, "dmg": 75,  "rate": 0.9, "speed": 1000, "spread": 0.02, "count": 1, "pierce": 1, "color": (255, 180, 50)},
    "smg":     {"name": "Калашников", "mag": 30, "reload": 2.4, "dmg": 30,  "rate": 0.1, "speed": 900,  "spread": 0.05, "count": 1, "pierce": 0, "color": (255, 150, 50)},
    "shotgun": {"name": "Дробовик",  "mag": 6,  "reload": 2.6, "dmg": 45,  "rate": 0.8, "speed": 700,  "spread": 0.15,  "count": 5, "pierce": 0, "color": (200, 100, 50)},
    "sawnoff": {"name": "Обрез",     "mag": 2,  "reload": 1.6, "dmg": 45,  "rate": 0.6, "speed": 600,  "spread": 0.2,  "count": 4, "pierce": 0, "color": (150, 100, 50)},
    "sniper":  {"name": "Снайперка", "mag": 5,  "reload": 2.6, "dmg": 90,  "rate": 1.5, "speed": 1500, "spread": 0.0,  "count": 1, "pierce": 4, "color": (100, 255, 100)},
}

MELEE_WEAPONS = {
    "chainsaw": {"name": "Бензопила", "dmg": 150, "rate": 0.15, "range": 75, "dismember": True, "color": (200, 50, 50)},
    "machete":  {"name": "Мачете",    "dmg": 80,  "rate": 0.35, "range": 80, "dismember": True, "color": (200, 200, 200)},
    "axe":      {"name": "Топор",     "dmg": 100, "rate": 0.5, "range": 70, "dismember": True, "color": (150, 100, 50)},
    "knife":    {"name": "Нож",       "dmg": 40,  "rate": 0.25, "range": 55, "dismember": False, "color": (150, 150, 150)},
    "bat":      {"name": "Дубина",    "dmg": 60,  "rate": 0.45, "range": 80, "dismember": False, "color": (139, 69, 19)},
    "crowbar":  {"name": "Лом",       "dmg": 50,  "rate": 0.4, "range": 75, "dismember": False, "color": (100, 100, 100)}
}

XP_START_NEEDED = 4
XP_GROWTH       = 1.25


# Удар ногой — когда в руках нет оружия ближнего боя. Тратит выносливость.
KICK = {"name": "Пинок", "dmg": 18, "range": 54, "rate": 0.55, "dismember": False,
        "cost": 18.0, "door": 1}
