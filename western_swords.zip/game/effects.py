import math, random, pygame
from pathlib import Path

_FOOTPRINT_RIGHT = None
_FOOTPRINT_LEFT = None

def _load_footprint():
    global _FOOTPRINT_RIGHT, _FOOTPRINT_LEFT
    if _FOOTPRINT_RIGHT is None:
        # Создаем холст высокого разрешения для сглаживания
        surf = pygame.Surface((32, 64), pygame.SRCALPHA)
        color = (140, 0, 0) # Насыщенный красный
        
        # Подошва (носок)
        pygame.draw.ellipse(surf, color, (4, 0, 24, 40))
        # Пятка
        pygame.draw.ellipse(surf, color, (8, 40, 16, 24))
        
        # Протектор (темные полоски)
        tread = (90, 0, 0)
        pygame.draw.line(surf, tread, (6, 10), (26, 10), 2)
        pygame.draw.line(surf, tread, (4, 18), (28, 18), 2)
        pygame.draw.line(surf, tread, (6, 26), (26, 26), 2)
        pygame.draw.line(surf, tread, (10, 48), (22, 48), 2)
        pygame.draw.line(surf, tread, (10, 54), (22, 54), 2)

        # Плавно уменьшаем до 10x20 (убирает пиксельность)
        scaled = pygame.transform.smoothscale(surf, (10, 20))
        _FOOTPRINT_RIGHT = scaled
        _FOOTPRINT_LEFT = pygame.transform.flip(scaled, True, False)
        print("[debug] Созданы идеальные красные следы кодом.")

_POOL_CACHE = {}


def _pool_surface(level):
    """Лужа крови под оторванной частью; level 1..10 — насколько разлилась."""
    s = _POOL_CACHE.get(level)
    if s is None:
        rx, ry = 3 + level * 1.0, 2 + level * 0.7
        w, h = int(rx * 2 + 8), int(ry * 2 + 8)
        big = pygame.Surface((w * 2, h * 2), pygame.SRCALPHA)
        rnd = random.Random(level * 97)
        n = 26
        pts = []
        for i in range(n):
            a = i * math.tau / n
            k = rnd.uniform(0.82, 1.1)
            pts.append((w + math.cos(a) * rx * 2 * k, h + math.sin(a) * ry * 2 * k))
        pygame.draw.polygon(big, (72, 4, 6, 190), pts)
        inner = [(w + (px - w) * 0.66, h + (py - h) * 0.66) for px, py in pts]
        pygame.draw.polygon(big, (108, 8, 10, 170), inner)
        pygame.draw.ellipse(big, (176, 44, 44, 80), (w * 0.62, h * 0.55, w * 0.4, h * 0.3))
        # размываем контур: вниз и обратно — края перестают быть «многоугольником»
        small = pygame.transform.smoothscale(big, (max(2, w // 2), max(2, h // 2)))
        s = pygame.transform.smoothscale(small, (w, h))
        _POOL_CACHE[level] = s
    return s


def _ragged(cx, cy, rx, ry, n, rnd, jag=0.28):
    pts = []
    for i in range(n):
        a = i * math.tau / n
        k = 1.0 + rnd.uniform(-jag, jag)
        pts.append((cx + math.cos(a) * rx * k, cy + math.sin(a) * ry * k))
    return pts


def _mix(a, b, t):
    return tuple(int(a[i] * (1 - t) + b[i] * t) for i in range(3))


class Limb:
    """Оторванная часть тела: тёмная мёртвая плоть, рваный срез с мясом и костью,
    лужа крови, которая растекается, когда часть упала."""
    SZ = 64
    SCALE = 0.6          # размер относительно зомби: рука не больше настоящей руки

    def __init__(self, x, y, kind, color, soft=True, angle=None, size=1.0):
        """soft — часть просто падает рядом (удар клинком/пилой), а не разлетается."""
        self.x = x
        self.y = y
        self.z = 10 if soft else 20
        ang = angle if angle is not None else random.uniform(0, math.tau)
        if soft:
            speed = random.uniform(25, 85)
            self.vz = random.uniform(55, 120)
            self.spin = random.uniform(-3.5, 3.5)
        else:
            speed = random.uniform(150, 400)
            self.vz = random.uniform(100, 300)
            self.spin = random.uniform(-15, 15)
        self.vx = math.cos(ang) * speed
        self.vy = math.sin(ang) * speed
        self.life = random.uniform(14.0, 24.0)
        self.angle = random.uniform(0, math.tau)
        self.kind = kind
        self.color = color
        self.size = size
        self.pool = 0.0
        self.ground = kind == "organ"          # орган лежит в луже, не скользит
        self.trail = []
        self._trail_t = 0.0
        self._spr = None
        self._seed = random.randint(0, 99999)

    def update(self, dt):
        self.x += self.vx * dt
        self.y += self.vy * dt
        self.z += self.vz * dt
        self.vz -= 600 * dt
        if self.z < 0:
            self.z = 0
            self.vz *= -0.35
            if abs(self.vz) < 40:
                self.vz = 0
            self.vx *= 0.55
            self.vy *= 0.55
            self.spin *= 0.6
        if self.z > 0:
            # в полёте оставляет кровавые брызги на земле
            self._trail_t -= dt
            if self._trail_t <= 0 and len(self.trail) < 16:
                self._trail_t = 0.035
                self.trail.append((self.x + random.uniform(-3, 3), self.y + random.uniform(-3, 3),
                                   random.uniform(1.2, 3.0)))
        else:
            fr = max(0.0, 1.0 - 6.0 * dt)       # по земле не скользит бесконечно
            self.vx *= fr
            self.vy *= fr
            self.spin *= fr
            if math.hypot(self.vx, self.vy) < 25:
                self.pool = min(1.0, self.pool + dt * 0.45)
        self.angle += self.spin * dt
        self.life -= dt

    # ---------------------------------------------------------------- спрайт
    def _build(self):
        S = self.SZ
        s = pygame.Surface((S, S), pygame.SRCALPHA)
        rnd = random.Random(self._seed)
        c = S // 2
        base = self.color[:3]
        # мёртвая плоть: приглушённая, сероватая, без «неоновых» цветов
        flesh = _mix(base, (122, 100, 86), 0.55)
        flesh_d = tuple(int(v * 0.52) for v in flesh)
        flesh_l = tuple(min(255, int(v * 1.14)) for v in flesh)
        meat = (122, 14, 16)
        meat_d = (66, 5, 7)
        meat_l = (168, 36, 38)
        bone = (214, 204, 182)
        bone_d = (150, 140, 120)
        cloth_s = (60, 48, 36)       # рукав
        cloth_p = (44, 48, 70)       # штанина

        def stump(cx, cy, r):
            """Рваный срез: тёмное мясо, светлое мышечное кольцо, торчащая кость."""
            s_pts = _ragged(cx, cy, r, r * 1.05, 11, rnd, 0.3)
            pygame.draw.polygon(s, meat_d, s_pts)
            inner = [(cx + (p[0] - cx) * 0.72, cy + (p[1] - cy) * 0.72) for p in s_pts]
            pygame.draw.polygon(s, meat, inner)
            core = [(cx + (p[0] - cx) * 0.4, cy + (p[1] - cy) * 0.4) for p in s_pts]
            pygame.draw.polygon(s, meat_l, core)
            pygame.draw.circle(s, bone, (int(cx - 1), int(cy)), max(2, int(r * 0.33)))
            pygame.draw.circle(s, bone_d, (int(cx - 1), int(cy)), max(2, int(r * 0.33)), 1)
            # обрывки мяса и жил
            for _ in range(4):
                a = rnd.uniform(math.pi * 0.55, math.pi * 1.45)
                ln = rnd.uniform(3, 6)
                pygame.draw.line(s, meat_d, (cx, cy), (cx + math.cos(a) * (r + ln), cy + math.sin(a) * (r + ln)), 1)

        def torn_edge(x0, y0, h, col, dark):
            """Рваный край ткани вдоль среза."""
            pts = [(x0, y0 - h)]
            n = 6
            for i in range(n + 1):
                pts.append((x0 + rnd.uniform(-3, 4), y0 - h + (2 * h) * i / n))
            pygame.draw.polygon(s, col, pts)
            pygame.draw.lines(s, dark, False, pts[1:], 1)

        def drip(x0, y0, ln):
            pygame.draw.line(s, meat_d, (x0, y0), (x0 + ln, y0 + rnd.uniform(-1, 1)), 2)
            pygame.draw.circle(s, meat, (int(x0 + ln), int(y0)), 2)

        def grime(x0, y0, w, h, n=6):
            for _ in range(n):
                px = x0 + rnd.uniform(0, w)
                py = y0 + rnd.uniform(-h / 2, h / 2)
                pygame.draw.circle(s, _mix(flesh_d, meat_d, 0.5), (int(px), int(py)), rnd.randint(1, 2))

        k = self.kind
        if k == "arm":
            # плечо в рваном рукаве
            pygame.draw.line(s, cloth_s, (c - 12, c), (c + 1, c + 1), 11)
            pygame.draw.line(s, _mix(cloth_s, (90, 76, 58), 0.4), (c - 12, c - 2), (c + 1, c - 1), 4)
            torn_edge(c - 13, c, 6, cloth_s, (28, 22, 16))
            stump(c - 15, c, 5)
            # предплечье и кисть
            pygame.draw.line(s, flesh_d, (c, c + 1), (c + 11, c + 3), 7)
            pygame.draw.line(s, flesh, (c, c), (c + 11, c + 2), 5)
            pygame.draw.line(s, flesh_l, (c + 1, c - 1), (c + 10, c + 1), 1)
            pygame.draw.circle(s, flesh_d, (c + 13, c + 3), 5)
            pygame.draw.circle(s, flesh, (c + 13, c + 3), 4)
            for i in range(4):
                a = -0.55 + i * 0.4
                fx, fy = c + 13 + math.cos(a) * 4, c + 3 + math.sin(a) * 4
                ex, ey = c + 13 + math.cos(a + 0.2) * 9, c + 3 + math.sin(a + 0.2) * 9
                pygame.draw.line(s, flesh_d, (fx, fy), (ex, ey), 2)
                pygame.draw.circle(s, (190, 180, 150), (int(ex), int(ey)), 1)
            grime(c - 4, c, 14, 6)
            pygame.draw.line(s, (90, 10, 12), (c + 4, c - 1), (c + 9, c + 3), 1)
            drip(c - 10, c + 5, 5)
        elif k == "leg":
            pygame.draw.line(s, cloth_p, (c - 12, c), (c + 3, c + 1), 12)
            pygame.draw.line(s, _mix(cloth_p, (80, 84, 110), 0.4), (c - 12, c - 3), (c + 3, c - 2), 4)
            pygame.draw.line(s, (28, 30, 44), (c - 8, c + 4), (c, c + 5), 1)
            torn_edge(c - 14, c, 7, cloth_p, (20, 20, 30))
            stump(c - 16, c, 6)
            # голень и ботинок
            pygame.draw.line(s, _mix(cloth_p, (20, 20, 26), 0.2), (c + 3, c + 1), (c + 11, c + 2), 9)
            pygame.draw.ellipse(s, (44, 28, 18), (c + 9, c - 3, 15, 11))
            pygame.draw.ellipse(s, (22, 14, 9), (c + 9, c - 3, 15, 11), 1)
            pygame.draw.line(s, (14, 9, 6), (c + 12, c + 5), (c + 22, c + 5), 1)
            grime(c - 8, c, 14, 7, 5)
            drip(c - 12, c + 6, 5)
        elif k == "head":
            # шея: рваная плоть, трахея и позвонок
            neck = _ragged(c - 11, c + 1, 6, 6, 10, rnd, 0.32)
            pygame.draw.polygon(s, meat_d, neck)
            pygame.draw.polygon(s, meat, [(c - 11 + (p[0] - c + 11) * 0.7, c + 1 + (p[1] - c - 1) * 0.7) for p in neck])
            pygame.draw.circle(s, (208, 150, 150), (c - 12, c - 1), 2)
            pygame.draw.circle(s, bone, (c - 11, c + 3), 2)
            for _ in range(4):
                a = rnd.uniform(math.pi * 0.6, math.pi * 1.4)
                pygame.draw.line(s, meat_d, (c - 11, c + 1), (c - 11 + math.cos(a) * 11, c + 1 + math.sin(a) * 9), 1)
            # голова
            pygame.draw.ellipse(s, flesh_d, (c - 8, c - 10, 21, 21))
            pygame.draw.ellipse(s, flesh, (c - 7, c - 9, 19, 19))
            pygame.draw.ellipse(s, flesh_l, (c - 4, c - 8, 9, 6))
            # клочья волос
            for _ in range(9):
                a = rnd.uniform(math.pi * 0.5, math.pi * 1.5)
                px, py = c + 1 + math.cos(a) * 8, c + math.sin(a) * 9
                pygame.draw.line(s, (26, 20, 16), (px, py), (px + rnd.uniform(-3, 1), py + rnd.uniform(-3, 3)), 1)
            # мутные глаза и открытый рот
            for ey in (-4, 4):
                pygame.draw.circle(s, (196, 188, 150), (c + 6, c + ey), 3)
                pygame.draw.circle(s, (88, 74, 40), (c + 7, c + ey), 1)
            pygame.draw.ellipse(s, (40, 4, 6), (c + 6, c - 2, 6, 6))
            for i in range(3):
                pygame.draw.line(s, (214, 206, 176), (c + 6 + i * 2, c - 2), (c + 6 + i * 2, c), 1)
            pygame.draw.arc(s, meat_d, (c - 2, c - 7, 9, 9), 0.4, 2.2, 2)
            drip(c - 8, c + 7, 5)
        elif k == "jaw":
            stump(c - 11, c, 4)
            pygame.draw.ellipse(s, flesh_d, (c - 8, c - 7, 20, 13))
            pygame.draw.ellipse(s, flesh, (c - 7, c - 6, 18, 11))
            for i in range(5):
                px = c - 3 + i * 3
                pygame.draw.line(s, (214, 206, 176), (px, c - 3), (px, c + 1), 1)
            pygame.draw.ellipse(s, meat_d, (c - 4, c + 1, 12, 4))
            drip(c - 6, c + 5, 4)
        elif k == "organ":
            v = self._seed % 5
            coat = (60, 4, 6, 70)      # кровь поверх органа — они мокрые и тёмные
            if v == 0:      # печень: тёмный клин с двумя долями, жёлоб посередине
                pts = [(c - 10, c - 2), (c - 6, c - 7), (c + 4, c - 6), (c + 10, c - 1), (c + 7, c + 4),
                       (c, c + 6), (c - 8, c + 4)]
                pygame.draw.polygon(s, (46, 14, 14), pts)
                pygame.draw.polygon(s, (92, 32, 26), [(c + (p[0] - c) * 0.84, c + (p[1] - c) * 0.84) for p in pts])
                pygame.draw.line(s, (50, 16, 14), (c - 2, c - 5), (c + 1, c + 4), 1)
                pygame.draw.ellipse(s, (146, 74, 64), (c - 5, c - 4, 6, 2))
            elif v == 1:    # лёгкое: рыхлая серо-розовая доля с трахеей-бронхом
                pts = _ragged(c, c, 8.5, 6, 11, rnd, 0.12)
                pygame.draw.polygon(s, (84, 48, 56), pts)
                pygame.draw.polygon(s, (134, 88, 96), [(c + (p[0] - c) * 0.82, c + (p[1] - c) * 0.82) for p in pts])
                for q in range(5):
                    pygame.draw.circle(s, (160, 112, 118), (int(c + rnd.uniform(-5, 4)), int(c + rnd.uniform(-3, 3))), 1)
                pygame.draw.line(s, (206, 196, 184), (c + 6, c - 1), (c + 11, c - 4), 2)
                pygame.draw.line(s, (206, 196, 184), (c + 6, c + 1), (c + 11, c + 3), 1)
            elif v == 2:    # сердце: конус с жировой бороздой и обрубками сосудов
                pygame.draw.polygon(s, (60, 8, 12), [(c + 7, c - 1), (c - 1, c - 7), (c - 8, c + 1), (c - 1, c + 6)])
                pygame.draw.polygon(s, (124, 22, 28), [(c + 5, c - 1), (c - 1, c - 5), (c - 6, c + 1), (c - 1, c + 4)])
                pygame.draw.line(s, (196, 160, 100), (c + 3, c - 3), (c - 4, c + 2), 1)
                pygame.draw.line(s, (170, 90, 100), (c + 5, c - 3), (c + 9, c - 7), 2)
                pygame.draw.line(s, (96, 50, 110), (c + 6, c + 0), (c + 10, c + 3), 2)
            elif v == 3:    # желудок: бледный мешок J-образной формы
                pygame.draw.ellipse(s, (96, 58, 54), (c - 9, c - 5, 18, 11))
                pygame.draw.ellipse(s, (160, 112, 104), (c - 8, c - 4, 16, 9))
                pygame.draw.ellipse(s, (196, 150, 140), (c - 5, c - 3, 7, 3))
            else:           # петли кишечника: толстые влажные трубки светло-серо-розового цвета
                for n in range(3):
                    yy = c - 8 + n * 8
                    pts = [(c - 14 + j * 5, yy + math.sin(j * 1.3 + n * 2.1 + self._seed) * 4) for j in range(7)]
                    pygame.draw.lines(s, (92, 46, 50), False, pts, 6)
                    pygame.draw.lines(s, (172, 120, 114), False, pts, 4)
                    pygame.draw.lines(s, (210, 170, 160), False, [(p[0] + 1, p[1] - 1) for p in pts], 1)
            # кровавый налёт
            ov = pygame.Surface((S, S), pygame.SRCALPHA)
            pygame.draw.circle(ov, coat, (c, c), 11)
            s.blit(ov, (0, 0), special_flags=pygame.BLEND_RGBA_MIN if False else 0)
        else:  # chunk / guts: бесформенный кусок мяса, а не аккуратные «трубочки»
            blob = _ragged(c, c, rnd.uniform(6, 9), rnd.uniform(4, 7), 12, rnd, 0.38)
            pygame.draw.polygon(s, meat_d, blob)
            inner = [(c + (p[0] - c) * 0.72, c + (p[1] - c) * 0.72) for p in blob]
            pygame.draw.polygon(s, (118, 22, 26), inner)
            for _ in range(3):
                px, py = c + rnd.uniform(-4, 4), c + rnd.uniform(-3, 3)
                pygame.draw.circle(s, (160, 56, 58), (int(px), int(py)), rnd.randint(1, 2))
            if rnd.random() < 0.5:
                pygame.draw.line(s, (216, 206, 184), (c - 3, c + 1), (c + 2, c - 1), 2)
        sc = self.SCALE * self.size
        return pygame.transform.smoothscale(s, (max(4, int(S * sc)), max(4, int(S * sc))))

    def _visible(self, surf, cx, cy):
        lx = int(self.x - cx)
        gy = int(self.y - cy)
        return -100 < lx < surf.get_width() + 100 and -100 < gy < surf.get_height() + 100

    def draw_ground(self, surf, cx, cy):
        """Всё, что лежит на земле — рисуется ПОД игроком и зомби: лужа, следы брызг, сама часть."""
        if self.life <= 0 or not self._visible(surf, cx, cy):
            return
        lx, gy = int(self.x - cx), int(self.y - cy)
        for tx, ty, tr in self.trail:
            sp = _splat(max(1, int(tr)), (86, 6, 8), int(tx) % 8)
            surf.blit(sp, (int(tx - cx) - sp.get_width() // 2, int(ty - cy) - sp.get_height() // 2))
        if self.pool > 0:
            ps = _pool_surface(max(1, int(self.pool * 10 * min(1.0, self.size + 0.2))))
            surf.blit(ps, ps.get_rect(center=(lx, gy)))
        if self.z <= 0:
            if self._spr is None:
                self._spr = self._build()
            rotated = pygame.transform.rotate(self._spr, -math.degrees(self.angle))
            surf.blit(rotated, rotated.get_rect(center=(lx, gy)))

    def draw_air(self, surf, cx, cy):
        """Только то, что в полёте, — поверх всего."""
        if self.life <= 0 or self.z <= 0 or not self._visible(surf, cx, cy):
            return
        lx, gy = int(self.x - cx), int(self.y - cy)
        ly = int(self.y - cy - self.z)
        shadow_r = max(2, 10 - int(self.z / 20))
        pygame.draw.ellipse(surf, (60, 46, 36), (lx - shadow_r, gy - shadow_r // 2, shadow_r * 2, shadow_r))
        if self._spr is None:
            self._spr = self._build()
        rotated = pygame.transform.rotate(self._spr, -math.degrees(self.angle))
        surf.blit(rotated, rotated.get_rect(center=(lx, ly)))


class CactusShard:
    def __init__(self, x, y, kind=None):
        self.x = x
        self.y = y
        self.kind = kind or random.choice(("flesh", "flesh", "spine"))
        self.z = random.uniform(14, 30)
        angle = random.uniform(0, math.tau)
        speed = random.uniform(90, 300)
        self.vx = math.cos(angle) * speed
        self.vy = math.sin(angle) * speed
        self.vz = random.uniform(100, 260)
        self.radius = random.randint(2, 5) if self.kind == "flesh" else random.randint(4, 8)
        self.rot = random.uniform(0, math.tau)
        self.spin = random.uniform(-12, 12)
        self.life = random.uniform(12.0, 22.0)
        self.landed = False
        self.just_landed = False
        self.shape = []
        if self.kind == "flesh":
            n = random.randint(5, 7)
            for i in range(n):
                a = i * math.tau / n
                rr = self.radius * random.uniform(0.6, 1.2)
                self.shape.append((math.cos(a) * rr, math.sin(a) * rr))

    def update(self, dt):
        self.life -= dt
        self.rot += self.spin * dt
        if self.landed: return
        self.x += self.vx * dt
        self.y += self.vy * dt
        self.z += self.vz * dt
        self.vz -= 600 * dt

        if self.z <= 0:
            self.z = 0
            self.vz *= -0.4
            self.vx *= 0.7
            self.vy *= 0.7
            if abs(self.vz) < 15 and abs(self.vx) < 15 and abs(self.vy) < 15:
                self.landed = True
                self.just_landed = True

        self.vx *= 0.95
        self.vy *= 0.95

    def draw(self, surf, cx, cy):
        if self.life <= 0: return
        lx = int(self.x - cx)
        ly = int(self.y - cy - self.z)
        if not (-60 < lx < surf.get_width() + 60 and -60 < ly < surf.get_height() + 60): return

        if self.z > 0:
            sr = max(1, int(self.radius * 0.8))
            pygame.draw.ellipse(surf, (120, 96, 58),
                                (int(self.x - cx) - sr, int(self.y - cy) - sr // 3, sr * 2, sr))

        if self.kind == "spine":
            a = self.rot
            x1 = lx - math.cos(a) * self.radius * 0.5
            y1 = ly - math.sin(a) * self.radius * 0.5
            x2 = lx + math.cos(a) * self.radius * 0.5
            y2 = ly + math.sin(a) * self.radius * 0.5
            pygame.draw.line(surf, (150, 160, 90), (x1, y1), (x2, y2), 1)
            pygame.draw.circle(surf, (110, 130, 70), (int(x2), int(y2)), 1)
        else:
            pts = []
            ca, sa = math.cos(self.rot), math.sin(self.rot)
            for px, py in self.shape:
                pts.append((lx + px * ca - py * sa, ly + px * sa + py * ca))
            pygame.draw.polygon(surf, (62, 108, 44), pts)
            pygame.draw.polygon(surf, (38, 74, 30), pts, 1)
            pygame.draw.line(surf, (120, 160, 86), (lx - 1, ly - 1), (lx + 1, ly + 1), 1)


class Debris:
    def __init__(self, x, y, kind="wood"):
        self.x = x
        self.y = y
        self.kind = kind
        a = random.uniform(0, math.tau)
        spd = random.uniform(70, 260)
        self.vx = math.cos(a) * spd
        self.vy = math.sin(a) * spd
        self.vz = random.uniform(60, 190)
        self.z = random.uniform(4, 20)
        self.rot = random.uniform(0, math.tau)
        self.spin = random.uniform(-14, 14)
        self.life = random.uniform(0.9, 2.2) if kind == 'glass' else random.uniform(0.7, 1.6)
        self.max_life = self.life
        if kind == "glass":
            self.color = random.choice(((180, 220, 236), (210, 238, 245), (140, 190, 214)))
            n = random.randint(3, 4)
            self.shape = []
            for i in range(n):
                aa = i * math.tau / n
                rr = random.uniform(1.5, 4.0)
                self.shape.append((math.cos(aa) * rr, math.sin(aa) * rr))
        else:
            self.color = random.choice(((128, 86, 46), (94, 62, 32), (154, 106, 58)))
            w = random.uniform(2.0, 4.0)
            h = random.uniform(0.7, 1.6)
            self.shape = [(-w, -h), (w, -h * 0.5), (w * 0.8, h), (-w, h * 0.6)]

    def update(self, dt):
        self.life -= dt
        self.rot += self.spin * dt
        if self.z > 0 or self.vz > 0:
            self.x += self.vx * dt
            self.y += self.vy * dt
            self.z += self.vz * dt
            self.vz -= 650 * dt
            if self.z <= 0:
                self.z = 0
                self.vz = -self.vz * 0.3 if self.vz < -20 else 0
                self.vx *= 0.6
                self.vy *= 0.6

    def draw(self, surf, cx, cy):
        if self.life <= 0: return
        lx = int(self.x - cx)
        ly = int(self.y - cy - self.z)
        if not (-40 < lx < surf.get_width() + 40 and -40 < ly < surf.get_height() + 40): return
        if self.z > 0:
            pygame.draw.ellipse(surf, (100, 80, 60), (int(self.x - cx) - 2, int(self.y - cy) - 1, 4, 2))
        ca, sa = math.cos(self.rot), math.sin(self.rot)
        pts = [(lx + px * ca - py * sa, ly + px * sa + py * ca) for px, py in self.shape]
        pygame.draw.polygon(surf, self.color, pts)
        if self.kind == "glass":
            pygame.draw.line(surf, (245, 252, 255), pts[0], pts[1], 1)
        else:
            pygame.draw.line(surf, (70, 44, 22), pts[0], pts[1], 1)


class Twig:
    """Обломок сухой ветки перекати-поля: летит, кувыркается, отскакивает."""
    def __init__(self, x, y, angle, power=1.0):
        self.x, self.y = x + random.uniform(-8, 8), y + random.uniform(-8, 8)
        a = angle + random.uniform(-1.6, 1.6)
        spd = random.uniform(60, 240) * power
        self.vx, self.vy = math.cos(a) * spd, math.sin(a) * spd
        self.z = random.uniform(4, 22)
        self.vz = random.uniform(60, 190)
        self.rot = random.uniform(0, math.tau)
        self.spin = random.uniform(-16, 16)
        self.len = random.uniform(5, 13)
        self.life = random.uniform(5.0, 9.0)
        self.col = random.choice(((128, 92, 50), (158, 118, 68), (108, 76, 40), (176, 132, 78)))
        self.bend = random.uniform(-3, 3)

    def update(self, dt):
        self.life -= dt
        self.rot += self.spin * dt
        if self.z > 0 or self.vz > 0:
            self.x += self.vx * dt
            self.y += self.vy * dt
            self.z += self.vz * dt
            self.vz -= 620 * dt
            if self.z <= 0:
                self.z = 0
                self.vz = -self.vz * 0.35 if self.vz < -25 else 0
                self.vx *= 0.55
                self.vy *= 0.55
                self.spin *= 0.5
        else:
            self.vx *= 0.9
            self.vy *= 0.9

    def draw(self, surf, cx, cy):
        lx = int(self.x - cx)
        ly = int(self.y - cy - self.z)
        if not (-30 < lx < surf.get_width() + 30 and -30 < ly < surf.get_height() + 30):
            return
        ca, sa = math.cos(self.rot), math.sin(self.rot)
        h = self.len / 2
        p0 = (lx - ca * h, ly - sa * h)
        p1 = (lx + ca * h, ly + sa * h)
        pm = (lx - sa * self.bend, ly + ca * self.bend)
        if self.z > 1:
            pygame.draw.ellipse(surf, (110, 84, 52), (int(self.x - cx) - 3, int(self.y - cy) - 1, 6, 2))
        pygame.draw.lines(surf, (44, 30, 16), False, [p0, pm, p1], 3)
        pygame.draw.lines(surf, self.col, False, [p0, pm, p1], 1)


_SPLAT_CACHE = {}


def _splat(r, color, v):
    """Неровная клякса с «лучами» и отлетевшими каплями — а не круг."""
    key = (int(r), color, v)
    s = _SPLAT_CACHE.get(key)
    if s is not None:
        return s
    rnd = random.Random(v * 131 + int(r) * 7)
    r = max(1, int(r))
    size = r * 4 + 6
    c = size // 2
    s = pygame.Surface((size, size), pygame.SRCALPHA)
    n = 9 if r > 1 else 5
    base = rnd.uniform(0, math.tau)
    pts = []
    for i in range(n * 2):
        a = base + i * math.tau / (n * 2)
        k = rnd.uniform(1.25, 1.9) if i % 2 == 0 and r > 1 else rnd.uniform(0.55, 0.95)
        stretch = 1.0 + 0.4 * math.cos((a - base) * 2)
        pts.append((c + math.cos(a) * r * k * stretch, c + math.sin(a) * r * k * 0.8))
    pygame.draw.polygon(s, color, pts)
    dark = tuple(int(x * 0.7) for x in color)
    pygame.draw.polygon(s, dark, [(c + (p[0] - c) * 0.5, c + (p[1] - c) * 0.5) for p in pts])
    for _ in range(2 + r // 2):
        a = rnd.uniform(0, math.tau)
        d = rnd.uniform(r * 1.5, r * 1.9)
        pygame.draw.circle(s, color, (int(c + math.cos(a) * d), int(c + math.sin(a) * d)), 1)
    _SPLAT_CACHE[key] = s
    return s


def create_splatter_surface(radius, angle, dmg_mult=1.0):
    # Рисуем в 2x и уменьшаем — края лужи получаются сглаженными
    ss = 2
    size = int(radius * 3 * max(1.0, dmg_mult))
    surface = pygame.Surface((size * ss, size * ss), pygame.SRCALPHA)
    cx, cy = size * ss / 2, size * ss / 2
    colors = [(92, 5, 7), (78, 3, 5), (68, 2, 4)]

    for k in range(3):
        points = []
        num_points = random.randint(10, 20)
        for i in range(num_points):
            a = (i / num_points) * math.tau
            r = radius * random.uniform(0.3, 0.9) * dmg_mult * ss
            points.append((cx + math.cos(a) * r, cy + math.sin(a) * r))
        pygame.draw.polygon(surface, colors[k], points)

    # тёмное свернувшееся пятно в центре
    core = []
    for i in range(14):
        a = i * math.tau / 14
        rr = radius * dmg_mult * random.uniform(0.38, 0.74) * ss
        core.append((cx + math.cos(a) * rr * 1.1, cy + math.sin(a) * rr * 0.85))
    pygame.draw.polygon(surface, (56, 1, 3), core)

    for _ in range(random.randint(10, 20)):
        a = angle + random.uniform(-0.6, 0.6)
        dist_start = random.uniform(radius*0.3, radius*0.6) * dmg_mult * ss
        dist_end = dist_start + random.uniform(radius*0.3, radius*1.2) * dmg_mult * ss
        x1, y1 = cx + math.cos(a) * dist_start, cy + math.sin(a) * dist_start
        x2, y2 = cx + math.cos(a) * dist_end, cy + math.sin(a) * dist_end
        pygame.draw.line(surface, colors[0], (x1, y1), (x2, y2), random.randint(1, 2) * ss)
        if random.random() < 0.8:
            pygame.draw.circle(surface, colors[0], (int(x2), int(y2)), ss)

    for _ in range(random.randint(30, 60)):
        a = angle + random.uniform(-1.2, 1.2)
        dist = random.uniform(radius*0.5, radius*2.0) * dmg_mult * ss
        px = cx + math.cos(a) * dist
        py = cy + math.sin(a) * dist
        pygame.draw.circle(surface, colors[0], (int(px), int(py)), random.choice([1, 1, 2]) * ss)
    return pygame.transform.smoothscale(surface, (size, size))

class BloodSystem:
    def __init__(self):
        _load_footprint()
        self.sparks = []
        self.decals = []  
        self.puddles = [] 
        self.limbs = []
        self.footprints = []
        self.dust = []
        self.cactus_shards = []
        self.mist = []
        self.wall_decals = []
        self.debris = []
        self.twigs = []
        self.glass_litter = []

    def _add_decal(self, x, y, r, color=(80, 0, 0)):
        self.decals.append({"x": x, "y": y, "r": r, "color": color, "v": random.randrange(8)})
        if len(self.decals) > 2000: self.decals.pop(0)

    def _add_puddle(self, x, y, base_r, angle, dmg):
        dmg_mult = max(0.6, min(1.5, dmg / 50.0))
        surf = create_splatter_surface(base_r, angle, dmg_mult)
        self.puddles.append({"x": x, "y": y, "surf": surf, "radius": base_r * dmg_mult, "scale": 0.4})
        if len(self.puddles) > 100: self.puddles.pop(0)

    def add_dust(self, x, y, angle):
        for _ in range(2):
            a = angle + math.pi + random.uniform(-0.7, 0.7)
            spd = random.uniform(15, 50)
            self.dust.append({
                "x": x, "y": y, "vx": math.cos(a) * spd, "vy": math.sin(a) * spd,
                "r": random.uniform(2, 5), "life": random.uniform(0.4, 0.8), "max_life": 0.8,
            })
        if len(self.dust) > 150: self.dust.pop(0)

    def add_cactus_explosion(self, x, y):
        for _ in range(36):
            spd = random.uniform(80, 320)
            a = random.uniform(0, math.tau)
            self.sparks.append({
                "x": x, "y": y, "z": random.uniform(8, 32),
                "vx": math.cos(a) * spd, "vy": math.sin(a) * spd,
                "vz": random.uniform(30, 120), "r": random.randint(2, 4), "color": (60, 100, 40)
            })
        for _ in range(9):
            self.cactus_shards.append(CactusShard(x, y, "flesh"))
        for _ in range(8):
            self.cactus_shards.append(CactusShard(x, y, "spine"))
        for _ in range(5):
            a = random.uniform(0, math.tau)
            d = random.uniform(4, 18)
            self._add_decal(x + math.cos(a) * d, y + math.sin(a) * d,
                            random.randint(2, 4), (42, 82, 34))
        self._add_mist(x, y, 0.0, 7, (60, 100, 40))

    def _add_mist(self, x, y, angle, count, color=(118, 6, 8)):
        for _ in range(count):
            a = angle + random.uniform(-0.6, 0.6)
            spd = random.uniform(12, 65)
            life = random.uniform(0.16, 0.42)
            self.mist.append({
                "x": x, "y": y,
                "vx": math.cos(a) * spd, "vy": math.sin(a) * spd,
                "r": random.uniform(2.5, 6.0), "life": life, "max_life": life,
                "color": color,
            })
        if len(self.mist) > 220:
            self.mist = self.mist[-220:]

    def add_debris(self, x, y, kind="wood", count=6):
        for _ in range(count):
            self.debris.append(Debris(x, y, kind))
        if len(self.debris) > 220:
            del self.debris[:len(self.debris) - 220]

    def add_tumble_burst(self, x, y, r, angle):
        """Перекати-поле разлетается на ветки, пыль и сухие листья."""
        for _ in range(int(14 + r)):
            self.twigs.append(Twig(x, y, angle, 1.0))
        if len(self.twigs) > 260:
            del self.twigs[:len(self.twigs) - 260]
        for _ in range(8):
            a = random.uniform(0, math.tau)
            self.dust.append({"x": x, "y": y, "vx": math.cos(a) * random.uniform(20, 90),
                              "vy": math.sin(a) * random.uniform(20, 90),
                              "r": random.uniform(3, 7), "life": random.uniform(0.5, 1.0), "max_life": 1.0})

    def add_glass_litter(self, x, y, w, h, n=22):
        """Осколки остаются на земле у окна и хрустят под ногами."""
        for _ in range(n):
            self.glass_litter.append({
                "x": x + random.uniform(-4, w + 4), "y": y + h + random.uniform(-6, 22),
                "r": random.uniform(1.2, 3.4), "a": random.uniform(0, math.tau),
                "c": random.choice(((196, 232, 246), (222, 246, 252), (150, 200, 222)))})
        if len(self.glass_litter) > 500:
            del self.glass_litter[:len(self.glass_litter) - 500]

    def on_glass(self, x, y):
        for g in self.glass_litter:
            if abs(g["x"] - x) < 14 and abs(g["y"] - y) < 14:
                return True
        return False

    def add_wall_splat(self, x, y, radius=2, angle=0.0):
        """Кровь на стене/крыше дома: брызги с потёками вниз."""
        r = max(4.0, radius * 2.0)
        splat = create_splatter_surface(r, angle, 0.9)
        sw, sh = splat.get_size()
        dmax = random.randint(7, 20)
        w, h = sw + 8, sh + dmax + 6
        surf = pygame.Surface((w, h), pygame.SRCALPHA)
        surf.blit(splat, (4, 3))
        for _ in range(random.randint(1, 3)):
            dx = random.randint(6, max(7, w - 6))
            y0 = random.randint(max(2, sh // 3), max(3, sh - 2))
            ln = random.randint(5, dmax)
            y1 = min(h - 2, y0 + ln)
            pygame.draw.line(surf, (88, 4, 6), (dx, y0), (dx, y1), 1)
            pygame.draw.circle(surf, (96, 6, 8), (dx, y1), 1)
        self.wall_decals.append({"x": x, "y": y, "surf": surf,
                                 "ox": w / 2, "oy": sh / 2, "life": 90.0, "max": 90.0})
        if len(self.wall_decals) > 300:
            self.wall_decals.pop(0)

    def _add_blood_spark(self, x, y, angle, speed, z, vz, r):
        self.sparks.append({
            "x": x, "y": y, "z": z,
            "vx": math.cos(angle) * speed, "vy": math.sin(angle) * speed,
            "vz": vz, "r": r, "color": (100, 0, 0), "blood": True,
        })

    def wound_drip(self, x, y, angle):
        """Кровь сочится из раны и капает на землю."""
        for _ in range(random.randint(1, 2)):
            a = angle + random.uniform(-0.6, 0.6)
            spd = random.uniform(15, 60)
            self._add_blood_spark(x, y, a, spd, random.uniform(8, 22),
                                  random.uniform(-10, 25), random.choice((1, 1, 2, 2)))

    def hit(self, x, y, angle, dmg, dist=0):
        # Чем сильнее удар и ближе цель — тем больше брызг
        count = int(max(2, min(12, 3 + dmg * 0.05 - dist / 300)))
        for _ in range(count):
            a = angle + random.uniform(-0.35, 0.35)
            spd = random.uniform(150, 380 + dmg * 3)
            self._add_blood_spark(x, y, a, spd, random.uniform(6, 26),
                                  random.uniform(25, 70 + dmg * 0.9),
                                  random.choice((1, 1, 2, 2, 2, 3)))
        self._add_mist(x, y, angle, min(6, 2 + int(dmg / 18)))

    def death(self, x, y, angle, dmg=30):
        self._add_puddle(x, y, random.randint(12, 20), angle, min(dmg, 70))
        # Мощный залповый выброс крови по направлению удара
        count = int(max(16, min(46, 16 + dmg * 0.35)))
        for _ in range(count):
            a = angle + random.uniform(-0.8, 0.8)
            spd = random.uniform(80, 420 + dmg * 2)
            self._add_blood_spark(x, y, a, spd, random.uniform(3, 34),
                                  random.uniform(20, 130 + dmg),
                                  random.choice((1, 2, 2, 2, 3, 3, 4)))
        # Несколько крупных сгустков, летящих медленнее
        for _ in range(random.randint(3, 6)):
            a = angle + random.uniform(-0.5, 0.5)
            self._add_blood_spark(x, y, a, random.uniform(50, 180),
                                  random.uniform(10, 30), random.uniform(40, 120), 4)
        # Брызги на землю вокруг тела
        for _ in range(random.randint(8, 14)):
            a = random.uniform(0, math.tau)
            d = random.uniform(6, 22)
            self._add_decal(x + math.cos(a) * d, y + math.sin(a) * d,
                            random.choice((1, 2, 2, 3)), (85, 0, 0))
        self._add_mist(x, y, angle, 10)

    def saw_gore(self, x, y, cut_angle, px, py):
        """Бензопила: веер крови в сторону пилы и игрока, туман, мясные ошмётки, лужа."""
        back = math.atan2(py - y, px - x)
        for _ in range(26):
            a = (back if random.random() < 0.55 else cut_angle) + random.uniform(-1.0, 1.0)
            self._add_blood_spark(x, y, a, random.uniform(120, 430), random.uniform(6, 24),
                                  random.uniform(30, 130), random.choice((1, 2, 2, 3, 3)))
        self._add_mist(x, y, back, 9)
        self._add_mist(x, y, cut_angle, 7)
        for _ in range(random.randint(8, 14)):
            a = random.uniform(0, math.tau)
            d = random.uniform(4, 26)
            self._add_decal(x + math.cos(a) * d, y + math.sin(a) * d,
                            random.choice((1, 2, 3, 3)), (80, 2, 4))
        if random.random() < 0.55:
            self._add_puddle(x, y, random.randint(8, 13), cut_angle, 45)
        if random.random() < 0.4:
            self.limbs.append(Limb(x, y, "chunk", (150, 60, 66), soft=True, angle=cut_angle))

    def gore_pile(self, x, y, angle, big=True, size=1.0, organs=True):
        """Огромная рваная рана: широкая лужа, брызги по направлению выстрела и органы вокруг."""
        r = int((random.randint(26, 34) if big else random.randint(18, 24)) * max(0.55, size))
        self._add_puddle(x, y, r, angle, 95 if big else 70)
        self._add_puddle(x + math.cos(angle) * 14, y + math.sin(angle) * 14, int(r * 0.7), angle, 80)
        for _ in range(26 if big else 14):
            a = angle + random.uniform(-0.9, 0.9)
            self._add_blood_spark(x, y, a, random.uniform(120, 460), random.uniform(6, 22),
                                  random.uniform(30, 130), random.choice((2, 2, 3, 3, 4)))
        for _ in range(random.randint(14, 22)):
            a = random.uniform(0, math.tau)
            d = random.uniform(8, r * 1.3)
            self._add_decal(x + math.cos(a) * d, y + math.sin(a) * d, random.choice((2, 3, 3, 4)), (78, 3, 5))
        self._add_mist(x, y, angle, 12)
        n = (random.randint(4, 6) if big else random.randint(2, 3)) if organs else 0
        if size < 0.85:
            n = min(n, 3)
        kinds = [0, 1, 1, 2, 3, 4, 4]
        for i in range(n):
            lb = Limb(x, y, "organ", (150, 60, 66), soft=True, angle=angle + random.uniform(-1.2, 1.2), size=max(0.6, size))
            lb._seed = (random.choice(kinds)) + 5 * random.randint(0, 20)
            lb.vx *= 0.7
            lb.vy *= 0.7
            self.limbs.append(lb)
        for _ in range(random.randint(2, 4)):
            self.limbs.append(Limb(x, y, "chunk", (150, 60, 66), soft=True, angle=angle))

    def spill_guts(self, x, y, angle):
        """Из распоротого пилой тела вываливаются внутренности."""
        for _ in range(random.randint(1, 2)):
            lb = Limb(x, y, "organ", (150, 60, 66), soft=True, angle=angle + random.uniform(-0.8, 0.8))
            lb._seed = 4 + 5 * random.randint(0, 20)      # кишечные петли
            self.limbs.append(lb)
        self._add_puddle(x, y, random.randint(10, 15), angle, 60)

    def guts(self, x, y, angle, count=4):
        """Тяжёлый разрыв: несколько кусков мяса рядом с телом и тёмные брызги."""
        for _ in range(min(count, 3)):
            self.limbs.append(Limb(x, y, "chunk", (150, 60, 66), soft=True))
        self._add_mist(x, y, angle, 5)
        for _ in range(random.randint(3, 6)):
            a = angle + random.uniform(-0.9, 0.9)
            d = random.uniform(3, 14)
            self._add_decal(x + math.cos(a) * d, y + math.sin(a) * d,
                            random.choice((2, 3, 4)), (72, 4, 6))

    def is_bloody(self, x, y):
        for p in self.puddles:
            if math.hypot(x - p["x"], y - p["y"]) < p["radius"] + 10: return True
        return False

    def add_footprint(self, x, y, angle, side, intensity):
        perp_angle = angle + math.pi/2
        offset = 5.0 
        ox = math.cos(perp_angle) * offset * side
        oy = math.sin(perp_angle) * offset * side
        self.footprints.append({
            "x": x + ox, "y": y + oy, "angle": angle, "side": side, 
            "intensity": intensity, "life": 10.0  # Живут 10 секунд
        })
        if len(self.footprints) > 2000: self.footprints.pop(0)

    def update(self, dt):
        for p in self.sparks[:]:
            p["x"] += p["vx"] * dt
            p["y"] += p["vy"] * dt
            p["z"] += p["vz"] * dt
            p["vz"] -= 800 * dt 
            if p["z"] <= 0:
                if p.get("color") == (100, 0, 0):
                    self._add_decal(p["x"], p["y"], p["r"], (80, 0, 0))
                elif p.get("color") == (60, 100, 40):
                    self._add_decal(p["x"], p["y"], p["r"], (40, 80, 30))
                self.sparks.remove(p)
        if len(self.sparks) > 1200:
            del self.sparks[:len(self.sparks) - 1200]

        for m in self.mist:
            m["x"] += m["vx"] * dt
            m["y"] += m["vy"] * dt
            m["vx"] *= 0.90
            m["vy"] *= 0.90
            m["r"] += 12 * dt
            m["life"] -= dt
        self.mist = [m for m in self.mist if m["life"] > 0]

        for wd in self.wall_decals:
            wd["life"] -= dt
        self.wall_decals = [wd for wd in self.wall_decals if wd["life"] > 0]

        for d in self.debris:
            d.update(dt)
        self.debris = [d for d in self.debris if d.life > 0]
        for t in self.twigs:
            t.update(dt)
        self.twigs = [t for t in self.twigs if t.life > 0]

        for p in self.puddles:
            if p["scale"] < 1.0:
                p["scale"] += 2.0 * dt 
                if p["scale"] > 1.0: p["scale"] = 1.0

        for l in self.limbs: l.update(dt)
        self.limbs = [l for l in self.limbs if l.life > 0]

        for s in self.cactus_shards:
            s.update(dt)
            if s.just_landed:
                s.just_landed = False
                self._add_decal(s.x, s.y, s.radius, (42, 82, 34))
        self.cactus_shards = [s for s in self.cactus_shards if s.life > 0]
        if len(self.cactus_shards) > 400: self.cactus_shards.pop(0)

        # Таймер жизни следов
        for f in self.footprints:
            f["life"] -= dt
        self.footprints = [f for f in self.footprints if f["life"] > 0]

        for d in self.dust:
            d["x"] += d["vx"] * dt
            d["y"] += d["vy"] * dt
            d["vx"] *= 0.92
            d["vy"] *= 0.92
            d["r"] += 10 * dt
            d["life"] -= dt
        self.dust = [d for d in self.dust if d["life"] > 0]

    def draw_dust(self, surf, cx, cy):
        for d in self.dust:
            dx = int(d["x"] - cx)
            dy = int(d["y"] - cy)
            if -50 < dx < surf.get_width() + 50 and -50 < dy < surf.get_height() + 50:
                alpha = int(140 * (d["life"] / d["max_life"]))
                r = int(d["r"])
                s = pygame.Surface((r * 2 + 2, r * 2 + 2), pygame.SRCALPHA)
                pygame.draw.circle(s, (216, 186, 130, alpha), (r + 1, r + 1), r)
                surf.blit(s, (dx - r - 1, dy - r - 1))

    def draw_ground(self, surf, cx, cy):
        for g in self.glass_litter:
            gx, gy = int(g["x"] - cx), int(g["y"] - cy)
            if -10 < gx < surf.get_width() + 10 and -10 < gy < surf.get_height() + 10:
                ca, sa = math.cos(g["a"]) * g["r"], math.sin(g["a"]) * g["r"]
                pts = [(gx + ca, gy + sa), (gx - sa * 0.6, gy + ca * 0.6), (gx - ca * 0.8, gy - sa * 0.8)]
                pygame.draw.polygon(surf, g["c"], pts)
        for d in self.decals:
            dx, dy = int(d["x"] - cx), int(d["y"] - cy)
            if -20 < dx < surf.get_width() + 20 and -20 < dy < surf.get_height() + 20:
                sp = _splat(d["r"], d.get("color", (80, 0, 0)), d.get("v", 0))
                surf.blit(sp, (dx - sp.get_width() // 2, dy - sp.get_height() // 2))

        for p in self.puddles:
            px, py = int(p["x"] - cx), int(p["y"] - cy)
            if -100 < px < surf.get_width() + 100 and -100 < py < surf.get_height() + 100:
                scaled_surf = pygame.transform.scale(p["surf"], (int(p["surf"].get_width() * p["scale"]), int(p["surf"].get_height() * p["scale"])))
                rect = scaled_surf.get_rect(center=(px, py))
                surf.blit(scaled_surf, rect)
                
        for f in self.footprints:
            fx, fy = int(f["x"] - cx), int(f["y"] - cy)
            if -20 < fx < surf.get_width() + 20 and -20 < fy < surf.get_height() + 20:
                # 1. Прозрачность от времени (следы растворяются на земле)
                time_alpha = min(1.0, f["life"] / 3.0)
                
                # 2. Прозрачность от заряда крови на ботинках (высыхает с каждым шагом)
                blood_alpha = f.get("intensity", 1.0)
                
                # Итоговая прозрачность (умножаем обе)
                final_alpha = time_alpha * blood_alpha
                if final_alpha <= 0.01: continue
                
                img = _FOOTPRINT_RIGHT if f["side"] == 1 else _FOOTPRINT_LEFT
                if img:
                    deg = -math.degrees(f["angle"]) - 90
                    rotated = pygame.transform.rotate(img, deg)
                    rotated.set_alpha(int(255 * final_alpha))
                    rect = rotated.get_rect(center=(fx, fy))
                    surf.blit(rotated, rect)

    def draw_limbs_ground(self, surf, cx, cy):
        for l in self.limbs: l.draw_ground(surf, cx, cy)

    def draw_walls(self, surf, cx, cy):
        for wd in self.wall_decals:
            x, y = int(wd["x"] - cx), int(wd["y"] - cy)
            if not (-80 < x < surf.get_width() + 80 and -80 < y < surf.get_height() + 80):
                continue
            img = wd["surf"]
            img.set_alpha(int(255 * min(1.0, wd["life"] / 5.0)))
            surf.blit(img, (int(x - wd["ox"]), int(y - wd["oy"])))

    def draw_air(self, surf, cx, cy):
        # кровавая взвесь
        for m in self.mist:
            mx, my = int(m["x"] - cx), int(m["y"] - cy)
            if not (-40 < mx < surf.get_width() + 40 and -40 < my < surf.get_height() + 40):
                continue
            r = max(1, int(m["r"]))
            alpha = int(95 * max(0.0, m["life"] / m["max_life"]))
            mc = m.get("color", (118, 6, 8))
            s = pygame.Surface((r * 2 + 2, r * 2 + 2), pygame.SRCALPHA)
            pygame.draw.circle(s, (mc[0], mc[1], mc[2], alpha), (r + 1, r + 1), r)
            surf.blit(s, (mx - r - 1, my - r - 1))

        for p in self.sparks:
            sx = int(p["x"] - cx)
            sy = int(p["y"] - cy - p["z"])
            col = p.get("color", (100, 0, 0))

            if p.get("blood"):
                # тень капли на земле
                if p["z"] > 0:
                    pygame.draw.circle(surf, (60, 16, 14),
                                       (int(p["x"] - cx), int(p["y"] - cy)),
                                       max(1, int(p["r"] * 0.9)))
                vx, vy = p["vx"], p["vy"]
                v_len = math.hypot(vx, vy) or 1
                length = min(10.0, 1.5 + p["r"] * 1.8 + v_len / 130)
                ex = sx - (vx / v_len) * length
                ey = sy - (vy / v_len) * length
                pygame.draw.line(surf, col, (sx, sy), (ex, ey), max(1, int(p["r"] - 0.4)))
                # сама капля ярче хвоста
                pygame.draw.circle(surf, (126, 6, 8), (sx, sy), max(1, int(p["r"] * 0.85)))
            elif col == (60, 100, 40):
                # сок кактуса — просто круглые капли
                pygame.draw.circle(surf, col, (sx, sy), p["r"])
            else:
                vx, vy = p["vx"], p["vy"]
                v_len = math.hypot(vx, vy) or 1
                pygame.draw.line(surf, col, (sx, sy),
                                 (sx - vx / v_len * 5, sy - vy / v_len * 5), max(1, p["r"]))
                pygame.draw.circle(surf, col, (sx, sy), p["r"])

        for l in self.limbs: l.draw_air(surf, cx, cy)
        for s in self.cactus_shards: s.draw(surf, cx, cy)
        for d in self.debris: d.draw(surf, cx, cy)
        for t in self.twigs: t.draw(surf, cx, cy)
