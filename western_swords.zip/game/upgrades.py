"""Улучшения при повышении уровня: каждый раз случайные 3 варианта, процент 10–20%.
В режиме без огнестрельного оружия (МЯСНИК) улучшения для стволов не выпадают."""
import random

# kind: "gun" — только огнестрел, "melee" — ближний бой (включая пинок), "any" — всегда
POOL = [
    {"id": "gun_dmg",   "kind": "gun",   "tag": "ОГНЕСТРЕЛ",    "title": "УРОН ПУЛЬ",
     "desc": "Пули бьют сильнее"},
    {"id": "gun_rate",  "kind": "gun",   "tag": "ОГНЕСТРЕЛ",    "title": "СКОРОСТРЕЛЬНОСТЬ",
     "desc": "Стреляешь чаще"},
    {"id": "reload",    "kind": "gun",   "tag": "ОГНЕСТРЕЛ",    "title": "ПЕРЕЗАРЯДКА",
     "desc": "Перезаряд быстрее"},
    {"id": "mag",       "kind": "gun",   "tag": "ОГНЕСТРЕЛ",    "title": "МАГАЗИН",
     "desc": "Больше патронов в обойме"},
    {"id": "melee_dmg", "kind": "melee", "tag": "БЛИЖНИЙ БОЙ",  "title": "УРОН В БЛИЖНЕМ",
     "desc": "Удары и пинки сильнее"},
    {"id": "melee_spd", "kind": "melee", "tag": "БЛИЖНИЙ БОЙ",  "title": "СКОРОСТЬ УДАРОВ",
     "desc": "Бьёшь быстрее"},
    {"id": "reach",     "kind": "melee", "tag": "БЛИЖНИЙ БОЙ",  "title": "ДАЛЬНОСТЬ УДАРА",
     "desc": "Достаёшь дальше"},
    {"id": "speed",     "kind": "any",   "tag": "ПЕРСОНАЖ",     "title": "СКОРОСТЬ БЕГА",
     "desc": "Двигаешься быстрее"},
    {"id": "hp",        "kind": "any",   "tag": "ПЕРСОНАЖ",     "title": "ЗДОРОВЬЕ",
     "desc": "Больше макс. здоровья"},
    {"id": "stamina",   "kind": "any",   "tag": "ПЕРСОНАЖ",     "title": "ВЫНОСЛИВОСТЬ",
     "desc": "Больше стамины, быстрее отдых"},
    {"id": "heal",      "kind": "any",   "tag": "ПЕРСОНАЖ",     "title": "ЛЕЧЕНИЕ",
     "desc": "Восстановить здоровье"},
]
TAG_COLORS = {"ОГНЕСТРЕЛ": (255, 190, 110), "БЛИЖНИЙ БОЙ": (150, 255, 150), "ПЕРСОНАЖ": (150, 200, 255)}


def roll(has_guns, n=3):
    """n разных улучшений со случайным процентом 10–20."""
    pool = [u for u in POOL if has_guns or u["kind"] != "gun"]
    return [dict(u, pct=random.randint(10, 20)) for u in random.sample(pool, n)]


def apply(player, up):
    p = up["pct"] / 100.0
    i = up["id"]
    if i == "gun_dmg":
        player.dmg_mult *= 1 + p
    elif i == "gun_rate":
        player.rate_mult *= 1 - p
    elif i == "reload":
        player.reload_mult *= 1 - p
    elif i == "mag":
        player.mag_mult *= 1 + p
    elif i == "melee_dmg":
        player.melee_dmg_mult *= 1 + p
    elif i == "melee_spd":
        player.melee_rate_mult *= 1 - p
    elif i == "reach":
        player.melee_reach_mult *= 1 + p
    elif i == "speed":
        player.speed *= 1 + p
    elif i == "hp":
        add = player.max_hp * p
        player.max_hp = int(round(player.max_hp + add))
        player.hp = min(player.max_hp, player.hp + add)
    elif i == "stamina":
        player.max_stamina *= 1 + p
        player.stamina = min(player.max_stamina, player.stamina + player.max_stamina * p)
        player.stam_regen_mult *= 1 + p
    elif i == "heal":
        player.hp = min(player.max_hp, player.hp + player.max_hp * p * 2.0)
    player.apply_upgrades()


def line(up):
    """Крупная строка карточки."""
    if up["id"] == "heal":
        return f"+{int(up['pct'] * 2)}% HP"
    if up["id"] in ("gun_rate", "reload", "melee_spd"):
        return f"−{up['pct']}% время" if up["id"] != "gun_rate" else f"+{up['pct']}%"
    return f"+{up['pct']}%"
