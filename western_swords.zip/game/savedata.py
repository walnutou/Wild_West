"""Рекорды по режимам (JSON в папке данных пользователя)."""
import json
import os
from pathlib import Path


def _dir():
    base = os.environ.get("ANDROID_PRIVATE") or os.environ.get("XDG_DATA_HOME") or str(Path.home() / ".local" / "share")
    p = Path(base) / "zombie_vortex"
    try:
        p.mkdir(parents=True, exist_ok=True)
    except Exception:
        p = Path(".")
    return p


_FILE = None
_data = None


def _load():
    global _data, _FILE
    if _data is None:
        _FILE = _dir() / "records.json"
        try:
            _data = json.loads(_FILE.read_text(encoding="utf-8"))
        except Exception:
            _data = {}
    return _data


def best(mode):
    return _load().get(mode, {})


def submit(mode, kills, seconds, wave=0, won=False):
    """Возвращает True, если поставлен новый рекорд."""
    d = _load()
    cur = d.get(mode, {})
    key = (wave, kills, seconds) if mode == "waves" else (kills, seconds)
    old = (cur.get("wave", 0), cur.get("kills", 0), cur.get("time", 0)) if mode == "waves" else (cur.get("kills", 0), cur.get("time", 0))
    if mode == "dawn":
        if not won:
            return False
        better = (not cur.get("won")) or seconds < cur.get("time", 1e9) or kills > cur.get("kills", 0)
    elif mode == "nightmare":
        better = (seconds, kills) > (cur.get("time", 0), cur.get("kills", 0))
    else:
        better = key > old
    if better:
        d[mode] = {"kills": kills, "time": int(seconds), "wave": wave, "won": won}
        try:
            _FILE.write_text(json.dumps(d, ensure_ascii=False), encoding="utf-8")
        except Exception:
            pass
    return better
