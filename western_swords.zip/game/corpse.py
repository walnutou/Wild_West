"""Труп: тело получает удар, отлетает, проворачивается и ПАДАЕТ — вместо «появления» спрайта.
Тело рисуется векторно в локальных координатах (голова вперёд), поэтому отстрелянные
конечности сразу отсутствуют, а поза плавно переходит из «стоит» в «лежит»."""
import math, random, pygame
from .config import SAND_D
from .gfx import Painter, shade

CANVAS = 120
FALL_TIME = 0.8
BLOOD = (128, 14, 14)
BLOOD_D = (84, 8, 8)


def _lerp(a, b, t):
    return a + (b - a) * t


def _ease_out_back(u):
    c1 = 1.1
    c3 = c1 + 1
    return 1 + c3 * (u - 1) ** 3 + c1 * (u - 1) ** 2


def _fall(u):
    """Реалистичное падение: колени подгибаются (медленно), потом тело быстро
    обрушивается, при ударе о землю — небольшой отскок и затухание."""
    if u >= 1.0:
        return 1.0
    if u < 0.7:
        return (u / 0.7) ** 2.2
    v = (u - 0.7) / 0.3
    return 1.0 - 0.09 * math.sin(math.pi * v) * (1.0 - v)


def _smooth(u):
    return u * u * (3 - 2 * u)


def _new_shape(raider):
    return {
        "leg_l": random.uniform(0.05, 0.38), "leg_r": random.uniform(0.05, 0.38),
        "leg_bend_l": random.uniform(-4, 4), "leg_bend_r": random.uniform(-4, 4),
        "arm_l": random.uniform(1.0, 2.0), "arm_r": random.uniform(1.0, 2.0),
        "arm_bend_l": random.uniform(-4, 4), "arm_bend_r": random.uniform(-4, 4),
        "head_y": random.uniform(-3.5, 3.5), "head_tilt": random.uniform(-0.5, 0.5),
        "blood": [(random.uniform(-2, 2), random.uniform(-3, 3), random.uniform(5.5, 7), random.uniform(5, 8))]
                 + [(random.uniform(-5, 5), random.uniform(-9, 9), random.uniform(1.5, 2.6), random.uniform(1.2, 2.2))
                    for _ in range(random.randint(1, 2))],
        "rips": [(random.uniform(-3, 3), random.choice((-1, 1)) * random.uniform(8, 11), random.uniform(1.6, 2.4))
                 for _ in range(random.randint(0, 1))],
        "hat_dx": random.uniform(8, 16), "hat_dy": random.choice((-1, 1)) * random.uniform(10, 17),
        "hat_rot": random.uniform(0, math.tau),
        "raider": raider,
        "wound": None,
        "wseed": random.randint(1, 99999),
        "gut_side": random.choice((-1, 1)),
    }


def render_body(style, limbs, shape, pose, angle, walk=0.0, scale=1.0, attack=0.0, jaw="normal"):
    """pose: 0 — стоит и идёт (walk — фаза шага), 1 — лежит вытянувшись."""
    skin, shirt, pants = style["skin"], style["shirt"], style["pants"]
    P = Painter(CANVAS, 2, angle, scale)
    edge, pedge, sedge = shade(skin, 0.45), shade(pants, 0.45), shade(shirt, 0.45)
    sw = math.sin(walk)

    # --- ноги ---
    for side, key, la, bend in ((-1, "l_leg", shape["leg_l"], shape["leg_bend_l"]),
                                (1, "r_leg", shape["leg_r"], shape["leg_bend_r"])):
        hip = (_lerp(-4, -9, pose), side * _lerp(4.5, 3.6, pose))
        if limbs[key]:
            alive_foot = (-12 + side * sw * 7, side * 5.5)
            lying_foot = (hip[0] - math.cos(la) * 17, hip[1] + side * math.sin(la) * 17)
            end = (_lerp(alive_foot[0], lying_foot[0], pose), _lerp(alive_foot[1], lying_foot[1], pose))
            mid = ((hip[0] + end[0]) / 2, (hip[1] + end[1]) / 2 + bend * 0.4 * pose)
            P.thick(hip, mid, 6.0, pants, pedge)
            P.thick(mid, end, 5.4, shade(pants, 0.92), pedge)
            P.ellipse(end[0] - 1.5, end[1], 4.4, 3.3, (36, 26, 20), (18, 12, 10), 0.8)
        else:
            P.circle(hip[0], hip[1], 4.0, BLOOD, BLOOD_D)
            P.ellipse(hip[0] - 4, hip[1], 5, 2.6, BLOOD_D)

    # --- руки ---
    for side, key, aa, bend in ((-1, "l_arm", shape["arm_l"], shape["arm_bend_l"]),
                                (1, "r_arm", shape["arm_r"], shape["arm_bend_r"])):
        sh = (_lerp(3, 7, pose), side * _lerp(11, 8.5, pose))
        if limbs[key]:
            sway = math.sin(walk * 0.8 + (0 if side < 0 else 1.7)) * 0.16
            a = _lerp((0.2 + sway) * (1 - 0.7 * attack), aa, pose)
            L = _lerp(21 + 5 * attack, 15, pose)
            end = (sh[0] + math.cos(a) * L, sh[1] + side * math.sin(a) * L)
            mid = ((sh[0] + end[0]) / 2, (sh[1] + end[1]) / 2 + bend * 0.5 * pose)
            P.thick(sh, mid, 5.2, shirt, sedge)
            P.thick(mid, end, 4.4, skin, edge)
            P.circle(end[0], end[1], 3.0, skin, edge, 0.7)
            if pose < 0.5:  # когти
                for d in (-0.4, 0.0, 0.4):
                    P.line((end[0] + 1.5, end[1]), (end[0] + 4.6, end[1] + d * 3), 0.9, shade(skin, 0.5))
        else:
            P.circle(sh[0], sh[1], 3.6, BLOOD, BLOOD_D)

    # --- торс: плечи поперёк → лежит вдоль ---
    tx = _lerp(2.5 * attack, 1.5, pose)
    rx, ry = _lerp(9.2, 12.5, pose), _lerp(13.2, 8.4, pose)
    P.ellipse(tx, 0, rx, ry, shirt, sedge, 1.1)
    P.ellipse(tx - 1.2, -2, rx * 0.68, ry * 0.68, shade(shirt, 1.2))
    for qx, qy, qr in shape["rips"]:
        P.ellipse(qx, qy * (1 - 0.3 * pose), qr * 1.4, qr, skin, edge, 0.6)
    for bx, by, brx, bry in shape["blood"]:
        P.ellipse(bx, by * (1 - 0.35 * pose), brx, bry, BLOOD, rot=bx)
        P.ellipse(bx + 0.5, by * (1 - 0.35 * pose), brx * 0.5, bry * 0.5, BLOOD_D, rot=bx)

    # --- рана. Тело лежит на спине, голова вперёд (+x): грудная клетка ближе к голове,
    #     живот ближе к тазу; печень — справа от пациента (-y), желудок и сердце — слева (+y) ---
    wd = shape.get("wound")
    if wd:
        rnd = random.Random(shape.get("wseed", 1))
        big = wd == "blast"
        wcx = tx + (0.5 if big else -rx * 0.28)
        wrx, wry = (rx * 0.8, ry * 0.74) if big else (rx * 0.55, ry * 0.42)
        # рваный край кожи и мяса
        n = 16
        rim = []
        for i in range(n):
            a_ = i * math.tau / n
            k_ = 1.0 + rnd.uniform(-0.2, 0.22)
            rim.append((wcx + math.cos(a_) * (wrx + 1.7) * k_, math.sin(a_) * (wry + 1.7) * k_))
        P.poly(rim, (96, 12, 14), (60, 6, 8), 0.5)
        cav = [(wcx + (p[0] - wcx) * 0.88, p[1] * 0.88) for p in rim]
        P.poly([(wcx + (p[0] - wcx) * 0.8, p[1] * 0.8) for p in rim], (52, 4, 6))

        if big:
            ch = wcx + wrx * 0.42       # центр груди
            ab = wcx - wrx * 0.45       # центр живота
            # лёгкие — два рыхлых серо-розовых крыла по бокам от средостения
            for sgn in (-1, 1):
                P.ellipse(ch, sgn * wry * 0.46, wrx * 0.36, wry * 0.34, (104, 58, 64), (60, 22, 28), 0.5, rot=sgn * 0.25)
                P.ellipse(ch + 0.4, sgn * wry * 0.46, wrx * 0.22, wry * 0.2, (128, 80, 86), rot=sgn * 0.25)
            # сердце — по центру, чуть влево от пациента, острой верхушкой к тазу
            P.poly([(ch + wrx * 0.12, wry * 0.02), (ch - wrx * 0.1, wry * 0.3), (ch - wrx * 0.2, wry * 0.14),
                    (ch + wrx * 0.04, -wry * 0.16)], (128, 22, 28), (72, 8, 12), 0.5)
            P.line((ch + wrx * 0.12, -wry * 0.04), (ch + wrx * 0.3, -wry * 0.1), 0.9, (150, 70, 90))   # аорта
            # диафрагма — тёмная полоса между грудью и животом
            P.line((wcx - wrx * 0.06, -wry * 0.8), (wcx - wrx * 0.06, wry * 0.8), 1.0, (96, 40, 40))
            # печень справа, желудок слева, кишечник по центру
            P.poly([(ab + wrx * 0.12, -wry * 0.78), (ab - wrx * 0.34, -wry * 0.62), (ab - wrx * 0.36, -wry * 0.14),
                    (ab + wrx * 0.1, -wry * 0.1)], (82, 28, 24), (44, 12, 12), 0.5)
            P.ellipse(ab, wry * 0.5, wrx * 0.26, wry * 0.28, (124, 86, 78), (80, 44, 42), 0.5, rot=0.4)
            for k in range(4):
                P.circle(ab - wrx * 0.28 + k * wrx * 0.14, ((-1) ** k) * wry * 0.14, wry * 0.15,
                         (142, 92, 86), (86, 40, 42), 0.4)
            # сломанные рёбра: обломки торчат от края раны внутрь, не параллельно и не ровно
            # (у маленьких зомби — детей — рёбер и грудины в ране нет: они мелкие и хрящевые)
            for sgn in (-1, 1) if scale >= 0.85 else ():
                for k in range(4):
                    if rnd.random() < 0.2:
                        continue
                    a_ = (0.25 + k * 0.3) * (1 if sgn > 0 else 1)
                    ex = wcx + wrx * (0.15 + 0.25 * k) + rnd.uniform(-0.5, 0.5)
                    ey = sgn * (wry * (0.98 - 0.06 * k))
                    ln = rnd.uniform(1.8, 3.4)
                    P.line((ex, ey), (ex - ln * 0.5 + rnd.uniform(-0.3, 0.3), ey - sgn * ln), 0.8, (206, 192, 168))
            # грудина: два обломка по средней линии
            if scale >= 0.85:
                P.line((wcx + wrx * 0.3, 0.0), (wcx + wrx * 0.55, 0.0), 0.9, (206, 192, 168))
                P.line((wcx + wrx * 0.62, 0.1), (wcx + wrx * 0.76, 0.0), 0.8, (196, 182, 158))
        else:
            # распоротый живот: жировой слой, петли тонкого кишечника, никаких рёбер и грудных органов
            P.ellipse(wcx, 0, wrx * 0.95, wry * 0.8, (74, 10, 12), rot=0.0)
            P.ellipse(wcx, 0, wrx * 0.95, wry * 0.8, (170, 130, 78), ring=0.9)
            for k in range(5):
                ox = wcx - wrx * 0.55 + k * wrx * 0.28
                P.circle(ox, ((-1) ** k) * wry * 0.2, wry * 0.5, (140, 90, 84), (86, 40, 42), 0.5)
                P.circle(ox + 0.4, ((-1) ** k) * wry * 0.2 - 0.3, wry * 0.18, (176, 128, 120))
            # кишки не выпадают, а торчат из разреза и свисают на землю, оставаясь частью тела
            side = shape.get("gut_side", 1)
            gx, gy = wcx - wrx * 0.1, side * wry * 0.55
            pts = [(gx, gy)]
            for j in range(1, 7):
                pts.append((gx - 1.8 * j + math.sin(j * 1.9 + shape["wseed"]) * 1.6,
                            gy + side * (1.7 * j + 0.5 * math.sin(j * 1.3))))
            for a_, b_ in zip(pts, pts[1:]):
                P.line(a_, b_, 3.3, (88, 34, 40))
            for a_, b_ in zip(pts, pts[1:]):
                P.line(a_, b_, 2.3, (160, 104, 100))
            for a_, b_ in zip(pts, pts[1:]):
                P.line((a_[0] + 0.3, a_[1] - 0.2), (b_[0] + 0.3, b_[1] - 0.2), 0.7, (206, 160, 152))
            P.circle(pts[-1][0], pts[-1][1], 1.9, (120, 60, 64), (70, 24, 28), 0.4)
        # кровь поверх органов: тёмные разводы без прозрачности (спрайт с альфой, наложение не годится)
        for k in range(3):
            P.ellipse(wcx + rnd.uniform(-wrx * 0.5, wrx * 0.5), rnd.uniform(-wry * 0.5, wry * 0.5),
                      wrx * 0.2, wry * 0.14, (92, 6, 8), rot=rnd.uniform(0, 3))
        for k in range(5):
            a_ = k * 1.3 + 0.5
            P.circle(wcx + math.cos(a_) * (wrx + 2.0), math.sin(a_) * (wry + 2.0), 0.9, (126, 12, 14))

    # --- голова ---
    hx = _lerp(9.5 + sw * 0.6 + 4.5 * attack, 17, pose)
    hy = shape["head_y"] * pose + math.sin(walk * 0.5) * 1.2 * (1 - pose)
    if limbs["head"]:
        tilt = shape["head_tilt"] * pose
        P.ellipse(hx, hy, 7.2, 6.9, skin, edge, 1.0, rot=tilt)
        P.ellipse(hx - 1.5, hy - 1.6, 4.3, 4.1, shade(skin, 1.15), rot=tilt)
        if style.get("raider"):
            P.line((hx + 1, hy - 3), (hx + 1.6, hy - 2.2), 1.0, (40, 25, 20))
            P.line((hx + 1, hy + 3), (hx + 1.6, hy + 2.2), 1.0, (40, 25, 20))
        elif pose < 0.5:
            # живое лицо: горящие красные глаза и оскал
            for ey in (-2.7, 2.7):
                P.circle(hx + 2.0, hy + ey, 1.9, (16, 10, 10))
                P.circle(hx + 2.4, hy + ey, 1.0, (255, 60, 20))
            if jaw == "gone":
                P.ellipse(hx + 4.5, hy + 1.0, 3.2, 3.0, (58, 0, 0), (20, 0, 0), 0.6)
                P.ellipse(hx + 4.5, hy + 1.0, 1.8, 1.5, (112, 8, 10))
                for ty in (-1.5, -0.2, 1.2):
                    P.line((hx + 3.2, hy + ty), (hx + 5.8, hy + ty), 0.6, (225, 225, 200))
                P.line((hx + 4.0, hy + 3.2), (hx + 4.0, hy + 5.2), 0.8, (120, 8, 10))
            elif jaw == "broken":
                P.ellipse(hx + 4.7, hy + 1.0, 2.4, 2.2, (55, 0, 0), (25, 0, 0), 0.5)
                P.poly([(hx + 2.6, hy + 2.8), (hx + 6.6, hy + 3.2), (hx + 5.8, hy + 8.8),
                        (hx + 3.0, hy + 7.6)], skin, edge, 0.8)
                P.line((hx + 3.4, hy + 3.6), (hx + 5.9, hy + 3.8), 0.7, (235, 235, 210))
                P.circle(hx + 4.6, hy + 7.2, 0.7, (120, 10, 12))
                P.line((hx + 4.4, hy + 8.2), (hx + 4.4, hy + 10.0), 0.7, (120, 10, 12))
            elif attack > 0.15:   # пасть раскрыта
                P.ellipse(hx + 4.6, hy, 1.4 + 2.2 * attack, 1.6 + 2.6 * attack, (70, 0, 0), (30, 0, 0), 0.5)
                for ty in (-1.6, 1.6):
                    P.line((hx + 3.6, hy + ty * attack * 1.4), (hx + 5.4, hy + ty * attack * 1.4), 0.8, (235, 235, 210))
            else:
                P.line((hx + 4.6, hy - 2.2), (hx + 4.6, hy + 2.2), 1.2, (50, 12, 12))
                for ty in (-1.2, 0.0, 1.2):
                    P.line((hx + 4.2, hy + ty), (hx + 5.2, hy + ty), 0.5, (225, 225, 200))
        else:
            for ey in (-2.7, 2.7):
                P.circle(hx + 2.0, hy + ey, 1.7, (14, 14, 14))
            if jaw == "gone":
                P.ellipse(hx + 4.2, hy + 0.3, 2.3, 2.0, (58, 0, 0), (25, 0, 0), 0.5)
            elif jaw == "broken":
                P.poly([(hx + 3.0, hy + 2.2), (hx + 5.8, hy + 2.5), (hx + 5.0, hy + 6.6),
                        (hx + 3.5, hy + 6.0)], skin, edge, 0.7)
                P.line((hx + 3.7, hy + 2.6), (hx + 5.4, hy + 2.8), 0.8, shade(skin, 0.45))
            else:
                P.line((hx + 4.4, hy - 1.8), (hx + 4.4, hy + 1.8), 1.1, shade(skin, 0.4))
        if shape["blood"]:
            P.ellipse(hx - 1, hy + 2.6, 2.6, 1.8, BLOOD)
    else:
        P.circle(hx - 0.5, 0, 4.4, BLOOD, BLOOD_D)
        P.ellipse(hx + 3.5, 0.5, 6.5, 3.4, BLOOD)
        P.ellipse(hx + 4, 0.5, 3.2, 1.7, BLOOD_D)
        P.circle(hx + 0.5, 0, 1.1, (224, 214, 194))

    # --- шляпа бандита ---
    if shape["raider"]:
        if pose < 0.15 and limbs["head"]:
            P.ellipse(hx - 1, hy, 12, 11, (30, 28, 28), (10, 10, 10), 0.8)
            P.ellipse(hx - 1, hy, 6.2, 5.6, (46, 42, 42), (12, 12, 12), 0.8)
        else:
            hat_x, hat_y = _lerp(hx, shape["hat_dx"] + 6, pose), _lerp(hy, shape["hat_dy"], pose)
            rot = shape["hat_rot"] * pose
            P.ellipse(hat_x, hat_y, 11, 8.5, (30, 28, 28), (10, 10, 10), 0.8, rot=rot)
            P.ellipse(hat_x, hat_y, 5.8, 5.2, (46, 42, 42), (12, 12, 12), 0.8, rot=rot)
            P.ellipse(hat_x, hat_y, 5.8, 5.2, (150, 40, 40), rot=rot, ring=0.9)

    return P.result()


class Corpse:
    def __init__(self, x, y, facing, hit_angle, dmg, skin, shirt, pants, limbs=None, raider=False, scale=1.0, jaw="normal", wound=None, launch=None):
        self.scale = scale
        self.x, self.y = x, y
        self.facing = facing
        self.style = {"skin": skin, "shirt": shirt, "pants": pants, "raider": raider}
        self.limbs = dict(limbs) if limbs else {k: True for k in ("head", "l_arm", "r_arm", "l_leg", "r_leg")}
        self.shape = _new_shape(raider)
        self.shape["wound"] = wound
        self.jaw = jaw

        # отброс по направлению удара: чем сильнее удар, тем дальше
        # отброс небольшой: от обычного выстрела тело лишь оседает, пила не отбрасывает вовсе
        sp = launch if launch is not None else 28.0 + min(dmg, 150) * 0.5
        self.vx, self.vy = math.cos(hit_angle) * sp, math.sin(hit_angle) * sp
        self.twist = random.choice((-1, 1)) * random.uniform(0.5, 1.6)

        self.t = 0.0
        self.life = 30.0
        self.trail = []
        self._last_trail = (x, y)
        pr = (17 + min(dmg, 160) * 0.07) * scale * (1.5 if wound else 1.0)
        self.pool_r = pr
        ss = 2                                  # рисуем в 2x и уменьшаем — края без «ступенек»
        big_sz = int(pr * 3) * ss
        c0 = big_sz / 2
        pts = []
        for i in range(30):
            a = i * math.tau / 30
            r = pr * ss * random.uniform(0.55, 1.05) * (1.0 + 0.3 * math.cos(a - hit_angle))
            pts.append((c0 + math.cos(a) * r, c0 + math.sin(a) * r))
        big = pygame.Surface((big_sz, big_sz), pygame.SRCALPHA)
        pygame.draw.polygon(big, (96, 6, 6), pts)
        pygame.draw.polygon(big, (70, 3, 3), [(c0 + (px - c0) * 0.62, c0 + (py - c0) * 0.62) for px, py in pts])
        self.pool = pygame.transform.smoothscale(big, (int(pr * 3), int(pr * 3)))
        self.sprite = None
        self.baked = False
        self.landed = False
        self.puffs = []

    # ---- состояние падения ----
    def _u(self):
        return max(0.0, min(1.0, (self.t - 0.05) / FALL_TIME))

    def update(self, dt):
        self.t += dt
        self.life -= dt
        k = math.exp(-(4.0 if self._u() < 0.7 else 7.5) * dt)
        self.x += self.vx * dt
        self.y += self.vy * dt
        if math.hypot(self.x - self._last_trail[0], self.y - self._last_trail[1]) > 6:
            self.trail.append((self.x, self.y))
            self._last_trail = (self.x, self.y)
        self.vx *= k
        self.vy *= k

        if not self.landed and self._u() >= 0.7:
            self.landed = True
            ang = math.atan2(self.vy, self.vx)
            for _ in range(6):
                a = ang + random.uniform(-1.6, 1.6)
                d = random.uniform(4, 16)
                self.puffs.append({"x": math.cos(a) * d, "y": math.sin(a) * d,
                                   "vx": math.cos(a) * 30, "vy": math.sin(a) * 30 - 8,
                                   "t": 0.0, "r": random.uniform(3, 6)})
        for p in self.puffs:
            p["t"] += dt
            p["x"] += p["vx"] * dt
            p["y"] += p["vy"] * dt
            p["vx"] *= 0.9
            p["vy"] *= 0.9
        self.puffs = [p for p in self.puffs if p["t"] < 0.55]

    def _sprite(self):
        u = self._u()
        if u >= 1.0 and self.baked:
            return self.sprite
        pose = _fall(u)
        ang = self.facing + self.twist * _smooth(u)
        self.sprite = render_body(self.style, self.limbs, self.shape, pose, ang, 0.0, self.scale, jaw=self.jaw)
        if u >= 1.0:
            self.baked = True
        return self.sprite

    def draw(self, surf, cx, cy):
        sx, sy = int(self.x - cx), int(self.y - cy)
        if not (-80 < sx < surf.get_width() + 80 and -80 < sy < surf.get_height() + 80):
            return
        u = self._u()
        pose = _fall(u)

        # лужа крови под телом растёт, за телом тянется кровавый след
        fade = max(0.0, min(1.0, self.life / 2.5))
        n = len(self.trail)
        for i in range(1, n):
            ax, ay = self.trail[i - 1]
            bx, by = self.trail[i]
            ww = max(2, int(self.pool_r * 0.34 * (0.35 + 0.65 * i / max(1, n))))
            pygame.draw.line(surf, (88, 4, 4), (int(ax - cx), int(ay - cy)), (int(bx - cx), int(by - cy)), ww)
            pygame.draw.line(surf, (66, 2, 3), (int(ax - cx), int(ay - cy)), (int(bx - cx), int(by - cy)), max(1, ww // 3))
        g = max(0.0, min(1.0, (self.t - 0.1) / 3.0))
        g = 1 - (1 - g) ** 3
        if g > 0.02:
            w = max(2, int(self.pool.get_width() * (0.25 + 0.75 * g)))
            pool = pygame.transform.smoothscale(self.pool, (w, w))
            if fade < 1.0:
                pool.set_alpha(int(255 * fade))
            surf.blit(pool, (sx - w // 2, sy - w // 2))

        spr = self._sprite()
        hop = 2.5 * math.sin(math.pi * min(1.0, max(0.0, (u - 0.7) / 0.3))) if u < 1.0 else 0.0
        fade = self.life < 2.5
        if fade:
            spr.set_alpha(int(255 * max(0.0, self.life) / 2.5))
        surf.blit(spr, (sx - CANVAS // 2, int(sy - CANVAS // 2 - hop)))

        for p in self.puffs:
            k = p["t"] / 0.55
            r = int(p["r"] * (1 + 1.6 * k))
            a = int(110 * (1 - k))
            s = pygame.Surface((r * 2 + 2, r * 2 + 2), pygame.SRCALPHA)
            pygame.draw.circle(s, (226, 200, 154, a), (r + 1, r + 1), r)
            surf.blit(s, (sx + p["x"] - r, sy + p["y"] - r))
