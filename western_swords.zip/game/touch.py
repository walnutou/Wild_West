"""Сенсорное управление: левый стик — движение, правый — прицел и автоогонь,
кнопки: БЕГ, УДАР, R, ВЗЯТЬ, пауза. Стики плавающие — появляются там, где коснулся палец."""
import math
import pygame
from .config import WIDTH, HEIGHT, TOUCH
from .utils import text

STICK_R = 92


def _near(px, py, cx, cy, r):
    return (px - cx) ** 2 + (py - cy) ** 2 <= r * r


class Touch:
    def __init__(self):
        self.enabled = TOUCH
        self.fingers = {}               # id -> {"role", "ox","oy","x","y", "btn"}
        self.move = (0.0, 0.0)
        self.aim_vec = (0.0, 0.0)
        self.last_dir = (1.0, 0.0)
        self.fire = False
        self.melee = False
        self.sprint = False
        self.events = []                # одноразовые: "reload", "interact", "pause"
        self.near_crate = False
        self.has_light = True
        self._pulse = {}

    # ---------------------------------------------------------------- раскладка
    def buttons(self):
        W, H = WIDTH, HEIGHT
        b = [
            {"id": "melee", "cx": W - 92, "cy": H - 238, "r": 50, "label": "УДАР", "hold": True},
            {"id": "reload", "cx": W - 92, "cy": H - 362, "r": 40, "label": "R"},
            {"id": "sprint", "cx": 96, "cy": H - 346, "r": 44, "label": "БЕГ", "toggle": True},
            {"id": "pause", "cx": W // 2, "cy": 38, "r": 26, "label": "II"},
        ]
        if self.has_light:
            b.append({"id": "light", "cx": 96, "cy": H - 470, "r": 40, "label": "СВЕТ"})
        if self.near_crate:
            b.append({"id": "interact", "cx": W - 92, "cy": H - 470, "r": 42, "label": "ВЗЯТЬ"})
        return b

    # ---------------------------------------------------------------- события
    def handle(self, e, state_playing):
        """Принимает FINGER*-события (и эмулированные мышью). Возвращает True, если событие поглощено."""
        if not self.enabled:
            return False
        if e.type == pygame.FINGERDOWN:
            return self._down(e.finger_id, e.x * WIDTH, e.y * HEIGHT, state_playing)
        if e.type == pygame.FINGERMOTION:
            return self._motion(e.finger_id, e.x * WIDTH, e.y * HEIGHT)
        if e.type == pygame.FINGERUP:
            return self._up(e.finger_id)
        return False

    def emulate_mouse(self, e, state_playing):
        """Для проверки на ПК: мышь изображает палец (ZV_TOUCH=1)."""
        if e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
            return self._down("mouse", e.pos[0], e.pos[1], state_playing)
        if e.type == pygame.MOUSEMOTION and "mouse" in self.fingers:
            return self._motion("mouse", e.pos[0], e.pos[1])
        if e.type == pygame.MOUSEBUTTONUP and e.button == 1:
            return self._up("mouse")
        return False

    def _down(self, fid, x, y, playing):
        if not playing:
            return False
        for b in self.buttons():
            if _near(x, y, b["cx"], b["cy"], b["r"] + 8):
                self.fingers[fid] = {"role": "btn", "btn": b["id"], "x": x, "y": y}
                if b.get("toggle"):
                    self.sprint = not self.sprint
                elif b.get("hold"):
                    self.melee = True
                else:
                    self.events.append(b["id"])
                self._pulse[b["id"]] = 0.18
                return True
        role = "move" if x < WIDTH * 0.5 else "aim"
        if any(f["role"] == role for f in self.fingers.values()):
            role = "aim" if role == "move" else "move"
            if any(f["role"] == role for f in self.fingers.values()):
                return True
        self.fingers[fid] = {"role": role, "ox": x, "oy": y, "x": x, "y": y}
        return True

    def _motion(self, fid, x, y):
        f = self.fingers.get(fid)
        if not f:
            return False
        f["x"], f["y"] = x, y
        if f["role"] in ("move", "aim"):
            dx, dy = x - f["ox"], y - f["oy"]
            d = math.hypot(dx, dy)
            if d > STICK_R:      # база стика тянется за пальцем — не нужно возвращаться в центр
                f["ox"] += dx / d * (d - STICK_R)
                f["oy"] += dy / d * (d - STICK_R)
        return True

    def _up(self, fid):
        f = self.fingers.pop(fid, None)
        if not f:
            return False
        if f["role"] == "btn" and f["btn"] == "melee":
            self.melee = False
        return True

    def release_all(self):
        self.fingers.clear()
        self.melee = False
        self.sprint = False
        self.fire = False
        self.move = (0.0, 0.0)
        self.aim_vec = (0.0, 0.0)

    # ---------------------------------------------------------------- состояние
    def update(self, dt):
        self.move = (0.0, 0.0)
        self.aim_vec = (0.0, 0.0)
        self.fire = False
        for f in self.fingers.values():
            if f["role"] not in ("move", "aim"):
                continue
            dx, dy = f["x"] - f["ox"], f["y"] - f["oy"]
            d = math.hypot(dx, dy)
            mag = min(1.0, d / STICK_R)
            vec = (dx / d * mag, dy / d * mag) if d > 1 else (0.0, 0.0)
            if f["role"] == "move":
                self.move = vec if mag > 0.18 else (0.0, 0.0)
            else:
                if mag > 0.22:
                    self.aim_vec = vec
                    self.last_dir = (vec[0] / mag, vec[1] / mag)
                    self.fire = True
        if self.move == (0.0, 0.0):
            self.sprint = False           # остановился — бег выключается
        for k in list(self._pulse):
            self._pulse[k] -= dt
            if self._pulse[k] <= 0:
                del self._pulse[k]

    def aim_point(self, game):
        """Точка прицеливания в экранных координатах (с лёгкой помощью: липнет к зомби в створе)."""
        p = game.player
        sx, sy = p.x - game.camera.x, p.y - game.camera.y
        ax, ay = self.last_dir
        ang = math.atan2(ay, ax)
        best, best_d = None, 0.2
        for z in list(game.zombies) + list(game.raiders):
            dx, dy = z.x - p.x, z.y - p.y
            dist = math.hypot(dx, dy)
            if dist < 30 or dist > 900:
                continue
            da = abs((math.atan2(dy, dx) - ang + math.pi) % math.tau - math.pi)
            if da < best_d:
                best, best_d = z, da
        if best is not None and self.fire:
            return (best.x - game.camera.x, best.y - game.camera.y)
        return (sx + ax * 260, sy + ay * 260)

    # ---------------------------------------------------------------- рисование
    def draw(self, surf, game):
        if not self.enabled:
            return
        ov = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        for f in self.fingers.values():
            if f["role"] in ("move", "aim"):
                col = (255, 255, 255) if f["role"] == "move" else (255, 120, 90)
                pygame.draw.circle(ov, (*col, 40), (int(f["ox"]), int(f["oy"])), STICK_R)
                pygame.draw.circle(ov, (*col, 110), (int(f["ox"]), int(f["oy"])), STICK_R, 3)
                dx, dy = f["x"] - f["ox"], f["y"] - f["oy"]
                d = math.hypot(dx, dy)
                if d > STICK_R:
                    dx, dy = dx / d * STICK_R, dy / d * STICK_R
                pygame.draw.circle(ov, (*col, 150), (int(f["ox"] + dx), int(f["oy"] + dy)), 36)
        # подсказки, где «брать» стики, пока пальцы не на экране
        roles = {f["role"] for f in self.fingers.values()}
        if "move" not in roles:
            pygame.draw.circle(ov, (255, 255, 255, 16), (150, HEIGHT - 140), STICK_R)
            pygame.draw.circle(ov, (255, 255, 255, 70), (150, HEIGHT - 140), STICK_R, 2)
        if "aim" not in roles:
            pygame.draw.circle(ov, (255, 120, 90, 16), (WIDTH - 280, HEIGHT - 140), STICK_R)
            pygame.draw.circle(ov, (255, 120, 90, 70), (WIDTH - 280, HEIGHT - 140), STICK_R, 2)
        for b in self.buttons():
            on = (b["id"] == "sprint" and self.sprint) or (b["id"] == "melee" and self.melee) or (b["id"] == "light" and game.flash_on) or b["id"] in self._pulse
            fill = (230, 190, 90, 150) if on else (30, 22, 14, 120)
            pygame.draw.circle(ov, fill, (b["cx"], b["cy"]), b["r"])
            pygame.draw.circle(ov, (250, 226, 180, 190), (b["cx"], b["cy"]), b["r"], 3)
        surf.blit(ov, (0, 0))
        for b in self.buttons():
            size = "md" if len(b["label"]) <= 2 else "sm"
            text(surf, b["label"], size, b["cx"], b["cy"], (255, 240, 200), center=True)
