import math, random
from pathlib import Path
import pygame
from .config import WIDTH, HEIGHT, PLAYER_SPEED, PLAYER_RADIUS, PLAYER_MAX_HP, SAND_D, WORLD_W, WORLD_H, WEAPONS, MELEE_WEAPONS, KICK
from .utils import clamp
from .bullet import Bullet
from .gfx import Painter, shade
from . import sounds, decor

# Где держим оружие (локальная ось X смотрит вперёд) и где лежат кисти — подобрано под модели
GUN_GX = {"pistol": 30, "revolver": 30, "smg": 22, "shotgun": 16, "sawnoff": 26, "sniper": 14}
# (x правой кисти относительно gx, y правой, y левой)
GUN_GRIP = {"smg": (3.0, 2.0, -1.4), "shotgun": (-3.0, 2.2, -1.2), "sawnoff": (-3.5, 2.0, -1.2),
            "sniper": (-3.0, 2.2, -1.2)}

_AXE_SIDE = None
GUN_LEN = {"pistol": 28, "revolver": 34, "smg": 47, "shotgun": 55, "sawnoff": 33, "sniper": 61}


def _load_axe_side():
    global _AXE_SIDE
    if _AXE_SIDE is None:
        path = Path(__file__).resolve().parent.parent / "assets" / "weapons" / "axe_side.png"
        try:
            _AXE_SIDE = pygame.image.load(str(path)).convert_alpha()
        except Exception:
            _AXE_SIDE = False
    return _AXE_SIDE or None


class Player:
    def __init__(self):
        self.x = WORLD_W // 2
        self.y = WORLD_H // 2
        self.speed = PLAYER_SPEED
        self.radius = PLAYER_RADIUS
        self.hp = PLAYER_MAX_HP
        self.max_hp = PLAYER_MAX_HP
        self.armor = 0
        self.max_armor = 100
        self.stamina = 100.0
        self.max_stamina = 100.0
        self.exhausted = False
        
        self.is_moving = False
        self.is_sprinting = False
        self.still_time = 0.0
        self.shot_noise = None
        self.move_angle = 0.0
        self.blood_charge = 0.0
        self.hat_blood = []
        
        self.active_gun = "pistol"
        self.active_melee = None          # по умолчанию без оружия — бьёт ногой
        self.dmg_mult = 1.0
        self.rate_mult = 1.0
        self.reload_mult = 1.0
        self.mag_mult = 1.0
        self.melee_dmg_mult = 1.0
        self.melee_rate_mult = 1.0
        self.melee_reach_mult = 1.0
        self.stam_regen_mult = 1.0
        self.weapon = self._make_weapon(self.active_gun)
        self.melee_weapon = None
        self.kick_timer = 0.0
        self.kick_total = KICK["rate"]
        self.kick_hit_done = True
        self.kick_angle = 0.0
        self.kick_side = 1
        self.stam_delay = 0.0
        
        self.shoot_timer = 0.0
        self.recoil = 0.0
        self.muzzle_flash = 0.0
        
        self.melee_timer = 0.0
        self.melee_angle = 0.0
        self.melee_hit_done = True
        self.chainsaw_spin = 0.0
        self.chainsaw_time = 0.0
        self.saw_blood = 0.0       # кровь на цепи
        self.walk_phase = 0.0
        self.swing_dir = 1
        self.foot_side = 1
        self.ammo = self.weapon["mag"]
        self.reload_t = 0.0
        self.solids = []          # здания — чтобы оружие не торчало сквозь стены
        self.wall_allow = 999.0   # сколько места у ствола до стены (сглаженно)
        self.noise_run = False
        self.gun_hidden = False   # режим «Мясник»: огнестрела нет

    def update_clearance(self, dt, aim):
        """Свободное место перед игроком. Приближаясь к стене, оружие убирается мгновенно,
        отпуская стену — возвращается плавно."""
        d = decor.ray_wall_dist(self.x, self.y, aim, 120.0, self.solids)
        if d < self.wall_allow:
            self.wall_allow = d
        else:
            self.wall_allow = min(d, self.wall_allow + dt * 420.0)

    def update(self, dt, keys, analog=None):
        mx, my = 0, 0
        if pygame.K_a in keys or pygame.K_LEFT in keys: mx -= 1
        if pygame.K_d in keys or pygame.K_RIGHT in keys: mx += 1
        if pygame.K_w in keys or pygame.K_UP in keys: my -= 1
        if pygame.K_s in keys or pygame.K_DOWN in keys: my += 1
        if analog is not None:
            mx, my = analog          # сенсорный стик: любое направление, не только 8
        
        self.is_moving = (mx != 0 or my != 0)
        if self.is_moving:
            self.still_time = 0.0
        else:
            self.still_time += dt
        
        sprint_key = pygame.K_LSHIFT in keys or pygame.K_RSHIFT in keys
        if self.stamina <= 0: self.exhausted = True
        elif self.stamina >= 30: self.exhausted = False
            
        self.is_sprinting = sprint_key and self.is_moving and not self.exhausted
        
        current_speed = self.speed
        if self.is_sprinting:
            current_speed *= 1.6 
            self.stamina -= 35 * dt 
            if self.stamina < 0: self.stamina = 0
        else:
            if self.stam_delay > 0:
                self.stam_delay -= dt
            else:
                self.stamina += 20 * dt * self.stam_regen_mult
            if self.stamina > self.max_stamina: self.stamina = self.max_stamina

        if self.is_moving:
            l = (mx * mx + my * my) ** 0.5
            mx, my = mx / l, my / l
            self.move_angle = math.atan2(my, mx)
            self.walk_phase += dt * (16.0 if self.is_sprinting else 11.0)
            
        self.x = clamp(self.x + mx * current_speed * dt, 20, WORLD_W - 20)
        self.y = clamp(self.y + my * current_speed * dt, 20, WORLD_H - 20)
        
        if self.shoot_timer > 0: self.shoot_timer -= dt
        if self.recoil > 0: self.recoil -= dt * 10
        if self.muzzle_flash > 0: self.muzzle_flash -= dt
        if self.melee_timer > 0: self.melee_timer -= dt
        if self.kick_timer > 0: self.kick_timer -= dt
        if self.reload_t > 0:
            self.reload_t -= dt
            if self.reload_t <= 0:
                self.reload_t = 0.0
                self.ammo = self.weapon["mag"]
                sounds.play("cock" if self.active_gun in ("shotgun", "sawnoff") else "reload_end", 0.5)

        for hb in self.hat_blood:
            hb["life"] -= dt
        self.hat_blood = [hb for hb in self.hat_blood if hb["life"] > 0]

    def take_damage(self, dmg):
        """Броня поглощает половину урона, пока не закончится."""
        if dmg <= 0: return 0
        if self.armor > 0:
            absorbed = min(self.armor, dmg * 0.5)
            self.armor -= absorbed
            dmg -= absorbed
        self.hp -= dmg
        return dmg

    def add_hat_blood(self, angle):
        dist = random.uniform(2.0, 10.0)
        ox = math.cos(angle + math.pi) * dist + random.uniform(-2.5, 2.5)
        oy = math.sin(angle + math.pi) * dist + random.uniform(-2.5, 2.5)
        r = random.uniform(2.0, 4.6)
        # неровный контур капли
        n = random.randint(7, 10)
        shape = []
        for i in range(n):
            a = i * math.tau / n
            rr = r * random.uniform(0.62, 1.18)
            shape.append((math.cos(a) * rr, math.sin(a) * rr))
        # мелкие брызги вокруг
        sats = []
        for _ in range(random.randint(2, 5)):
            a = random.uniform(0, math.tau)
            d = r * random.uniform(0.9, 2.4)
            sats.append((math.cos(a) * d, math.sin(a) * d, random.uniform(0.45, 1.3)))
        # потечные дорожки к полям шляпы
        base_a = math.atan2(oy, ox)
        drips = []
        for _ in range(random.randint(1, 2)):
            a = base_a + random.uniform(-0.4, 0.4)
            drips.append((math.cos(a), math.sin(a), random.uniform(2.5, 7.0)))
        self.hat_blood.append({"ox": ox, "oy": oy, "r": r, "shape": shape,
                               "sats": sats, "drips": drips, "life": 45.0})
        if len(self.hat_blood) > 40:
            self.hat_blood.pop(0)

    def shoot(self, target_x, target_y, bullets_list, blood_sys, shells=None):
        if self.shoot_timer > 0 or self.reload_t > 0 or self.melee_timer > 0 or self.kick_timer > 0: return
        if self.ammo <= 0:
            sounds.play("empty", 0.5)
            self.start_reload()
            return
        self.ammo -= 1
        self.still_time = 0.0
        sounds.play(self.active_gun, 0.65)
        sounds.play("shell", 0.18)
        self.shoot_timer = self.weapon["rate"]
        self.recoil = 1.0
        self.muzzle_flash = 0.05
        
        base_angle = math.atan2(target_y - self.y, target_x - self.x)
        free = decor.ray_wall_dist(self.x, self.y, base_angle, 44.0, self.solids)
        mdist = max(4.0, min(40.0, free - 2.0))   # пуля рождается перед стеной, а не за ней
        sx = self.x + math.cos(base_angle) * mdist
        sy = self.y + math.sin(base_angle) * mdist
        self.shot_noise = (sx, sy, 2200.0 if self.active_gun in ("sniper", "shotgun", "revolver") else 1800.0)
        
        for _ in range(self.weapon["count"]):
            angle = base_angle + random.uniform(-self.weapon["spread"], self.weapon["spread"])
            b = Bullet(sx, sy, angle, self.weapon["speed"], self.weapon["dmg"], self.weapon["pierce"], self.weapon["color"])
            b.weapon_key = self.active_gun
            bullets_list.append(b)
        if shells is not None:
            side = base_angle + math.pi * 0.5
            gx = self.x + math.cos(base_angle) * 10 + math.cos(side) * random.uniform(10, 18)
            gy = self.y + math.sin(base_angle) * 10 + math.sin(side) * random.uniform(10, 18)
            shells.append({"x": gx, "y": gy, "z": random.uniform(8, 14),
                           "vx": math.cos(side) * random.uniform(45, 95) + math.cos(base_angle) * random.uniform(5, 35),
                           "vy": math.sin(side) * random.uniform(45, 95) + math.sin(base_angle) * random.uniform(5, 35),
                           "vz": random.uniform(45, 95), "rot": random.uniform(0, math.tau),
                           "spin": random.uniform(-18, 18), "life": 6.0})
            if len(shells) > 90:
                shells.pop(0)
        if self.ammo <= 0:
            self.start_reload()

    def start_reload(self):
        if self.reload_t > 0 or self.ammo >= self.weapon["mag"]: return
        self.reload_t = self.weapon["reload"]
        sounds.play("reload_start", 0.4)

    def update_chainsaw(self, dt, active):
        """Бензопила сначала заводится, потом начинает резать."""
        self.chainsaw_time += dt
        self.saw_blood = max(0.0, self.saw_blood - dt * 0.12)
        if self.active_melee != "chainsaw":
            self.chainsaw_spin = 0.0
            return
        target = 1.0 if active else 0.0
        if target > self.chainsaw_spin:
            self.chainsaw_spin = min(1.0, self.chainsaw_spin + dt * 0.9)
        else:
            self.chainsaw_spin = max(0.0, self.chainsaw_spin - dt * 3.0)

    def do_melee(self, target_x, target_y, blood_sys):
        if not self.melee_weapon or self.melee_timer > 0: return False
        self.melee_angle = math.atan2(target_y - self.y, target_x - self.x)
        if self.active_melee == "chainsaw":
            if self.chainsaw_spin < 0.65:
                return False
            self.melee_timer = self.melee_weapon["rate"]
            self.melee_hit_done = True
            return True
        self.melee_timer = self.melee_weapon["rate"]
        self.melee_hit_done = False
        self.swing_dir *= -1
        self.still_time = 0.0
        sounds.play("swing", 0.5)
        return True

    def do_kick(self, target_x, target_y):
        """Пинок: доступен без оружия ближнего боя, стоит выносливости."""
        if self.melee_weapon or self.kick_timer > 0 or self.reload_t > 0:
            return False
        if self.exhausted or self.stamina < KICK["cost"]:
            return False
        self.stamina -= KICK["cost"]
        self.stam_delay = 1.0
        if self.stamina <= 0:
            self.stamina = 0.0
        self.kick_angle = math.atan2(target_y - self.y, target_x - self.x)
        self.kick_timer = self.kick_total = KICK["rate"] * self.melee_rate_mult
        self.kick_hit_done = False
        self.kick_side *= -1
        self.still_time = 0.0
        sounds.play("swing", 0.5)
        return True

    def kick_hit_ready(self):
        if self.kick_timer <= 0 or self.kick_hit_done:
            return False
        if 1.0 - self.kick_timer / max(0.05, self.kick_total) >= 0.4:
            self.kick_hit_done = True
            return True
        return False

    def melee_hit_ready(self):
        if self.active_melee == "chainsaw" or self.melee_timer <= 0 or self.melee_hit_done:
            return False
        rate = max(0.05, self.melee_weapon["rate"])
        prog = 1.0 - max(0.0, self.melee_timer) / rate
        if prog >= 0.45:
            self.melee_hit_done = True
            return True
        return False

    def equip_gun(self, key):
        self.active_gun = key
        self.weapon = self._make_weapon(key)
        self.ammo = self.weapon["mag"]
        self.reload_t = 0.0

    def _make_weapon(self, key):
        w = WEAPONS[key].copy()
        w["dmg"] *= self.dmg_mult
        w["rate"] *= self.rate_mult
        w["reload"] *= self.reload_mult
        w["mag"] = max(1, int(round(w["mag"] * self.mag_mult)))
        return w

    def apply_upgrades(self):
        """Пересчитать текущее оружие после улучшений уровня."""
        base = WEAPONS[self.active_gun]
        self.weapon["dmg"] = base["dmg"] * self.dmg_mult
        self.weapon["rate"] = base["rate"] * self.rate_mult
        self.weapon["reload"] = base["reload"] * self.reload_mult
        new_mag = max(1, int(round(base["mag"] * self.mag_mult)))
        self.ammo += new_mag - self.weapon["mag"]
        self.weapon["mag"] = new_mag
        if self.melee_weapon:
            mb = MELEE_WEAPONS[self.active_melee]
            self.melee_weapon["dmg"] = mb["dmg"] * self.melee_dmg_mult
            self.melee_weapon["rate"] = mb["rate"] * self.melee_rate_mult
            self.melee_weapon["range"] = mb["range"] * self.melee_reach_mult

    def equip_melee(self, key):
        self.active_melee = key
        self.melee_weapon = MELEE_WEAPONS[key].copy()
        mb = MELEE_WEAPONS[key]
        self.melee_weapon["dmg"] = mb["dmg"] * self.melee_dmg_mult
        self.melee_weapon["rate"] = mb["rate"] * self.melee_rate_mult
        self.melee_weapon["range"] = mb["range"] * self.melee_reach_mult

    def add_weapon(self, key, is_melee=False):
        if is_melee: self.equip_melee(key)
        else: self.equip_gun(key)

    def draw(self, surf, cam_x, cam_y, target_x, target_y):
        x = int(self.x - cam_x)
        y = int(self.y - cam_y)
        angle = math.atan2(target_y - self.y, target_x - self.x)
        # 200px — чтобы длинный ствол и вспышка не обрезались по краю спрайта
        P = Painter(200, 2, angle)

        skin = (214, 160, 118)
        skin_d = (130, 84, 56)
        jeans, jeans_d = (40, 40, 52), (20, 20, 28)        # тёмные брюки
        boot, boot_d = (44, 34, 32), (14, 10, 10)          # начищенные туфли
        pon, pon_d = (234, 228, 212), (138, 132, 118)      # белая рубашка (рукава закатаны)
        cream = (196, 166, 110)

        mvx = mvy = 0.0
        if self.is_moving:
            d = self.move_angle - angle
            mvx, mvy = math.cos(d), math.sin(d)
        for side in (-1, 1):
            sw = math.sin(self.walk_phase + (0 if side < 0 else math.pi)) * 13
            fx = sw * mvx
            fy = side * 6.0 + sw * mvy
            if self.kick_timer > 0 and side == self.kick_side:
                kp = 1.0 - self.kick_timer / max(0.05, self.kick_total)
                ext = math.sin(math.pi * min(1.0, kp * 1.15)) * 26.0
                ka = self.kick_angle - angle
                fx = math.cos(ka) * (6.0 + ext)
                fy = side * 4.0 + math.sin(ka) * (6.0 + ext)
            hip = (0, side * 5.0)
            kicking = self.kick_timer > 0 and side == self.kick_side
            P.thick(hip, (fx, fy), 7.4 if kicking else 6.4, jeans, jeans_d)
            P.ellipse(fx - 1.5, fy, 7.2 if kicking else 5.6, 5.0 if kicking else 4.0, boot, boot_d, 0.9)
            P.circle(fx - 5.6 * (1 if mvx >= 0 else -1), fy, 1.1, (230, 200, 90))

        recoil = max(0.0, self.recoil) * 5
        reload_prog = 0.0
        if self.reload_t > 0:
            reload_prog = 1.0 - self.reload_t / max(0.01, self.weapon["reload"])
        reload_kick = 7.0 * math.sin(math.pi * max(0.0, min(1.0, reload_prog))) if self.reload_t > 0 else 0.0
        gx = GUN_GX[self.active_gun] - recoil - reload_kick
        # оружие у стены: сжимаем вдоль прицела и оттягиваем назад (как будто ствол поднят)
        muzzle = gx + GUN_LEN[self.active_gun]
        allow = self.wall_allow - 3.0
        gs, goff = 1.0, 0.0
        if muzzle > allow:
            gs = max(0.45, allow / muzzle)
            goff = max(-16.0, min(0.0, allow - muzzle * gs))
        tx = lambda v: max(8.0, v * gs + goff)
        
        # оружие рисуем ДО тела: шляпа/туловище перекрывают приклад, а не наоборот
        melee_visible = self.melee_timer > 0 or (
            self.active_melee == "chainsaw" and self.chainsaw_spin > 0.02)
        gun_hidden = (self.gun_hidden or self.kick_timer > 0) and not melee_visible
        glen = fore_x = 0
        if not melee_visible and not gun_hidden:
            P.xform(gs, goff)
            glen, fore_x = self._draw_gun(P, gx)
            P.xform(1.0, 0.0)

        # --- Jackal: белая рубашка, тёмные подтяжки крест-накрест, тёмные зачёсанные волосы, красные очки ---
        sus, sus_d = (58, 40, 38), (26, 16, 16)
        P.ellipse(-1.5, 0, 9.4, 18.6, pon, pon_d, 1.1)                      # плечи и спина
        P.ellipse(-3.0, -1.0, 6.6, 12.5, shade(pon, 1.05))                  # свет на спине
        P.poly([(-7.5, 15.5), (-10.5, 5), (-10.5, -5), (-7.5, -15.5), (-4.5, -15.5), (-7.5, -5), (-7.5, 5), (-4.5, 15.5)],
               shade(pon, 0.9))                                              # складки у пояса
        # подтяжки: две лямки с плеч сходятся в X на лопатках и уходят к поясу
        P.line((6.0, 9.0), (-9.0, -4.0), 2.0, sus, sus_d, 0.5) if False else None
        P.thick((5.5, 9.4), (-9.5, -4.2), 2.2, sus, sus_d)
        P.thick((5.5, -9.4), (-9.5, 4.2), 2.2, sus, sus_d)
        P.circle(-3.8, 0.0, 1.1, (150, 118, 80))                            # перекрестье
        # голова: волосы
        P.ellipse(1.5, 0, 7.8, 8.6, (36, 24, 20), (10, 6, 6), 1.0)
        P.ellipse(0.4, 0, 6.4, 7.0, (52, 36, 30))
        P.ellipse(3.6, 0, 4.6, 3.0, (78, 56, 44))                            # чёлка/начёс
        P.line((-3.0, -3.8), (4.5, -3.4), 0.7, (24, 16, 14))
        P.line((-3.0, 3.8), (4.5, 3.4), 0.7, (24, 16, 14))
        P.ellipse(1.4, -8.2, 1.6, 1.5, skin, skin_d, 0.6)                    # уши
        P.ellipse(1.4, 8.2, 1.6, 1.5, skin, skin_d, 0.6)
        P.ellipse(7.2, 0, 2.4, 6.4, skin, skin_d, 0.8)                       # лицо спереди
        # красные очки
        P.rect(7.6, -5.4, 3.0, 4.8, (206, 36, 46), (80, 10, 16), 0.7)
        P.rect(7.6, 0.6, 3.0, 4.8, (206, 36, 46), (80, 10, 16), 0.7)
        P.line((8.2, -4.6), (8.2, -2.0), 0.6, (255, 150, 150))
        P.line((8.2, 1.4), (8.2, 4.0), 0.6, (255, 150, 150))
        P.line((7.8, -0.2), (7.8, 0.2), 0.8, (60, 10, 12))
        P.line((10.4, 0), (11.2, 0), 1.0, (190, 130, 100))                   # нос

        for hb in self.hat_blood:
            hx = 0.5 + hb["ox"] * 0.6
            hy = hb["oy"] * 0.6
            age = 1.0 - min(1.0, hb["life"] / 45.0)  # 0 — свежая, 1 — засохшая
            r = int(122 - 36 * age)
            g = int(8 + 30 * age)
            b = int(8 + 22 * age)
            alpha = int(255 * min(1.0, hb["life"] / 2.0))
            col = (r, g, b, alpha)
            outline = (max(0, r - 54), max(0, g - 4), max(0, b - 4), alpha)
            sc = 0.9
            pts = [(hx + px * sc, hy + py * sc) for px, py in hb["shape"]]
            P.poly(pts, col, outline, 0.5)
            for sx, sy, sr in hb["sats"]:
                P.circle(hx + sx * sc, hy + sy * sc, sr, col)
            for dx, dy, dl in hb.get("drips", ()):
                P.line((hx, hy), (hx + dx * dl, hy + dy * dl), 1.3, col)
                P.circle(hx + dx * dl, hy + dy * dl, 1.0, col)
            if age < 0.45:
                P.circle(hx - 0.7, hy - 0.7, 0.7, (168, 46, 40, alpha))

        # руки и кисти — поверх тела и рукояти
        if gun_hidden:
            # руки опущены и согнуты, оружие в кулаках у пояса
            for sh_, hy_ in (((7.0, 10.0), 5.5), ((7.0, -10.0), -5.5)):
                self._draw_arm(P, sh_, (17.0, hy_), skin, skin_d, pon, pon_d)
                self._draw_fist(P, 17.0, hy_, skin, skin_d)
        elif not melee_visible:
            r_shoulder, l_shoulder = (7.0, 10.0), (7.0, -10.0)
            if self.active_gun in ("pistol", "revolver"):
                # Обе руки сходятся в одну хватку на рукояти
                hx_ = tx(gx)
                self._draw_arm(P, r_shoulder, (hx_ - 3.0, 3.8), skin, skin_d, pon, pon_d)
                self._draw_arm(P, l_shoulder, (hx_ - 3.2, -2.4), skin, skin_d, pon, pon_d)
                if self.reload_t > 0:
                    P.xform(gs, goff)
                    self._draw_reload(P, gx, reload_prog)
                    P.xform(1.0, 0.0)
                self._draw_grip_hands(P, hx_, skin, skin_d)
            else:
                rdx, ry, ly = GUN_GRIP.get(self.active_gun, (3.0, 2.0, -1.4))
                r_hand = (tx(gx + rdx), ry)
                if self.reload_t > 0:
                    # рука уходит к магазину/затвору
                    l_hand = (tx(gx + 7), 7.5)
                else:
                    l_hand = (tx(fore_x), ly)
                self._draw_arm(P, r_shoulder, r_hand, skin, skin_d, pon, pon_d)
                self._draw_arm(P, l_shoulder, l_hand, skin, skin_d, pon, pon_d)
                if self.reload_t > 0:
                    P.xform(gs, goff)
                    self._draw_reload(P, gx, reload_prog)
                    P.xform(1.0, 0.0)
                self._draw_fist(P, r_hand[0], r_hand[1], skin, skin_d)
                self._draw_fist(P, l_hand[0], l_hand[1], skin, skin_d)

            if self.muzzle_flash > 0:
                fx = (gx + glen) * gs + goff
                P.circle(fx + 5, 0, 11, (255, 170, 60, 70))
                P.poly([(fx, 0), (fx + 7, -9), (fx + 11, -2), (fx + 25, 0),
                        (fx + 11, 2), (fx + 7, 9)], (255, 185, 55))
                P.poly([(fx, 0), (fx + 5, -5), (fx + 8, -1.2), (fx + 17, 0),
                        (fx + 8, 1.2), (fx + 5, 5)], (255, 250, 210))

        spr = P.result()
        spr.fill((196, 196, 196, 255), special_flags=pygame.BLEND_RGBA_MULT)
        surf.blit(spr, spr.get_rect(center=(x, y)))

        if self.kick_timer > 0:
            # дуга замаха и «линии скорости» — пинок хорошо виден
            kp = 1.0 - self.kick_timer / max(0.05, self.kick_total)
            alpha = int(230 * math.sin(math.pi * min(1.0, kp * 1.1)))
            if alpha > 10:
                sw_s = pygame.Surface((140, 140), pygame.SRCALPHA)
                rad = 34 + 22 * math.sin(math.pi * min(1.0, kp * 1.15))
                ka = self.kick_angle
                for k_, (wd, col) in enumerate(((7, (255, 248, 226)), (3, (255, 255, 255)))):
                    a0 = ka - 0.95 + 0.25 * k_
                    a1 = ka + 0.95 - 0.25 * k_
                    pts = [(70 + math.cos(a0 + (a1 - a0) * i / 14) * rad,
                            70 + math.sin(a0 + (a1 - a0) * i / 14) * rad) for i in range(15)]
                    pygame.draw.lines(sw_s, (col[0], col[1], col[2], alpha // (1 + k_)), False, pts, wd)
                surf.blit(sw_s, sw_s.get_rect(center=(x, y)))

        if self.reload_t > 0:
            k = 1.0 - self.reload_t / max(0.01, self.weapon["reload"])
            pygame.draw.rect(surf, (40, 28, 18), (x - 22, y + 24, 44, 6), border_radius=3)
            pygame.draw.rect(surf, (240, 200, 90), (x - 22, y + 24, int(44 * k), 6), border_radius=3)

        # Рисуем оружие ближнего боя во время удара / работы бензопилы
        if melee_visible:
            self._draw_melee(surf, x, y, angle)

    def _draw_arm(self, P, shoulder, hand, skin, skin_d, sleeve, sleeve_d):
        """Плечо → локоть → кисть. Локоть сгибается наружу, длина звеньев фиксирована —
        рука не «резиновая», как бы близко или далеко ни была хватка."""
        L = 19.0
        dx, dy = hand[0] - shoulder[0], hand[1] - shoulder[1]
        dist = math.hypot(dx, dy) or 1.0
        reach = min(dist, 2 * L - 0.5)
        hx = shoulder[0] + dx / dist * reach
        hy = shoulder[1] + dy / dist * reach
        h = math.sqrt(max(0.0, L * L - (reach / 2) ** 2))
        h = min(h, 9.5) * 0.85
        nx, ny = -dy / dist, dx / dist
        side = 1.0 if shoulder[1] > 0 else -1.0
        if ny * side < 0:
            nx, ny = -nx, -ny
        ex = shoulder[0] + dx / dist * reach * 0.5 + nx * h
        ey = shoulder[1] + dy / dist * reach * 0.5 + ny * h
        P.circle(shoulder[0], shoulder[1], 4.0, sleeve, sleeve_d, 0.8)
        P.thick(shoulder, (ex, ey), 6.6, sleeve, sleeve_d)
        P.circle(ex, ey, 3.1, shade(sleeve, 1.05))
        P.thick((ex, ey), (hx, hy), 5.2, skin, skin_d)
        P.line((ex + (hx - ex) * 0.55, ey + (hy - ey) * 0.55 - 1.2),
               (hx - (hx - ex) * 0.1, hy - (hy - ey) * 0.1 - 1.2), 0.8, shade(skin, 1.12))

    def _draw_fist(self, P, hx, hy, skin, skin_d):
        """Кулак, обхватывающий оружие."""
        P.ellipse(hx, hy, 4.1, 3.6, skin, skin_d, 0.9)
        for k in range(3):
            yy = hy - 1.7 + k * 1.7
            P.line((hx - 2.6, yy), (hx + 2.5, yy + 0.3), 0.7, shade(skin, 0.78))
            P.circle(hx + 2.5, yy + 0.3, 0.75, shade(skin, 1.06))
        P.circle(hx - 1.8, hy - 2.2, 0.9, shade(skin, 1.1))

    def _draw_grip_hands(self, P, gx, skin, skin_d):
        """Обе кисти сомкнуты в одну хватку на рукояти пистолета/револьвера."""
        # левая (поддерживающая) кисть — позади и чуть выше
        P.ellipse(gx - 0.8, -2.6, 4.6, 4.2, shade(skin, 0.82), skin_d, 0.9)
        # правая — сверху, обхватывает рукоять
        P.ellipse(gx + 1.2, 2.2, 4.4, 4.6, skin, skin_d, 1.0)
        # пальцы правой руки
        for yy in (0.4, 2.0, 3.6):
            P.line((gx - 2.4, yy), (gx + 4.4, yy + 0.4), 0.9, shade(skin, 0.68))
            P.circle(gx + 4.5, yy + 0.4, 0.75, shade(skin, 1.06))
        # пальцы поддержки, лежащие поверх
        for yy in (-3.0, -1.6):
            P.line((gx - 4.0, yy), (gx + 2.6, yy + 0.4), 0.8, shade(skin, 0.7))
        # складка между кистями
        P.line((gx - 3.0, -0.8), (gx + 2.2, 1.2), 0.6, shade(skin, 0.6))
        # большой палец поддержки
        P.thick((gx - 3.2, -2.4), (gx + 1.8, 0.2), 1.6, shade(skin, 1.02), skin_d)
        P.circle(gx + 1.9, 0.3, 0.9, shade(skin, 1.1))
        # костяшки правой кисти
        P.circle(gx + 3.6, 4.4, 0.8, shade(skin, 1.12))
        P.circle(gx + 1.8, 5.0, 0.8, shade(skin, 1.08))

    def _draw_reload(self, P, gx, prog):
        """Магазин/спидлоадер/патрон/затвор в движении."""
        steel, steel_d, steel_l = (92, 98, 110), (36, 38, 46), (184, 192, 206)
        brass = (198, 158, 78)
        g = self.active_gun
        if g in ("pistol", "smg"):
            if prog < 0.5:
                my = 8 + prog * 30
                P.rect(gx + 4.0, my, 4.4, 9.0, steel_d, (18, 18, 22), 0.6)
                P.line((gx + 5.0, my + 1.0), (gx + 7.0, my + 1.0), 0.6, steel_l)
            else:
                my = 38 - (prog - 0.5) * 62
                P.rect(gx + 4.0, my, 4.4, 9.0, steel, steel_d, 0.6)
                P.line((gx + 5.0, my + 1.0), (gx + 7.0, my + 1.0), 0.6, steel_l)
        elif g == "revolver":
            y = -16 + min(0.5, prog) * 30
            P.circle(gx + 9.0, y, 5.2, steel_l, steel_d, 0.8)
            P.circle(gx + 9.0, y, 2.2, steel_d)
            for i in range(6):
                a = i * math.tau / 6 + prog * 5.0
                P.circle(gx + 9.0 + math.cos(a) * 3.1, y + math.sin(a) * 3.1, 0.7, brass)
        elif g in ("shotgun", "sawnoff"):
            y = -18 + min(1.0, prog * 1.4) * 22
            P.rect(gx + 13.0, y, 3.0, 7.0, (170, 50, 40), (60, 16, 12), 0.6)
            P.rect(gx + 13.0, y + 5.0, 3.0, 2.0, brass)
        else:  # sniper
            bx = gx + 8.0 - math.sin(math.pi * min(1.0, prog)) * 7.0
            P.circle(bx, 5.0, 2.0, steel_l, steel_d, 0.7)
            P.line((bx, 4.0), (bx + 6.0, 4.0), 1.4, steel_d)

    def _draw_gun(self, P, gx):
        g = self.active_gun
        steel, steel_d, steel_l = (92, 98, 110), (36, 38, 46), (184, 192, 206)
        wood, wood_d, wood_l = (136, 86, 44), (74, 42, 18), (192, 136, 76)
        brass, brass_d = (198, 158, 78), (116, 86, 34)
        dark = (22, 22, 26)

        if g == "pistol":
            # деревянная рукоять с латунной пяткой
            P.poly([(gx - 7, -3.0), (gx + 1.5, -3.0), (gx + 2.6, 5.2), (gx - 5.4, 5.2)], wood, wood_d, 0.9)
            P.poly([(gx - 6.0, -2.2), (gx - 0.6, -2.2), (gx + 0.4, 3.2), (gx - 4.9, 3.2)], wood_l)
            P.line((gx - 5.8, 3.4), (gx + 1.2, 3.4), 1.2, brass_d)
            # рамка, барабан и каморы
            P.rect(gx - 1.0, -4.2, 11.0, 8.4, steel_d)
            P.rect(gx - 0.4, -3.5, 9.8, 7.0, steel)
            P.ellipse(gx + 8.0, 0, 4.6, 5.0, steel_l, steel_d, 0.9)
            P.ellipse(gx + 8.0, 0, 3.0, 3.4, steel_d)
            for yy in (-2.2, 0.0, 2.2):
                P.circle(gx + 8.0, yy, 0.9, brass_d)
            # ствол
            P.rect(gx + 10.0, -2.5, 14.0, 5.0, steel, steel_d, 0.8)
            P.rect(gx + 10.4, -1.9, 12.6, 1.2, steel_l)
            P.rect(gx + 10.4, 1.6, 12.0, 1.1, steel_d)
            P.rect(gx + 24.0, -3.0, 2.6, 6.0, steel_d)
            P.circle(gx + 25.6, 0, 1.2, dark)
            # выбрасыватель, курок и мушка
            P.rect(gx + 10.4, 2.6, 9.0, 1.4, steel_d)
            P.poly([(gx - 0.6, -4.0), (gx + 2.4, -5.8), (gx + 3.2, -3.8)], steel_d)
            P.rect(gx + 21.0, -4.0, 1.4, 2.0, steel_d)
            return 28, gx + 8

        if g == "revolver":
            P.poly([(gx - 8, -3.4), (gx + 1, -3.4), (gx + 2.8, 6.0), (gx - 6.4, 6.0)], wood, wood_d, 0.9)
            P.poly([(gx - 7.0, -2.5), (gx - 1.0, -2.5), (gx + 0.2, 3.4), (gx - 5.8, 3.4)], wood_l)
            P.line((gx - 6.8, 4.0), (gx + 1.2, 4.0), 1.6, brass_d)
            P.rect(gx - 1.2, -4.6, 12.6, 9.2, steel_d)
            P.rect(gx - 0.5, -3.8, 11.2, 7.6, steel)
            P.ellipse(gx + 9.0, 0, 5.4, 5.6, steel_l, steel_d, 0.9)
            P.ellipse(gx + 9.0, 0, 3.4, 3.6, steel_d)
            P.circle(gx + 9.0, 0, 1.2, brass)
            for i in range(6):
                a = i * math.tau / 6
                P.circle(gx + 9.0 + math.cos(a) * 2.4, math.sin(a) * 2.4, 0.65, brass_d)
            P.rect(gx + 13.0, -2.4, 18.0, 4.8, steel, steel_d, 0.8)
            P.rect(gx + 13.4, -1.8, 16.6, 1.1, steel_l)
            P.rect(gx + 13.4, 1.5, 16.0, 1.0, steel_d)
            P.rect(gx + 31.0, -3.0, 3.0, 6.0, steel_d)
            P.circle(gx + 32.6, 0, 1.3, dark)
            P.poly([(gx - 0.8, -4.4), (gx + 2.8, -6.2), (gx + 3.6, -4.0)], steel_d)
            P.rect(gx + 27.0, -4.2, 1.6, 2.2, steel_d)
            P.rect(gx + 12.4, 2.8, 12.0, 1.5, steel_d)
            return 34, gx + 14

        if g == "smg":
            # приклад
            P.poly([(gx - 18, -1.0), (gx - 8, -3.6), (gx - 8, 6.2), (gx - 18, 4.6)], wood, wood_d, 0.9)
            P.line((gx - 17, 0.2), (gx - 9, -1.6), 0.8, wood_l)
            P.rect(gx - 20, -1.4, 2.6, 6.6, steel_d)
            # ствольная коробка
            P.rect(gx - 8, -4.6, 17.0, 9.2, steel_d)
            P.rect(gx - 7.2, -3.8, 15.4, 7.6, steel)
            P.rect(gx - 7.0, -3.5, 15.0, 1.2, steel_l)
            P.rect(gx + 1.0, 1.8, 4.4, 4.0, dark)
            # пистолетная рукоять и изогнутый магазин
            P.poly([(gx + 0.6, 4.0), (gx + 5.8, 4.0), (gx + 4.0, 11.0), (gx - 0.8, 10.0)], wood_d, (40, 22, 10), 0.7)
            P.poly([(gx + 2.4, 3.4), (gx + 8.6, 3.4), (gx + 11.4, 14.6), (gx + 5.4, 15.4)], steel_d, dark, 0.7)
            P.poly([(gx + 3.4, 4.2), (gx + 7.8, 4.2), (gx + 10.2, 13.8), (gx + 6.0, 14.4)], steel)
            P.line((gx + 4.4, 5.0), (gx + 8.6, 13.4), 0.8, steel_l)
            # деревянное цевьё
            P.rect(gx + 9.0, -4.0, 17.0, 8.0, wood, wood_d, 0.9)
            P.rect(gx + 9.6, -3.4, 15.8, 2.2, wood_l)
            for yy in (0.0, 1.6, 3.0):
                P.line((gx + 10.0, yy), (gx + 25.4, yy), 0.5, wood_d)
            # газовая трубка, ствол и мушка
            P.rect(gx + 9.0, -6.6, 17.0, 2.4, steel_d)
            P.rect(gx + 9.4, -6.2, 16.0, 0.9, steel_l)
            P.rect(gx + 26.0, -2.2, 15.0, 4.4, steel, steel_d, 0.8)
            P.rect(gx + 26.4, -1.7, 13.8, 1.0, steel_l)
            P.rect(gx + 33.0, -5.4, 1.8, 3.2, steel_d)
            P.rect(gx + 40.0, -3.0, 4.6, 6.0, steel_d)
            for yy in (-1.6, 0.0, 1.6):
                P.rect(gx + 40.6, yy - 0.4, 3.2, 0.8, dark)
            return 47, gx + 17

        if g == "shotgun":
            # приклад и коробка
            P.poly([(gx - 28, -1.0), (gx - 9, -4.0), (gx - 9, 6.4), (gx - 28, 4.8)], wood, wood_d, 0.9)
            P.line((gx - 27, 0.4), (gx - 10, -2.0), 0.9, wood_l)
            P.rect(gx - 30, -1.6, 2.8, 7.0, steel_d)
            P.rect(gx - 9, -4.6, 16.0, 9.2, steel_d)
            P.rect(gx - 8.2, -3.8, 14.4, 7.6, steel)
            P.rect(gx - 8.0, -3.5, 14.0, 1.2, steel_l)
            # ствол и подствольный магазин
            P.rect(gx + 7.0, -2.6, 45.0, 5.2, steel, steel_d, 0.9)
            P.rect(gx + 7.4, -2.0, 43.6, 1.2, steel_l)
            P.rect(gx + 11.0, 2.8, 39.0, 2.6, steel_d)
            P.rect(gx + 11.4, 3.2, 37.6, 0.9, steel_l)
            # цевьё-помпа
            P.rect(gx + 20.0, -4.4, 14.0, 9.0, wood, wood_d, 0.9)
            P.rect(gx + 20.6, -3.8, 12.8, 2.0, wood_l)
            for yy in (-1.6, 0.0, 1.6):
                P.line((gx + 21.0, yy), (gx + 33.4, yy), 0.5, wood_d)
            P.circle(gx + 51.6, -2.0, 1.1, brass_d)
            P.rect(gx + 51.0, -3.2, 2.4, 1.0, steel_d)
            return 55, gx + 27

        if g == "sawnoff":
            P.poly([(gx - 8, -3.0), (gx + 1, -3.0), (gx + 2.6, 5.6), (gx - 6.0, 5.6)], wood, wood_d, 0.9)
            P.poly([(gx - 7.0, -2.2), (gx - 1.0, -2.2), (gx + 0.4, 3.2), (gx - 5.4, 3.2)], wood_l)
            P.rect(gx - 0.6, -4.4, 5.0, 8.8, steel_d)
            P.circle(gx + 1.2, 0, 1.6, brass, brass_d, 0.6)
            for yy in (-4.8, 1.2):
                P.rect(gx + 3.4, yy, 26.0, 3.6, steel, steel_d, 0.8)
                P.rect(gx + 3.8, yy + 0.5, 24.8, 0.9, steel_l)
                P.rect(gx + 28.6, yy - 0.3, 2.2, 4.2, steel_d)
                P.circle(gx + 29.7, yy + 1.8, 0.8, dark)
            P.line((gx + 3.6, 0.0), (gx + 29.0, 0.0), 0.7, steel_d)
            # деревянное цевьё под стволами — за него и держимся
            P.rect(gx + 8.0, -2.4, 13.0, 4.8, wood, wood_d, 0.9)
            P.line((gx + 9.0, -1.7), (gx + 20.0, -1.7), 0.6, wood_l)
            P.line((gx + 9.0, 1.7), (gx + 20.0, 1.7), 0.6, wood_d)
            return 33, gx + 14

        # sniper
        P.poly([(gx - 29, -1.2), (gx - 8, -4.0), (gx - 8, 6.4), (gx - 29, 5.0)], wood, wood_d, 0.9)
        P.line((gx - 28, 0.4), (gx - 9, -2.2), 0.9, wood_l)
        P.rect(gx - 31, -1.8, 2.8, 7.2, steel_d)
        P.rect(gx - 8, -4.4, 17.0, 8.8, steel_d)
        P.rect(gx - 7.2, -3.6, 15.4, 7.2, steel)
        P.rect(gx - 7.0, -3.3, 15.0, 1.1, steel_l)
        # оптика
        P.rect(gx + 1.0, -9.8, 22.0, 4.4, (30, 32, 38), (10, 10, 12), 0.8)
        P.rect(gx + 1.0, -9.2, 22.0, 1.2, (70, 76, 88))
        P.rect(gx + 1.4, -10.4, 2.6, 5.6, steel_d)
        P.rect(gx + 20.0, -10.4, 2.6, 5.6, steel_d)
        P.ellipse(gx + 22.4, -7.6, 0.9, 2.2, (120, 210, 240), (30, 50, 60), 0.6)
        P.rect(gx + 4.0, -6.0, 2.0, 2.2, steel_d)
        P.rect(gx + 16.0, -6.0, 2.0, 2.2, steel_d)
        # ложе и ствол
        P.poly([(gx + 11.0, -3.4), (gx + 31.0, -3.4), (gx + 33.0, 0.5),
                (gx + 31.0, 4.4), (gx + 11.0, 4.4)], wood, wood_d, 0.9)
        P.line((gx + 12.0, -2.6), (gx + 30.0, -2.6), 0.8, wood_l)
        P.line((gx + 12.0, 3.8), (gx + 30.0, 3.8), 0.7, wood_d)
        P.rect(gx + 15.0, -2.0, 40.0, 4.0, steel, steel_d, 0.8)
        P.rect(gx + 15.4, -1.5, 38.8, 1.0, steel_l)
        P.rect(gx + 55.0, -3.0, 4.6, 6.0, steel_d)
        for yy in (-1.8, 0.0, 1.8):
            P.rect(gx + 55.6, yy - 0.4, 3.4, 0.8, dark)
        P.poly([(gx + 14.0, 2.0), (gx + 54.0, 2.0), (gx + 54.0, 3.2), (gx + 14.0, 3.2)], wood_d)
        # затвор и сошки
        P.circle(gx + 8.0, 4.4, 1.7, steel_d)
        P.line((gx + 8.0, 3.6), (gx + 8.0, 0.0), 1.4, steel_d)
        P.line((gx + 29.0, 2.6), (gx + 26.0, 8.0), 0.8, steel_d)
        P.line((gx + 33.0, 2.6), (gx + 36.0, 8.0), 0.8, steel_d)
        return 61, gx + 23

    def _draw_melee(self, surf, x, y, target_angle):
        if not self.melee_weapon: return

        # Текущий угол взмаха (маятник) или угол прицела
        if self.active_melee == "chainsaw":
            prog = 1.0
            sweep = 0.0
            ang = target_angle + math.sin(self.chainsaw_time * 70) * 0.05 * self.chainsaw_spin
        elif self.melee_timer > 0:
            rate = max(0.05, self.melee_weapon["rate"])
            prog = 1.0 - max(0.0, self.melee_timer) / rate
            sweep = (-1.2 + 2.4 * prog) * self.swing_dir
            ang = self.melee_angle + sweep
        else:
            prog = 1.0
            sweep = 0.0
            ang = target_angle

        m = self.active_melee
        w_len = {"bat": 35, "machete": 40, "axe": 40, "knife": 20,
                 "crowbar": 35, "chainsaw": 45}.get(m, 35)

        P = Painter(200, 2, ang)
        steel, steel_d, steel_l = (196, 202, 212), (60, 64, 74), (250, 252, 255)
        wood, wood_d, wood_l = (176, 126, 70), (80, 50, 24), (214, 164, 100)
        grip, grip_d = (52, 38, 28), (26, 18, 12)
        brass, brass_d = (198, 158, 78), (116, 86, 34)
        handle = (20, 4)
        l_hand = (13.0, -5.5) if m == "chainsaw" else (16.0, 1.0)
        self._draw_arm(P, (7.0, 10.0), handle, (214, 160, 118), (130, 84, 56),
                       (234, 228, 212), (138, 132, 118))
        self._draw_arm(P, (7.0, -10.0), l_hand, (214, 160, 118), (130, 84, 56),
                       (234, 228, 212), (138, 132, 118))

        # 2. Оружие (у стены укорачиваем вдоль взмаха, хват остаётся на месте)
        reach_m = 24 + w_len + (6 if m == "crowbar" else 0)
        allow_m = decor.ray_wall_dist(self.x, self.y, ang, 110.0, self.solids) - 3.0
        ms = 1.0
        if reach_m > allow_m and allow_m > 0:
            ms = max(0.25, (allow_m - 20) / (reach_m - 20))
            P.xform(ms, 20 * (1 - ms))
        if m == "bat":
            P.rect(8, 1.4, 13, 5.2, grip, grip_d, 0.7)
            for k in range(4):
                P.line((10.0 + k * 2.6, 1.8), (9.4 + k * 2.6, 6.2), 0.6, (74, 54, 40))
            P.poly([(20, 1.0), (27, 0.2), (20 + w_len - 2, -0.6), (20 + w_len, 4.0),
                    (20 + w_len - 2, 8.6), (27, 7.8), (20, 7.0)], wood, wood_d, 1.0)
            P.ellipse(20 + w_len - 1, 4.0, 2.8, 4.4, wood, wood_d, 1.0)
            P.line((22, 2.0), (20 + w_len - 3, 1.2), 1.2, wood_l)
            P.line((22, 6.2), (20 + w_len - 3, 6.8), 0.9, wood_d)
            for nx, ny in ((20 + w_len - 6, 2.6), (20 + w_len - 9, 5.6)):
                P.circle(nx, ny, 0.8, (160, 164, 176), (52, 54, 62), 0.4)

        elif m == "machete":
            E = 20 + w_len
            # тёмная рукоять с насечкой, без гарды
            P.rect(8, 1.6, 13, 5.0, (52, 52, 56), (20, 20, 24), 0.8)
            P.rect(8.6, 2.2, 11.8, 1.4, (86, 86, 92))
            for k in range(4):
                P.line((10.5 + k * 2.6, 2.0), (10.0 + k * 2.6, 6.0), 0.7, (24, 24, 28))
            P.rect(19.5, 1.0, 1.8, 6.4, (140, 140, 148), (60, 60, 68), 0.6)
            # широкий клинок с прямым закруглённым концом, как у мачете
            P.poly([(21.5, 1.2), (E - 2, 1.2), (E + 3, 2.0), (E + 3, 7.8),
                    (E - 2, 8.8), (21.5, 8.8)], (150, 158, 172), (58, 62, 72), 0.9)
            P.poly([(23, 4.6), (E - 3, 4.6), (E + 1, 5.4), (E + 1, 7.6),
                    (E - 3, 8.2), (23, 8.2)], (212, 220, 234))
            P.line((22, 1.8), (E - 2, 1.8), 1.2, (96, 102, 116))
            P.line((22, 4.2), (E - 3, 4.2), 0.6, (120, 128, 144))
            P.line((22, 8.3), (E - 2, 8.6), 1.0, (240, 244, 252))
            P.circle(10.2, 4.0, 0.9, (30, 30, 34))

        elif m == "axe":
            # топор: длинное деревянное топорище и стальной клин-лезвие с обухом
            E = 20 + w_len
            P.rect(8, 2.2, 14, 3.6, grip, grip_d, 0.7)                          # хват
            for k in range(4):
                P.line((10.0 + k * 3.0, 2.4), (9.5 + k * 3.0, 5.6), 0.6, (74, 54, 40))
            P.poly([(21, 2.0), (E - 7, 1.4), (E - 5, 2.0), (E - 5, 6.0), (E - 7, 6.6), (21, 6.0)], wood, wood_d, 0.9)
            P.line((22, 2.8), (E - 8, 2.4), 0.8, wood_l)
            P.ellipse(8.6, 4.0, 1.6, 2.2, wood_d)                               # нижний выступ топорища
            # голова: обух сзади, клин расширяется к режущей кромке
            P.rect(E - 12, -0.6, 5, 9.2, steel_d, (24, 26, 32), 0.8)             # обух
            P.poly([(E - 8, 0.4), (E - 2, -2.2), (E + 3, -6.2), (E + 6, -5.0), (E + 7, 4.0),
                    (E + 6, 13.0), (E + 3, 14.2), (E - 2, 10.2), (E - 8, 7.6)], steel, steel_d, 1.0)
            P.poly([(E - 6, 1.6), (E - 1, -0.6), (E + 3, -3.8), (E + 4.6, 4.0), (E + 3, 11.8), (E - 1, 8.6), (E - 6, 6.4)],
                   (222, 228, 238))
            P.line((E + 6.4, -4.4), (E + 7.4, 4.0), 1.0, steel_l)               # режущая кромка
            P.line((E + 7.4, 4.0), (E + 6.4, 12.4), 1.0, steel_l)
            P.circle(E - 5, 4.0, 1.0, steel_d)                                   # заклёпка в проушине

        elif m == "knife":
            P.rect(8, 1.8, 12, 4.4, grip, grip_d, 0.7)
            P.rect(18.6, -1.2, 1.8, 10.4, brass_d)
            P.poly([(20.4, 0.6), (20 + w_len - 3, -0.2), (20 + w_len, 2.2),
                    (20 + w_len - 1, 5.2), (20 + w_len - 4, 7.2), (20.4, 7.2)],
                   steel, steel_d, 0.8)
            P.poly([(21, 1.2), (20 + w_len - 3, 0.4), (20 + w_len - 0.5, 2.4),
                    (20 + w_len - 1.5, 4.8), (21, 6.2)], steel_l)
            P.line((21, 6.6), (20 + w_len - 5, 6.4), 0.7, steel_l)
            P.circle(9.8, 4.0, 1.0, brass_d)

        elif m == "crowbar":
            P.thick((5, 4), (20 + w_len - 2, 4), 4.4, (78, 22, 22))
            P.thick((7, 4), (20 + w_len - 3, 4), 3.0, (188, 48, 44))
            P.line((8, 2.6), (20 + w_len - 5, 2.6), 0.8, (245, 120, 110))
            P.thick((20 + w_len - 4, 4), (20 + w_len + 5, 11), 3.8, (188, 48, 44), (78, 22, 22))
            P.thick((20 + w_len + 5, 11), (20 + w_len + 2, 17), 3.2, (188, 48, 44), (78, 22, 22))
            P.line((20 + w_len + 3, 12), (20 + w_len + 1, 16), 0.8, (245, 120, 110))
            P.poly([(5, 2.4), (1, 1.2), (1, 6.8), (5, 5.6)], (150, 40, 36), (70, 20, 20), 0.6)

        elif m == "chainsaw":
            # корпус
            P.poly([(6, -3.6), (22, -3.6), (24, 1.0), (24, 9.0), (22, 12.6), (6, 12.6), (4, 9.0), (4, 1.0)],
                   (226, 118, 22), (90, 44, 8), 1.0)
            P.poly([(7, -2.4), (21, -2.4), (22, 1.2), (22, 7.6), (7, 7.6), (5.5, 1.2)], (244, 148, 52))
            # верхняя ручка
            P.line((8, -2.8), (8, -7.0), 2.2, (42, 42, 48))
            P.line((8, -7.0), (20, -7.0), 2.2, (42, 42, 48))
            P.line((20, -7.0), (20, -3.2), 2.2, (42, 42, 48))
            # шина
            P.rect(24, 1.4, w_len, 5.6, (150, 154, 164), (60, 64, 74), 0.9)
            P.rect(24.6, 2.0, w_len - 1.2, 1.4, (215, 220, 230))
            # цепь бежит по шине, когда пила заведена
            off = (self.chainsaw_time * 140.0 * self.chainsaw_spin) % 5.0
            for i in range(-5, int(w_len) + 5, 5):
                x0 = 25.5 + i - off
                if 23 < x0 < 24 + w_len - 2:
                    P.rect(x0, 0.6, 2.2, 1.8, (60, 60, 66))
                    P.rect(x0 + 1.0, 6.9, 2.2, 1.8, (60, 60, 66))
            for i in range(0, int(w_len) - 2, 9):
                P.circle(28 + i, 4.2, 0.8, (70, 70, 78))
            P.circle(26.5, 4.2, 2.0, (70, 70, 78), (20, 20, 24), 0.6)
            if self.saw_blood > 0.02:
                sb = self.saw_blood
                a_ = int(210 * min(1.0, sb * 1.6))
                P.rect(24.4, 1.6, (w_len - 1.5) * min(1.0, 0.45 + sb), 5.2, (112, 6, 8, a_))
                for i in range(0, int(w_len) - 4, 6):
                    P.circle(27 + i, 4.2 + math.sin(i * 1.3) * 1.6, 1.2, (150, 12, 14, a_))
                P.ellipse(14, 3.6, 7, 3.6, (110, 6, 8, int(a_ * 0.8)))
            # выхлоп, пока двигатель работает
            if self.chainsaw_spin > 0.05:
                for k in range(3):
                    ph = (self.chainsaw_time * 2.4 + k * 0.33) % 1.0
                    P.circle(5.0 - ph * 9.0, -4.0 - ph * 7.0, 1.4 + ph * 3.0,
                             (78, 78, 78, int(90 * (1 - ph) * self.chainsaw_spin)))

        P.xform(1.0, 0.0)
        # 3. Обе кисти на рукояти (левая чуть позади правой)
        self._draw_fist(P, l_hand[0], l_hand[1], (214, 166, 122), (120, 80, 52))
        self._draw_fist(P, handle[0], handle[1], (214, 166, 122), (120, 80, 52))

        # 4. След от взмаха — изогнутая полоса, а не белый клин
        if self.melee_timer > 0 and abs(sweep) > 0.01:
            tr = Painter(200, 2, self.melee_angle)
            r0, r1 = 26, w_len + 14
            steps = 6
            a_start = -1.2 * self.swing_dir
            for j in range(steps):
                t0, t1 = j / steps, (j + 1) / steps
                a0 = a_start + (sweep - a_start) * t0
                a1 = a_start + (sweep - a_start) * t1
                alpha = int(90 * prog * (0.25 + 0.75 * t1))
                if alpha <= 0: continue
                tr.poly([
                    (math.cos(a0) * r0, math.sin(a0) * r0),
                    (math.cos(a0) * r1, math.sin(a0) * r1),
                    (math.cos(a1) * r1, math.sin(a1) * r1),
                    (math.cos(a1) * r0, math.sin(a1) * r0),
                ], (255, 248, 224, alpha))
            tr_s = tr.result()
            surf.blit(tr_s, tr_s.get_rect(center=(x, y)))

        spr = P.result()
        if m == "chainsaw":
            sh = 1.2 * self.chainsaw_spin
            ox = math.sin(self.chainsaw_time * 73.0) * sh
            oy = math.cos(self.chainsaw_time * 91.0) * sh
            surf.blit(spr, spr.get_rect(center=(x + ox, y + oy)))
        else:
            surf.blit(spr, spr.get_rect(center=(x, y)))
