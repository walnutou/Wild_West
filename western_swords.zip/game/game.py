import math, random, sys
import pygame
from .config import (
    WIDTH, HEIGHT, WORLD_W, WORLD_H, SAND, SAND_D,
    WEAPONS, MELEE_WEAPONS, KICK, XP_START_NEEDED, XP_GROWTH, MOBILE, TOUCH,
)
from .player import Player
from .zombie import Zombie
from .raider import Raider
from .effects import BloodSystem
from .corpse import Corpse
from .camera import Camera
from . import decor, ui, sounds
from .utils import text, seg_dist
from . import atmosphere, menu, modes, savedata, upgrades
from .touch import Touch

class Game:
    def __init__(self):
        sounds.init()
        self.keys_pressed = set()
        self.touch = Touch()
        self.mode = "free"
        self.menu_t = 0.0
        self.new_record = False
        self.reset()
        self.enter_menu()

    # ------------------------------------------------------------ ввод (мышь или сенсор)
    def aim_screen(self):
        if self.touch.enabled:
            return self.touch.aim_point(self)
        return pygame.mouse.get_pos()

    def fire_held(self):
        if self.touch.enabled:
            return self.touch.fire
        return pygame.mouse.get_pressed()[0]

    def melee_held(self):
        if self.touch.enabled:
            return self.touch.melee
        return pygame.key.get_pressed()[pygame.K_SPACE] or pygame.mouse.get_pressed()[2]

    # ------------------------------------------------------------ меню
    def enter_menu(self):
        self.reset(self.mode)
        self.zombies = []
        self.tumbleweeds = []
        self.state = "menu"
        self.menu_cam = [1990 - WIDTH / 2, 1310.0]
        for i in range(18 if not MOBILE else 12):
            z = self._make_zombie(0, 0)
            z.menu_dir = random.choice((-1, 1))
            z.speed = random.uniform(26, 52) * (0.7 if z.type == "tank" else 1.0)
            z.x = self.menu_cam[0] + random.uniform(-120, WIDTH + 120)
            z.y = random.uniform(1700, 2010)
            z.wob = random.uniform(0, 6)
            self.zombies.append(z)
        self.atm.flash = 0.0

    def update_menu(self, dt):
        self.menu_t += dt
        self.wind_t += dt
        self.menu_cam[0] = 1990 - WIDTH / 2 + math.sin(self.menu_t * 0.15) * 36
        cx = self.menu_cam[0]
        for z in self.zombies:
            sp = z.speed
            z.x += z.menu_dir * sp * dt
            z.facing = 0.0 if z.menu_dir > 0 else math.pi
            z.wob += dt * sp * 0.05
            z.t += dt
            z.state = "wander"
            if z.x < cx - 160 and z.menu_dir < 0:
                z.menu_dir = 1
                z.x = cx - 150
            elif z.x > cx + WIDTH + 160 and z.menu_dir > 0:
                z.menu_dir = -1
                z.x = cx + WIDTH + 150
        self.atm.update_menu(self, dt)

    def draw_menu_scene(self, surf):
        surf.fill(SAND)
        cx, cy = self.menu_cam
        far = -99999
        decor.draw_floors(surf, self.decor, cx, cy, far, far)
        decor.draw_all(surf, self.decor, cx, cy, far, far)
        for z in sorted(self.zombies, key=lambda q: q.y):
            z.draw(surf, far, far, cx, cy)
        decor.draw_roofs(surf, self.decor, cx, cy, far, far)
        self.atm.draw_fog(surf, cx, cy)
        self.atm.draw_menu(surf, self, cx, cy)
        for z in self.zombies:
            z.draw_eyes(surf, cx, cy, 0.9)
        self.atm.draw_post(surf, self, menu=True)

    def reset(self, mode=None):
        if mode:
            self.mode = mode
        self.cfg = modes.BY_ID[self.mode]
        self.new_record = False
        self.keys_pressed.clear()
        self.player = Player()
        self.camera = Camera(WIDTH, HEIGHT)
        self.xp, self.level, self.xp_needed = 0, 1, XP_START_NEEDED
        
        self.zombies, self.raiders, self.orbs = [], [], []
        self.bullets, self.crates = [], []
        self.corpses = []
        self.floating_texts = []
        
        self.crate_timer = 9.0
        self.footprint_timer = 0.0
        self.dust_timer = 0.0
        self.tumbleweeds = []
        self.tumble_timer = 2.0
        self.shells = []
        self.hitstop = 0.0
        self.shake = 0.0
        self.hit_flashes = []
        self.step_timer = 0.0
        self.dark = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        self._light_base = None
        self._light_cache = {}

        self.blood = BloodSystem()
        self.decor = decor.make_decor()
        self.solid_buildings = [d for d in self.decor if d.get("solid")]
        self.player.solids = self.solid_buildings
        self.extra_noises = []
        self.flash_on = True            # фонарь (клавиша F)
        self.choices = []
        self.alert_cd = 0.0
        self.wind_t = random.uniform(0, 100)
        self.atm = atmosphere.Atmosphere()
        self.last_hp = self.player.hp
        self.heart_timer = 0.0
        self.breath_timer = 0.0
        sounds.loop(0, "amb_wind", 0.0)
        sounds.loop(1, "amb_drone", 0.0)
        sounds.loop(2, "saw_idle", 0.0)
        sounds.loop(3, "saw_rev", 0.0)

        for _ in range(16):
            self.crates.append(self._make_crate())
        
        self.game_time = 0.0
        self._populate_world()
        self.state = "playing"
        self.admin_open = False
        self.wave = 0
        self.wave_state = "rest"
        self.wave_timer = 3.0
        self.wave_left = 0
        self.wave_acc = 0.0
        self.dawn_t = 0.0
        self.player.gun_hidden = not self.cfg["guns"]
        if not self.cfg["guns"]:
            self.player.add_weapon("machete", is_melee=True)
        self.spawn_timer = 1.0
        self.raider_timer = 15.0
        self.game_time = 0.0
        self.kills = 0
        self.flash = 0.0

    def _make_crate(self):
        for _ in range(30):
            x = random.randint(200, WORLD_W-200)
            y = random.randint(200, WORLD_H-200)
            if not any(d.get("solid") and decor.circle_rect_hit(x, y, 22, d)
                       for d in getattr(self, "decor", ())):
                break
        roll = random.random()
        if roll < 0.20 and getattr(self, "cfg", {}).get("guns", True):
            return {"x": x, "y": y, "type": "gun"}
        elif roll < 0.32 or (roll < 0.20 and not getattr(self, "cfg", {}).get("guns", True)):
            return {"x": x, "y": y, "type": "melee"}
        else:
            return {"x": x, "y": y, "type": "xp"}

    def _opening_fx(self, op, pt, res):
        """Эффекты попадания в окно/дверь: трещины, осколки, щепки, звук, шум."""
        px_, py_ = pt
        if op["kind"] == "window":
            if res == "broken":
                self.blood.add_debris(px_, py_, "glass", 26)
                self.blood.add_glass_litter(op["x"], op["y"], op["w"], op["h"], 26)
                sounds.play_at("glass", px_, py_, 1.0, 1800)
                self.extra_noises.append((px_, py_, 700.0, "glass"))
                self.shake = max(self.shake, 0.08)
            else:
                self.blood.add_debris(px_, py_, "glass", 5)
                sounds.play_at("glass", px_, py_, 0.45, 1400)
        else:
            if res == "broken":
                self.blood.add_debris(px_, py_, "wood", 22)
                sounds.play_at("wood", px_, py_, 1.0, 1800)
                self.extra_noises.append((px_, py_, 700.0, "door"))
                self.shake = max(self.shake, 0.1)
            else:
                self.blood.add_debris(px_, py_, "wood", 5)
                sounds.play_at("wood", px_, py_, 0.7, 1500)
        self.hit_flashes.append({"x": px_, "y": py_, "life": 0.1, "max": 0.1})

    def _pop_tumbleweed(self, tw, angle):
        if tw in self.tumbleweeds:
            self.tumbleweeds.remove(tw)
        self.blood.add_tumble_burst(tw["x"], tw["y"] - tw.get("z", 0), tw["r"], angle)
        sounds.play_at("twig", tw["x"], tw["y"], 0.9, 1300)
        self.hit_flashes.append({"x": tw["x"], "y": tw["y"], "life": 0.08, "max": 0.08})

    def _route(self, x, y, tx, ty):
        """Путь вокруг зданий: граф видимости по углам домов и дверям (алгоритм Дейкстры)."""
        import heapq
        if not decor.line_blocked(x, y, tx, ty):
            return (tx, ty)
        x0, x1 = min(x, tx) - 120, max(x, tx) + 120
        y0, y1 = min(y, ty) - 120, max(y, ty) + 120
        blds = [b for b in decor.TOWN if b.get("solid") and
                b["x"] + b["w"] / 2 > x0 and b["x"] - b["w"] / 2 < x1 and
                b["y"] + b["h"] / 2 > y0 and b["y"] - b["h"] / 2 < y1]
        if not blds:
            return (tx, ty)

        def free(a, b):
            line = (a, b)
            for bd in blds:
                walls, _ = decor.building_parts(bd)
                for wr in walls:
                    if wr.clipline(line):
                        return False
            return True

        m = 26
        nodes = [(x, y), (tx, ty)]
        for bd in blds:
            hw, hh = bd["w"] / 2 + m, bd["h"] / 2 + m
            for sx in (-1, 1):
                for sy in (-1, 1):
                    nodes.append((bd["x"] + sx * hw, bd["y"] + sy * hh))
            nodes.append((bd["x"], bd["y"] + bd["h"] / 2 + 34))    # перед дверью снаружи
            nodes.append((bd["x"], bd["y"] + bd["h"] / 2 - 34))    # за дверью внутри
            nodes.append((bd["x"], bd["y"]))
        n = len(nodes)
        dist = [1e18] * n
        prev = [-1] * n
        dist[0] = 0.0
        pq = [(0.0, 0)]
        while pq:
            d, i = heapq.heappop(pq)
            if d > dist[i]:
                continue
            if i == 1:
                break
            for j in range(n):
                if j == i:
                    continue
                dd = d + math.hypot(nodes[i][0] - nodes[j][0], nodes[i][1] - nodes[j][1])
                if dd < dist[j] and free(nodes[i], nodes[j]):
                    dist[j] = dd
                    prev[j] = i
                    heapq.heappush(pq, (dd, j))
        if prev[1] < 0:
            return (tx, ty)
        j = 1
        while prev[j] != 0 and prev[j] >= 0:
            j = prev[j]
        return nodes[j]

    def _nav(self, z, tx, ty):
        c = z._navc
        if c is not None and c[0] > self.game_time and abs(c[1] - tx) < 40 and abs(c[2] - ty) < 40 \
                and math.hypot(c[3] - z.x, c[4] - z.y) > 16:
            return (c[3], c[4])
        wp = self._route(z.x, z.y, tx, ty)
        z._navc = (self.game_time + 0.6, tx, ty, wp[0], wp[1])
        return wp

    def _gore_kind(self, e):
        """Какая рана у убитого: 'blast' — дробь в упор, 'saw' — пила, иначе None."""
        w = getattr(e, "last_weapon", "")
        if w in ("shotgun", "sawnoff") and getattr(e, "last_hit_dist", 999) < 190:
            return "blast"
        if w == "chainsaw":
            return "saw"
        return None

    def toggle_flashlight(self):
        if not self.cfg["flash"]:
            return
        self.flash_on = not self.flash_on
        sounds.play("empty", 0.25)
        self._add_floating_text(self.player.x, self.player.y - 34,
                                "ФОНАРЬ ВКЛ" if self.flash_on else "ФОНАРЬ ВЫКЛ", (255, 240, 170))

    def _melee_hit(self, kick=False):
        if kick:
            w_stats = dict(KICK, dmg=KICK["dmg"] * self.player.melee_dmg_mult,
                           range=KICK["range"] * self.player.melee_reach_mult)
        else:
            w_stats = self.player.melee_weapon
        aim = self.player.kick_angle if kick else self.player.melee_angle
        max_diff = 0.8 if self.player.active_melee == "chainsaw" else 1.4
        # При взмахе тело летит по касательной к дуге удара, а не просто от игрока
        chainsaw = self.player.active_melee == "chainsaw"
        swing_impact = aim + math.pi * 0.5 * self.player.swing_dir
        for z in self.zombies + self.raiders:
            if math.hypot(z.x - self.player.x, z.y - self.player.y) < w_stats["range"] + z.r * 0.5:
                hit_angle = math.atan2(z.y - self.player.y, z.x - self.player.x)
                diff = abs((hit_angle - aim + math.pi) % math.tau - math.pi)
                if diff > max_diff:
                    continue
                if decor.line_blocked(self.player.x, self.player.y, z.x, z.y):
                    continue
                impact = hit_angle if chainsaw else swing_impact
                if hasattr(z, 'take_hit'):
                    z.take_hit(w_stats["dmg"], impact, self.blood, can_dismember=w_stats["dismember"],
                               is_melee=True, weapon_key="kick" if kick else self.player.active_melee,
                               strength=max(1.0, w_stats["dmg"] / 60.0) * self.player.dmg_mult)
                    if kick:
                        # след подошвы от пинка на земле у цели; ботинок пачкается и оставляет следы дальше
                        self.blood.add_footprint(z.x, z.y, self.player.kick_angle, self.player.kick_side, 1.0)
                        self.blood.add_footprint(z.x - math.cos(hit_angle) * 9, z.y - math.sin(hit_angle) * 9,
                                                 self.player.kick_angle, -self.player.kick_side, 0.8)
                        self.player.blood_charge = max(self.player.blood_charge, 1.0)
                        self.blood.add_dust(z.x, z.y, hit_angle)
                        self.blood.add_dust(z.x, z.y, hit_angle + 0.5)
                        self.shake = max(self.shake, 0.1)
                        self.blood.sparks.append({"x": z.x, "y": z.y, "z": 14, "vx": 0, "vy": 0, "vz": 0, "r": 6,
                                                  "color": (255, 244, 214), "life": 0.06}) if False else None
                    if kick and hasattr(z, "kx"):
                        # сильный толчок ногой: отбрасывает и надолго сбивает с шага
                        z.kx += math.cos(hit_angle) * 260.0 * (0.5 if getattr(z, "type", "") == "tank" else 1.0)
                        z.ky += math.sin(hit_angle) * 260.0 * (0.5 if getattr(z, "type", "") == "tank" else 1.0)
                        z.stagger = max(z.stagger, 0.9)
                else:
                    z.hp -= w_stats["dmg"]
                self.blood.hit(z.x, z.y, impact, w_stats["dmg"])
                if chainsaw:
                    self.blood.saw_gore(z.x, z.y, hit_angle, self.player.x, self.player.y)
                    self.player.saw_blood = min(1.0, self.player.saw_blood + 0.35)
                    if random.random() < 0.5:
                        self.player.add_hat_blood(hit_angle)
                    self.shake = max(self.shake, 0.08)
                sounds.play("hit_flesh", 0.55)
                self.hit_flashes.append({"x": z.x, "y": z.y, "life": 0.12, "max": 0.12})
                
        # Удар по кактусам
        for d in self.decor:
            if d["t"] == "cactus" and not d.get("broken", False):
                cy = d["y"] - 15 * d["s"]
                if math.hypot(d["x"] - self.player.x, cy - self.player.y) < w_stats["range"] + 20 * d["s"]:
                    hit_angle = math.atan2(cy - self.player.y, d["x"] - self.player.x)
                    diff = abs((hit_angle - aim + math.pi) % math.tau - math.pi)
                    if diff > max_diff:
                        continue
                    d["broken"] = True
                    self.blood.add_cactus_explosion(d["x"], cy)

        # перекати-поле разлетается от удара
        for tw in self.tumbleweeds[:]:
            if math.hypot(tw["x"] - self.player.x, tw["y"] - self.player.y) < w_stats["range"] + tw["r"]:
                a = math.atan2(tw["y"] - self.player.y, tw["x"] - self.player.x)
                if abs((a - aim + math.pi) % math.tau - math.pi) <= max_diff:
                    self._pop_tumbleweed(tw, a)

        # Ближний бой выбивает двери и окна
        for bld in self.solid_buildings:
            for op in bld.get("openings", ()):
                if op.get("broken"):
                    continue
                ox = op["x"] + op["w"] / 2
                oy = op["y"] + op["h"] / 2
                if math.hypot(ox - self.player.x, oy - self.player.y) > w_stats["range"] + 24:
                    continue
                a = math.atan2(oy - self.player.y, ox - self.player.x)
                if abs((a - aim + math.pi) % math.tau - math.pi) > max_diff:
                    continue
                res = decor.damage_opening(op, w_stats.get("door", 3), ox, oy)
                self._opening_fx(op, (ox, oy), res)
                self.extra_noises.append((self.player.x, self.player.y, 450.0, "melee"))

    def _open_xp_crate(self, c):
        if c not in self.crates: return
        self.crates.remove(c)
        for _ in range(4):
            self.orbs.append({"x": c["x"] + random.uniform(-18, 18), "y": c["y"] + random.uniform(-18, 18), "v": 2})
        self._add_floating_text(c["x"], c["y"] - 30, "+8 XP", (255, 230, 120))

    def _start(self, mode=None):
        self.touch.release_all()
        self.reset(mode or self.mode)
        self.state = "playing"

    def _finish(self, won):
        self.new_record = savedata.submit(self.mode, self.kills, self.game_time, wave=self.wave, won=won)
        self.state = "victory" if won else "gameover"
        self.touch.release_all()

    def _ui_click(self, pos):
        st = self.state
        if st == "menu":
            for bid, r, _ in menu.menu_buttons():
                if r.collidepoint(pos):
                    if bid == "play": self._start()
                    elif bid == "modes": self.state = "modes"
                    elif bid == "quit": pygame.quit(); sys.exit()
        elif st == "modes":
            for m, r in zip(modes.MODES, menu.mode_cards()):
                if r.collidepoint(pos):
                    self.mode = m["id"]
                    self.cfg = m
            if menu.back_button().collidepoint(pos):
                self.state = "menu"
        elif st == "paused":
            for bid, r, _ in menu.pause_buttons():
                if r.collidepoint(pos):
                    if bid == "resume": self.state = "playing"
                    elif bid == "restart": self._start()
                    elif bid == "menu": self.enter_menu()
        elif st in ("gameover", "victory"):
            for bid, r, _ in menu.end_buttons():
                if r.collidepoint(pos):
                    if bid == "restart": self._start()
                    elif bid == "menu": self.enter_menu()
        elif st == "levelup":
            for i, r in enumerate(ui.option_rects()):
                if r.collidepoint(pos): self.choose(i)

    def handle_event(self, e):
        playing = self.state == "playing" and not self.admin_open
        if e.type in (pygame.FINGERDOWN, pygame.FINGERMOTION, pygame.FINGERUP):
            self.touch.handle(e, playing)
            return
        if e.type == pygame.APP_WILLENTERBACKGROUND and self.state == "playing":
            self.state = "paused"
            self.touch.release_all()
        if self.touch.enabled and not MOBILE and e.type in (
                pygame.MOUSEBUTTONDOWN, pygame.MOUSEBUTTONUP, pygame.MOUSEMOTION):
            self.touch.emulate_mouse(e, playing)
        if e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
            self._ui_click(e.pos)
            return
        if e.type == pygame.KEYDOWN and self.state in ("menu", "modes"):
            if e.key == pygame.K_ESCAPE:
                if self.state == "modes": self.state = "menu"
                else: pygame.quit(); sys.exit()
            elif e.key in (pygame.K_RETURN, pygame.K_SPACE, pygame.K_KP_ENTER) and self.state == "menu":
                self._start()
            elif e.key == pygame.K_m and self.state == "menu":
                self.state = "modes"
            return
        if e.type == pygame.KEYDOWN and self.state in ("gameover", "victory") and e.key == pygame.K_m:
            self.enter_menu()
            return
        if e.type == pygame.KEYDOWN:
            # Считываем WASD
            if e.scancode == pygame.KSCAN_W: self.keys_pressed.add(pygame.K_w)
            elif e.scancode == pygame.KSCAN_A: self.keys_pressed.add(pygame.K_a)
            elif e.scancode == pygame.KSCAN_S: self.keys_pressed.add(pygame.K_s)
            elif e.scancode == pygame.KSCAN_D: self.keys_pressed.add(pygame.K_d)
            else: self.keys_pressed.add(e.key)

            # --- АДМИН-ПАНЕЛЬ ---
            if e.key == pygame.K_TAB:
                self.admin_open = not self.admin_open
                return

            if self.admin_open:
                # Выдача оружия (1-6)
                if pygame.K_1 <= e.key <= pygame.K_6:
                    guns = list(WEAPONS.keys())
                    idx = e.key - pygame.K_1
                    if idx < len(guns):
                        self.player.add_weapon(guns[idx], is_melee=False)
                # Выдача ближнего боя (F1-F6)
                if pygame.K_F1 <= e.key <= pygame.K_F6:
                    melee = list(MELEE_WEAPONS.keys())
                    idx = e.key - pygame.K_F1
                    if idx < len(melee):
                        self.player.add_weapon(melee[idx], is_melee=True)
                # Читы
                if e.key == pygame.K_h:
                    self.player.hp = self.player.max_hp
                if e.key == pygame.K_g:
                    self.player.armor = self.player.max_armor
                if e.key == pygame.K_k:
                    self.xp += 1000
                return

            # --- ОСТАЛЬНЫЕ КЛАВИШИ ---
            if e.key == pygame.K_ESCAPE:
                if self.state == "playing": self.state = "paused"
                elif self.state == "paused": self.state = "playing"
                elif self.state in ("gameover", "victory"): self.enter_menu()

            if self.state in ("gameover", "victory") and e.key == pygame.K_r:
                self._start()
            if self.state == "levelup":
                if e.key in (pygame.K_1, pygame.K_KP1): self.choose(0)
                elif e.key in (pygame.K_2, pygame.K_KP2): self.choose(1)
                elif e.key in (pygame.K_3, pygame.K_KP3): self.choose(2)
                
            if self.state == "playing" and (e.key == pygame.K_e or e.scancode == pygame.KSCAN_E):
                self._interact()

            if self.state == "playing" and (e.key == pygame.K_f or e.scancode == pygame.KSCAN_F):
                self.toggle_flashlight()

            if self.state == "playing" and (e.key == pygame.K_r or e.scancode == pygame.KSCAN_R):
                self.player.start_reload()

        elif e.type == pygame.KEYUP:
            if e.scancode == pygame.KSCAN_W: self.keys_pressed.discard(pygame.K_w)
            elif e.scancode == pygame.KSCAN_A: self.keys_pressed.discard(pygame.K_a)
            elif e.scancode == pygame.KSCAN_S: self.keys_pressed.discard(pygame.K_s)
            elif e.scancode == pygame.KSCAN_D: self.keys_pressed.discard(pygame.K_d)
            else: self.keys_pressed.discard(e.key)

        elif e.type == pygame.WINDOWFOCUSLOST:
            # Иначе зажатые клавиши «залипают» после переключения окна
            self.keys_pressed.clear()


    def _interact(self):
        for c in self.crates[:]:
            if math.hypot(self.player.x - c["x"], self.player.y - c["y"]) < 100:
                if c["type"] == "gun" and not self.cfg["guns"]:
                    c["type"] = "melee"
                if c["type"] == "gun":
                    w = random.choice(list(WEAPONS.keys()))
                    self.player.add_weapon(w, is_melee=False)
                    self._add_floating_text(c["x"], c["y"]-30, f"ОРУЖИЕ: {WEAPONS[w]['name']}", (255, 220, 100))
                elif c["type"] == "melee":
                    m_roll = random.random()
                    if not self.cfg["guns"]:
                        w = ("chainsaw" if m_roll < 0.10 else "axe" if m_roll < 0.32 else
                             "machete" if m_roll < 0.55 else "bat" if m_roll < 0.75 else "knife")
                    elif m_roll < 0.03: w = "chainsaw"
                    elif m_roll < 0.11: w = "machete"
                    elif m_roll < 0.26: w = "knife"
                    elif m_roll < 0.50: w = "bat"
                    else: w = "crowbar"
                    self.player.add_weapon(w, is_melee=True)
                    self._add_floating_text(c["x"], c["y"]-30, f"БЛИЖНИЙ БОЙ: {MELEE_WEAPONS[w]['name']}", (150, 255, 150))
                else:
                    self._open_xp_crate(c)
                    continue
                    
                self.crates.remove(c)
                for _ in range(10):
                    self.blood.sparks.append({
                        "x": c["x"], "y": c["y"], "z": 20, 
                        "vx": random.uniform(-100, 100), "vy": random.uniform(-100, 100),
                        "vz": random.uniform(50, 150), "r": 3, "color": (255, 215, 0)
                    })
                break

    def choose(self, i):
        if 0 <= i < len(self.choices):
            up = self.choices[i]
            upgrades.apply(self.player, up)
            self._add_floating_text(self.player.x, self.player.y - 40,
                                    f"{up['title']} {upgrades.line(up)}", (255, 224, 120))
        self.state = "playing"
        self._check_levelup()

    def _check_levelup(self):
        if self.xp >= self.xp_needed and self.state == "playing":
            self.xp -= self.xp_needed
            self.level += 1
            self.xp_needed = int(self.xp_needed * XP_GROWTH) + 2
            self.choices = upgrades.roll(bool(self.cfg["guns"]))
            self.state = "levelup"

    def _add_floating_text(self, x, y, msg, color):
        self.floating_texts.append({"x": x, "y": y, "text": msg, "color": color, "life": 1.5, "vy": -50})

    def _difficulty(self):
        if self.mode == "waves":
            return self.wave * 0.8
        if self.mode == "dawn":
            return self.game_time / 24.0
        return self.game_time / 30.0

    def _make_boss(self, x, y):
        z = Zombie(x, y, 700 + self.wave * 70, 58 * self.cfg["zspeed"], 30, "tank", 32, 25)
        z.boss = True
        return z

    def _make_zombie(self, x, y):
        scale = self._difficulty()
        roll = random.random()
        if roll < 0.25:
            hp, speed, r, ztype, dmg, xp = 15 + scale * 10, 150 + scale * 20, 10, "fast", 6, 2
        elif roll < 0.45:
            hp, speed, r, ztype, dmg, xp = 120 + scale * 60, 40 + scale * 5, 20, "tank", 20, 5
        else:
            hp, speed, r, ztype, dmg, xp = 35 + scale * 20, 70 + scale * 10, 14, "normal", 10, 1
        return Zombie(x, y, hp, speed * self.cfg["zspeed"], r, ztype, dmg, xp)

    def _free_spot(self, cx, cy, dmin, dmax, r=24):
        x, y = cx, cy
        for _ in range(14):
            a = random.uniform(0, math.tau)
            d = random.uniform(dmin, dmax)
            x = max(60, min(WORLD_W - 60, cx + math.cos(a) * d))
            y = max(60, min(WORLD_H - 60, cy + math.sin(a) * d))
            if not any(dd.get("solid") and decor.circle_rect_hit(x, y, r, dd) for dd in self.decor):
                break
        return x, y

    def _populate_world(self):
        """Зомби живут по всей карте, а не только рядом с игроком: бродят и слушают."""
        px, py = self.player.x, self.player.y
        if self.cfg["spawn"] <= 0:
            return
        for _ in range(38 if not MOBILE else 20):
            x = random.randint(100, WORLD_W - 100)
            y = random.randint(100, WORLD_H - 100)
            if math.hypot(x - px, y - py) < 750:
                continue
            if any(dd.get("solid") and decor.circle_rect_hit(x, y, 30, dd) for dd in self.decor):
                continue
            self.zombies.append(self._make_zombie(x, y))

    def _spawn_enemy(self):
        x, y = self._free_spot(self.player.x, self.player.y, 600, 900)
        self.zombies.append(self._make_zombie(x, y))

    def _bullet_blocked_by_walls(self, b, px, py):
        line = ((px, py), (b.x, b.y))
        for bld in self.solid_buildings:
            ops = bld.get("openings", ())
            for op in ops:
                if op.get("broken"):
                    continue
                key = ("op", id(op))
                if key in b.walls_hit:
                    continue
                r = pygame.Rect(op["x"], op["y"], op["w"], op["h"])
                hit = r.clipline(line)
                if hit:
                    b.walls_hit.add(key)
                    pt = hit[0]
                    res = decor.damage_opening(op, 1, pt[0], pt[1])
                    self._opening_fx(op, pt, res)
                    if op["kind"] == "door" and res != "broken":
                        if b in self.bullets and b.pierce <= 0:
                            self.bullets.remove(b)
                            return True
                        b.pierce -= 1
                    if b.is_enemy and res != "broken":
                        if b in self.bullets:
                            self.bullets.remove(b)
                        return True
                    b.damage *= 0.9

            walls, _ = decor.building_parts(bld)
            for i, wr in enumerate(walls):
                key = (id(bld), i)
                if key in b.walls_hit:
                    continue
                hit = wr.clipline(line)
                if not hit:
                    continue
                pt = hit[0]
                if any((op.get("broken") or op["kind"] == "window") and
                       pygame.Rect(op["x"], op["y"], op["w"], op["h"]).collidepoint(pt)
                       for op in ops):
                    continue
                b.walls_hit.add(key)
                bld.setdefault("holes", []).append((pt[0], pt[1]))
                if len(bld["holes"]) > 50:
                    bld["holes"].pop(0)
                self.blood.add_debris(pt[0], pt[1], "wood", 6)
                self.hit_flashes.append({"x": pt[0], "y": pt[1], "life": 0.09, "max": 0.09})
                sounds.play_at("wood", pt[0], pt[1], 0.5, 1200)
                if b.is_enemy:
                    if b in self.bullets:
                        self.bullets.remove(b)
                    return True
                b.damage *= 0.55
        return False

    def _light_mask(self, radius):
        r = max(20, int(radius // 10) * 10)
        cached = self._light_cache.get(r)
        if cached is not None:
            return cached
        if self._light_base is None:
            size = 512
            base = pygame.Surface((size, size), pygame.SRCALPHA)
            c = size // 2
            for rr in range(c, 0, -4):
                a = int(205 * (1 - rr / c) ** 1.4)
                pygame.draw.circle(base, (0, 0, 0, a), (c, c), rr)
            self._light_base = base
        mask = pygame.transform.smoothscale(self._light_base, (r * 2, r * 2))
        self._light_cache[r] = mask
        return mask

    def _draw_lighting(self, surf, cx, cy):
        self.atm.draw_lighting(surf, self, cx, cy)

    def _push_out_of_buildings(self, e):
        r = getattr(e, "r", 14)
        for dd in self.decor:
            if not dd.get("solid"):
                continue
            if abs(e.x - dd["x"]) > dd["w"] / 2 + r + 6 or abs(e.y - dd["y"]) > dd["h"] / 2 + r + 6:
                continue
            walls, _ = decor.building_parts(dd)
            for wr in walls:
                cx = max(wr.left, min(e.x, wr.right))
                cy = max(wr.top, min(e.y, wr.bottom))
                dx, dy = e.x - cx, e.y - cy
                d2 = dx * dx + dy * dy
                if d2 < r * r:
                    if d2 > 0.001:
                        d = math.sqrt(d2)
                        e.x = cx + dx / d * r
                        e.y = cy + dy / d * r
                    else:
                        # внутри стены — выталкиваем по короткой стороне
                        px = min(r, wr.width / 2)
                        py = min(r, wr.height / 2)
                        if px < py:
                            e.x = wr.right + r if e.x >= wr.centerx else wr.left - r
                        else:
                            e.y = wr.bottom + r if e.y >= wr.centery else wr.top - r

    def _update_mode(self, dt):
        if self.mode == "dawn":
            self.dawn_t += dt
            if self.dawn_t >= self.cfg["goal_time"]:
                self._finish(True)
        elif self.mode == "waves":
            px, py = self.player.x, self.player.y
            if self.wave_state == "rest":
                self.wave_timer -= dt
                if self.wave_timer <= 0:
                    self.wave += 1
                    self.wave_left = 5 + self.wave * 3 + (1 if self.wave % 5 == 0 else 0)
                    self.wave_state = "fight"
                    self.wave_acc = 0.0
                    self._add_floating_text(px, py - 70, "ВОЛНА %d" % self.wave, (255, 90, 70))
                    sounds.play("stinger", 0.6)
            else:
                self.wave_acc -= dt
                if self.wave_left > 0 and self.wave_acc <= 0 and len(self.zombies) < (30 if not MOBILE else 18):
                    self.wave_acc = 0.4
                    for _ in range(random.randint(1, 3)):
                        if self.wave_left <= 0:
                            break
                        x, y = self._free_spot(px, py, 650, 950)
                        if self.wave % 5 == 0 and self.wave_left == 1:
                            z = self._make_boss(x, y)
                        else:
                            z = self._make_zombie(x, y)
                        z.state = "investigate"
                        z.investigate = (px, py)
                        z.hurry = 0.85
                        self.zombies.append(z)
                        self.wave_left -= 1
                elif self.wave_left <= 0 and not self.zombies:
                    self.wave_state = "rest"
                    self.wave_timer = 7.0
                    self.player.hp = min(self.player.max_hp, self.player.hp + 25)
                    self._add_floating_text(px, py - 70, "ВОЛНА %d ПРОЙДЕНА" % self.wave, (120, 255, 120))
                    for _ in range(2):
                        self.crates.append(self._make_crate())

    def _separate_zombies(self):
        """Мягко расталкиваем зомби, чтобы толпа не слипалась в одну точку."""
        zs = self.zombies
        cell = {}
        for z in zs:
            cell.setdefault((int(z.x // 48), int(z.y // 48)), []).append(z)
        for (cx_, cy_), grp in cell.items():
            for dx_ in (0, 1):
                for dy_ in (-1, 0, 1):
                    if dx_ == 0 and dy_ == -1:
                        continue
                    other = cell.get((cx_ + dx_, cy_ + dy_))
                    if other is None:
                        continue
                    for a in grp:
                        for b in other:
                            if a is b:
                                continue
                            ddx, ddy = b.x - a.x, b.y - a.y
                            d2 = ddx * ddx + ddy * ddy
                            mind = (a.r + b.r) * 0.85
                            if 0.01 < d2 < mind * mind:
                                d = math.sqrt(d2)
                                push = (mind - d) * 0.5
                                a.x -= ddx / d * push
                                a.y -= ddy / d * push
                                b.x += ddx / d * push
                                b.y += ddy / d * push

    def _spawn_tumbleweed(self):
        side = random.choice((-1, 1))
        x = self.player.x + side * random.uniform(450, 700)
        y = self.player.y + random.uniform(-260, 260)
        x = max(50, min(WORLD_W - 50, x))
        y = max(50, min(WORLD_H - 50, y))
        r = random.uniform(14, 22)
        vx = -side * random.uniform(55, 105)
        for _ in range(12):
            if not any(decor.circle_rect_hit(x, y, r, b) for b in self.solid_buildings):
                break
            a = random.uniform(0, math.tau)
            d = random.uniform(450, 700)
            x = max(50, min(WORLD_W - 50, self.player.x + math.cos(a) * d))
            y = max(50, min(WORLD_H - 50, self.player.y + math.sin(a) * d))
        self.tumbleweeds.append({
            "x": x, "y": y,
            "vx": vx, "vy": random.uniform(-18, 18),
            "r": r,
            "rot": random.uniform(0, math.tau),
            "spin": vx / max(4.0, r),
            "frames": decor.make_tumbleweed_frames(r),
            "z": 0.0, "vz": random.uniform(0, 30), "hop": random.uniform(0.8, 2.5),
            "life": random.uniform(12, 20),
            "dust": 0.0,
        })

    def _spawn_raider(self):
        a = random.uniform(0, math.tau)
        d = random.uniform(700, 1000)
        x = max(40, min(WORLD_W - 40, self.player.x + math.cos(a) * d))
        y = max(40, min(WORLD_H - 40, self.player.y + math.sin(a) * d))
        for _ in range(12):
            if not any(dd.get("solid") and decor.circle_rect_hit(x, y, 20, dd)
                       for dd in self.decor):
                break
            a = random.uniform(0, math.tau)
            d = random.uniform(700, 1000)
            x = max(40, min(WORLD_W - 40, self.player.x + math.cos(a) * d))
            y = max(40, min(WORLD_H - 40, self.player.y + math.sin(a) * d))
        scale = self.game_time / 60.0
        weapon_key = random.choice(("pistol", "revolver", "smg"))
        hp = 60 + scale * 40
        speed = 90 + scale * 15
        self.raiders.append(Raider(x, y, hp, speed, 16, weapon_key))

    def update(self, dt):
        if self.state in ("menu", "modes"):
            self.update_menu(dt)
            return
        if self.state != "playing" or self.admin_open:
            if self.touch.enabled:
                self.touch.release_all()
            return
        if self.hitstop > 0:
            self.hitstop -= dt
            return
        self.game_time += dt
        self._update_mode(dt)
        if self.state != "playing":
            return
        if self.flash > 0: self.flash -= dt
        if self.shake > 0: self.shake = max(0.0, self.shake - dt * 1.4)
        for f in self.hit_flashes:
            f["life"] -= dt
        self.hit_flashes = [f for f in self.hit_flashes if f["life"] > 0]
        
        # Запоминаем позицию ДО движения для проверки коллизий
        old_x, old_y = self.player.x, self.player.y
        
        keys, analog = self.keys_pressed, None
        if self.touch.enabled:
            self.touch.update(dt)
            keys = set(self.keys_pressed)
            if self.touch.sprint:
                keys.add(pygame.K_LSHIFT)
            analog = self.touch.move if self.touch.move != (0.0, 0.0) else None
            self.touch.has_light = bool(self.cfg["flash"])
            self.touch.near_crate = any(c["type"] != "xp" and
                                        math.hypot(self.player.x - c["x"], self.player.y - c["y"]) < 100
                                        for c in self.crates)
            for ev in self.touch.events:
                if ev == "reload": self.player.start_reload()
                elif ev == "interact": self._interact()
                elif ev == "light": self.toggle_flashlight()
                elif ev == "pause":
                    self.state = "paused"
            self.touch.events.clear()
            if self.state != "playing":
                return
        self.player.update(dt, keys, analog)
        
        # ПРОВЕРКА КОЛЛИЗИЙ С ДЕКОРОМ
        for d in self.decor:
            if d.get("solid"):
                if decor.building_hit(self.player.x, self.player.y, self.player.radius, d):
                    self.player.x, self.player.y = old_x, old_y
                    break
                continue
            if d["t"] == "rock":
                continue  # Камни низкие, через них перешагиваем
            if d["t"] == "cactus":
                if d.get("broken"): continue  # Сломанные кактусы не мешают
                rad = 15 * d["s"]
            elif d["t"] == "fence":
                rad = 20 * d["s"]
            else:
                continue
                
            if math.hypot(self.player.x - d["x"], self.player.y - d["y"]) < rad + self.player.radius:
                self.player.x = old_x
                self.player.y = old_y
                break
        
        mx, my = self.aim_screen()
        aim_now = math.atan2(my + self.camera.y - self.player.y, mx + self.camera.x - self.player.x)
        self.player.update_clearance(dt, aim_now)
        sounds.set_listener(self.player.x, self.player.y)
        self.alert_cd = max(0.0, self.alert_cd - dt)
        self.wind_t += dt

        if self.player.is_moving:
            self.step_timer -= dt
            if self.step_timer <= 0:
                self.step_timer = 0.34 if not self.player.is_sprinting else 0.22
                sounds.play("step", 0.22 if not self.player.is_sprinting else 0.32)
                if self.blood.on_glass(self.player.x, self.player.y):
                    sounds.play("crunch", 0.7)
                    self.extra_noises.append((self.player.x, self.player.y, 380.0, "glass"))

        if self.player.is_sprinting:
            self.dust_timer -= dt
            if self.dust_timer <= 0:
                self.blood.add_dust(self.player.x, self.player.y, self.player.move_angle)
                self.dust_timer = 0.04
        self.camera.update(self.player.x, self.player.y, WORLD_W, WORLD_H)

        # Перекати-поле
        self.tumble_timer -= dt
        if self.tumble_timer <= 0 and len(self.tumbleweeds) < 4:
            self._spawn_tumbleweed()
            self.tumble_timer = random.uniform(3.5, 7.0)
        gust = 0.75 + 0.45 * math.sin(self.wind_t * 0.35) + 0.25 * math.sin(self.wind_t * 1.3 + 1.7)
        for tw in self.tumbleweeds[:]:
            ox, oy = tw["x"], tw["y"]
            tw.setdefault("tvx", tw["vx"])
            tw["vx"] += (tw["tvx"] * gust - tw["vx"]) * min(1.0, dt * 0.8)
            tw["spin"] = tw["vx"] / max(4.0, tw["r"])
            if gust > 1.15 and tw["z"] <= 0.1 and random.random() < dt * 1.2:
                tw["vz"] = random.uniform(40, 85)          # порыв подбрасывает клубок
            tw["x"] += tw["vx"] * dt
            tw["y"] += tw["vy"] * dt
            for b in self.solid_buildings:
                if decor.circle_rect_hit(tw["x"], tw["y"], tw["r"], b):
                    tw["x"], tw["y"] = ox, oy
                    tw["vx"] *= -0.65
                    tw["tvx"] = -tw.get("tvx", tw["vx"]) * 0.7
                    tw["vy"] = tw["vy"] * -0.65 + random.uniform(-12, 12)
                    tw["spin"] = tw["vx"] / max(4.0, tw["r"])
                    tw["vz"] = max(tw["vz"], random.uniform(20, 45))
                    break
            tw["rot"] += tw["spin"] * dt
            tw["z"] += tw["vz"] * dt
            tw["vz"] -= 500 * dt
            if tw["z"] <= 0:
                tw["z"] = 0
                tw["vz"] = -tw["vz"] * 0.25 if tw["vz"] < -20 else 0
            tw["hop"] -= dt
            if tw["hop"] <= 0:
                tw["hop"] = random.uniform(1.5, 3.5)
                if tw["z"] <= 0.1:
                    tw["vz"] = random.uniform(22, 48)
            tw["life"] -= dt
            tw["dust"] -= dt
            if tw["dust"] <= 0:
                tw["dust"] = 0.16
                self.blood.add_dust(tw["x"], tw["y"], tw["rot"])
            if (tw["x"] < -80 or tw["x"] > WORLD_W + 80 or
                    tw["y"] < -80 or tw["y"] > WORLD_H + 80 or tw["life"] <= 0):
                self.tumbleweeds.remove(tw)

        for sh in self.shells[:]:
            sh["x"] += sh["vx"] * dt
            sh["y"] += sh["vy"] * dt
            sh["z"] += sh["vz"] * dt
            sh["vz"] -= 600 * dt
            sh["rot"] += sh["spin"] * dt
            if sh["z"] <= 0:
                sh["z"] = 0
                sh["vz"] = -sh["vz"] * 0.35 if sh["vz"] < -20 else 0
                sh["vx"] *= 0.7
                sh["vy"] *= 0.7
            sh["life"] -= dt
            if sh["life"] <= 0:
                self.shells.remove(sh)

        if self.blood.is_bloody(self.player.x, self.player.y):
            self.player.blood_charge = 1.0
            
        self.footprint_timer -= dt
        # Следы ТОЛЬКО если есть кровь на ботинках!
        if self.player.is_moving and self.player.blood_charge > 0 and self.footprint_timer <= 0:
            inten = self.player.blood_charge # Чем больше крови, тем ярче
            self.blood.add_footprint(self.player.x, self.player.y, self.player.move_angle, self.player.foot_side, inten)
            self.player.foot_side *= -1 # Чередуем ноги (1 -> -1 -> 1)
            
            # Тратим кровь на ботинках за каждый шаг
            self.player.blood_charge -= 0.2
            if self.player.blood_charge < 0: self.player.blood_charge = 0
            
            self.footprint_timer = 0.3 # Каждые 0.3 секунды
        
        mx, my = self.aim_screen()
        
        if not self.admin_open:
            # Стрельба (ЛКМ / правый стик)
            if self.cfg["guns"] and self.fire_held():
                self.player.shoot(mx + self.camera.x, my + self.camera.y, self.bullets, self.blood, self.shells)
                self.shake = max(self.shake, 0.05)
            
            # Ближний бой (ПРОБЕЛ или ПКМ); бензопила сначала заводится
            melee_held = self.melee_held()
            self.player.update_chainsaw(dt, melee_held)
            if melee_held:
                if self.player.do_melee(mx + self.camera.x, my + self.camera.y, self.blood):
                    if self.player.active_melee == "chainsaw":
                        self._melee_hit()
            if self.player.melee_hit_ready():
                self._melee_hit()
            if melee_held and not self.player.melee_weapon:
                self.player.do_kick(mx + self.camera.x, my + self.camera.y)
            if self.player.kick_hit_ready():
                self._melee_hit(kick=True)

        px, py = self.player.x, self.player.y
        inside_any = any(decor.inside_building(px, py, b) for b in self.solid_buildings)
        for op, opened in decor.update_openings(self.solid_buildings, dt, px, py):
            sounds.play_at("creak", op["x"] + op["w"] / 2, op["y"], 0.55 if opened else 0.4, 900)
        hidden = self.player.still_time >= 2.0 and inside_any

        noise_event = self.player.shot_noise
        self.player.shot_noise = None
        noises = list(self.extra_noises)
        self.extra_noises = []
        pl = self.player
        if pl.is_sprinting:
            # топот бегущего слышно по всей карте (в доме — приглушённо)
            noises.append((px, py, 2600.0 if inside_any else 9000.0, "run"))
        elif pl.is_moving:
            noises.append((px, py, 280.0 if self.mode != "nightmare" else 520.0, "walk"))
        if pl.active_melee == "chainsaw" and pl.chainsaw_spin > 0.3:
            noises.append((px, py, 1800.0, "saw"))
        if noise_event is not None:
            nx, ny, nr = noise_event
            for b in self.solid_buildings:
                if decor.inside_building(nx, ny, b):
                    door = next((op for op in b.get("openings", ())
                                 if op["kind"] == "door"), None)
                    if door is not None:
                        nx = door["x"] + door["w"] / 2
                        ny = door["y"] + door["h"] / 2
                    break
            noises.append((nx, ny, nr, "shot"))
            sounds.play("echo_" + pl.active_gun, 0.35)
            sounds.play("boom", 0.4 if pl.active_gun in ("shotgun", "sniper", "revolver", "sawnoff") else 0.25)

        for z in self.zombies:
            dist = math.hypot(z.x - px, z.y - py)
            see = (not hidden and dist < 620 * z.boost and
                   not decor.line_blocked(z.x, z.y, px, py))
            z.nav = self._nav
            z.boost = 1.15 if (self.flash_on and self.cfg["flash"]) else 1.0   # свет привлекает: быстрее
            z.update(dt, px, py, active=see, noises=noises)
            if z.alert_ready and self.alert_cd <= 0 and dist < 3000:
                self.alert_cd = 0.12
                sounds.play_at("z_alert", z.x, z.y, 0.9, 3200)
            z.idle_snd -= dt
            if z.idle_snd <= 0:
                z.idle_snd = random.uniform(5.0, 15.0)
                sounds.play_at("z_moan", z.x, z.y, 0.7, 1300)
        self._separate_zombies()
        for r in self.raiders:
            dist = math.hypot(r.x - px, r.y - py)
            see = (not hidden and dist < 650 and
                   not decor.line_blocked(r.x, r.y, px, py))
            r.update(dt, px, py, self.bullets, active=see)
        for e in self.zombies + self.raiders:
            self._push_out_of_buildings(e)

        for b in self.bullets[:]:
            # Сохраняем прошлую позицию для проверки столкновений (чтобы пули не пролетали сквозь зомби)
            prev_x, prev_y = b.x, b.y
            if not b.update(dt):
                self.bullets.remove(b)
                continue
                
            angle = math.atan2(b.vy, b.vx)
            if self._bullet_blocked_by_walls(b, prev_x, prev_y):
                continue

            if b.is_enemy:
                if math.hypot(b.x - self.player.x, b.y - self.player.y) < self.player.radius + b.radius:
                    self.player.take_damage(b.damage)
                    self.flash = 0.28
                    self.blood.hit(b.x, b.y, angle, 20)
                    self.bullets.remove(b)
            else:
                for tw in self.tumbleweeds[:]:
                    if seg_dist(tw["x"], tw["y"] - tw.get("z", 0), prev_x, prev_y, b.x, b.y) < tw["r"] + b.radius:
                        self._pop_tumbleweed(tw, angle)
                        b.damage *= 0.85
                # Проверка пуль в кактусы
                hit_cactus = False
                for d in self.decor:
                    if d["t"] == "cactus" and not d.get("broken", False):
                        cy = d["y"] - 15 * d["s"]
                        dist_to_cactus = seg_dist(d["x"], cy, prev_x, prev_y, b.x, b.y)
                        
                        if dist_to_cactus < 20 * d["s"] + b.radius:
                            if not d.get("broken"):
                                d["broken"] = True
                                # Вызываем взрыв кактуса (зеленые брызги и осколки)
                                self.blood.add_cactus_explosion(d["x"], d["y"] - 16 * d["s"])
                            
                            if b.pierce <= 0:
                                if b in self.bullets:
                                    self.bullets.remove(b)
                                hit_cactus = True
                                break
                            else:
                                b.pierce -= 1
                if hit_cactus: continue

                targets = self.zombies + self.raiders
                for t in targets:
                    if t.hp > 0 and id(t) not in b.hit_targets:
                        # Проверяем расстояние от центра зомби до отрезка пути пули
                        dist = seg_dist(t.x, t.y, prev_x, prev_y, b.x, b.y)
                        if dist < t.r + b.radius + 2: # +2 пикселя на щедрый хитбокс
                            dist = math.hypot(b.x - b.start_x, b.y - b.start_y)
                            dmg_mult = max(0.2, 1.0 - (dist / 1500.0))
                            actual_dmg = b.damage * dmg_mult
                            
                            t.last_hit_dist = dist
                            if hasattr(t, 'take_hit'):
                                is_headshot = t.take_hit(actual_dmg, angle, self.blood, can_dismember=False,
                                                         is_melee=False, weapon_key=getattr(b, 'weapon_key', ''),
                                                         strength=max(1.0, actual_dmg / 30.0) * self.player.dmg_mult)
                                if is_headshot:
                                    self._add_floating_text(t.x, t.y - 30, "HEADSHOT!", (255, 255, 0))
                            else:
                                t.hp -= actual_dmg
                                
                            b.hit_targets.add(id(t))
                            self.blood.hit(b.x, b.y, angle, actual_dmg, dist)
                            self.hit_flashes.append({"x": b.x, "y": b.y, "life": 0.09, "max": 0.09})
                            for _ in range(2):
                                sa = angle + random.uniform(-1.4, 1.4)
                                spd = random.uniform(60, 180)
                                self.blood.sparks.append({"x": b.x, "y": b.y, "z": random.uniform(8, 22),
                                                          "vx": math.cos(sa) * spd, "vy": math.sin(sa) * spd,
                                                          "vz": random.uniform(20, 70), "r": 1,
                                                          "color": (120, 18, 14)})
                            
                            if b.pierce > 0: 
                                b.pierce -= 1
                            else:
                                # Пуля застревает в зомби (1.2% шанс убран)
                                if b in self.bullets: self.bullets.remove(b)
                                break

        self.crate_timer -= dt
        if self.crate_timer <= 0 and len(self.crates) < 22:
            self.crates.append(self._make_crate())
            self.crate_timer = 9.0

        self.spawn_timer -= dt
        if self.spawn_timer <= 0:
            near_cnt = sum(1 for z in self.zombies
                           if abs(z.x - px) < 1100 and abs(z.y - py) < 1100)
            near_cap, total_cap = (15, 60) if not MOBILE else (10, 34)
            # ОГРАНИЧЕНИЕ: рядом с игроком и на всей карте
            if self.cfg["spawn"] <= 0:
                self.spawn_timer = 5.0      # в режиме «Орда» зомби приходят волнами
            elif near_cnt < near_cap and len(self.zombies) < total_cap:
                self._spawn_enemy()
                prog = (self.dawn_t / self.cfg.get("goal_time", 1e9)) if self.mode == "dawn" else 0.0
                interval = max(0.3, 1.5 - self.game_time * 0.015) / (self.cfg["spawn"] * (1.0 + 0.7 * prog))
                self.spawn_timer = interval * random.uniform(0.7, 1.3)
            else:
                # Если лимит достигнут, просто ждем, пока кто-то умрет
                self.spawn_timer = 1.0

        # Бандиты появляются позже зомби и реже
        if self.game_time > 30 and self.mode != "waves":
            self.raider_timer -= dt
            if self.raider_timer <= 0:
                if len(self.raiders) < 3:
                    self._spawn_raider()
                    self.raider_timer = random.uniform(20.0, 30.0)
                else:
                    self.raider_timer = 1.0

        px, py = self.player.x, self.player.y

        for c in self.crates[:]:
            if c["type"] == "xp" and math.hypot(px - c["x"], py - c["y"]) < 34:
                self._open_xp_crate(c)

        for z in self.zombies:
            d = math.hypot(z.x - px, z.y - py)
            
            # ЛОГИКА СЛЕДОВ ДЛЯ ЗОМБИ
            if self.blood.is_bloody(z.x, z.y):
                z.bloody_timer = 7.0
                
            z.footprint_timer -= dt
            if z.bloody_timer > 0:
                z.bloody_timer -= dt
                if z.footprint_timer <= 0:
                    # Оставляем след, если зомби двигался
                    if z.speed > 0:
                        self.blood.add_footprint(z.x, z.y, z.facing, 1, 0.8)
                        z.footprint_timer = 0.4 # Зомби оставляют следы реже

            if z.growl_ready:
                z.growl_ready = False
                sounds.play("growl", max(0.0, 0.55 - d / 1400.0))
            if z.bite_ready:
                z.bite_ready = False
                if d < z.r + self.player.radius + 14:
                    self.player.take_damage(z.dmg)
                    self.flash = 0.28
                    self.blood.hit(px, py, z.facing, 15)
                    sounds.play("bite", max(0.15, 0.7 - d / 900.0))

        # Раны продолжают кровоточить: капли падают на землю
        for e in self.zombies + self.raiders:
            if e.bleed_timer > 0:
                e.bleed_timer -= dt
                e.bleed_spawn -= dt
                if e.bleed_spawn <= 0:
                    e.bleed_spawn = random.uniform(0.14, 0.32)
                    self.blood.wound_drip(e.x, e.y, e.facing)

        alive_z = []
        for z in self.zombies:
            if z.hp <= 0:
                self.kills += 1
                self.hitstop = max(self.hitstop, 0.035)
                self.shake = max(self.shake, 0.16)
                self.orbs.append({"x": z.x, "y": z.y, "v": z.xp})
                sounds.play_at("thud", z.x, z.y, 0.8, 1100)
                dist = math.hypot(z.x - self.player.x, z.y - self.player.y)
                self.blood.death(z.x, z.y, getattr(z, 'last_splash_angle', z.facing), getattr(z, 'last_dmg', 30))
                wound = self._gore_kind(z)
                zs = z.r / 14.0
                if wound == "blast":
                    self.blood.gore_pile(z.x, z.y, getattr(z, 'last_splash_angle', z.facing), True, size=zs)
                    self.shake = max(self.shake, 0.28)
                elif wound == "saw":
                    # кишки торчат из тела (рисуются на трупе), на земле — только кровь и ошмётки
                    self.blood.gore_pile(z.x, z.y, getattr(z, 'last_splash_angle', z.facing), False, size=zs, organs=False)
                col = (90, 130, 70) if z.type == "normal" else (170, 130, 60) if z.type == "fast" else (60, 90, 50)
                self.corpses.append(Corpse(
                    z.x, z.y, z.facing, getattr(z, 'last_hit_angle', z.facing + math.pi),
                    getattr(z, 'last_dmg', 30), col, (58, 46, 34), (34, 34, 52), z.limbs,
                    scale=zs, jaw=getattr(z, 'jaw', 'normal'), wound=wound,
                    launch={'blast': 150.0, 'saw': 12.0}.get(wound)))
            else:
                alive_z.append(z)
        self.zombies = alive_z

        alive_r = []
        for r in self.raiders:
            if r.hp <= 0:
                self.kills += 1
                self.hitstop = max(self.hitstop, 0.035)
                self.shake = max(self.shake, 0.16)
                self.orbs.append({"x": r.x, "y": r.y, "v": 10})
                self.blood.death(r.x, r.y, getattr(r, 'last_splash_angle', 0), getattr(r, 'last_dmg', 30))
                wound = self._gore_kind(r)
                if wound == "blast":
                    self.blood.gore_pile(r.x, r.y, getattr(r, 'last_splash_angle', 0), True)
                elif wound == "saw":
                    self.blood.gore_pile(r.x, r.y, getattr(r, 'last_splash_angle', 0), False, organs=False)
                away = math.atan2(r.y - py, r.x - px)
                self.corpses.append(Corpse(
                    r.x, r.y, away + math.pi, getattr(r, 'last_hit_angle', away), 40,
                    (204, 156, 112), (160, 60, 60), (52, 48, 44),
                    r.limbs, raider=True, scale=r.r / 14.0, wound=wound,
                    launch={'blast': 150.0, 'saw': 12.0}.get(wound)))
            else:
                alive_r.append(r)
        self.raiders = alive_r

        for c in self.corpses:
            c.update(dt)
        self.corpses = [c for c in self.corpses if c.life > 0]

        if self.player.hp <= 0:
            self.player.hp = 0
            self._finish(False)
            return

        for o in self.orbs:
            dx, dy = px - o["x"], py - o["y"]
            d = math.hypot(dx, dy) or 1
            if d < 150:
                o["x"] += dx / d * 350 * dt
                o["y"] += dy / d * 350 * dt
            if d < 25:
                o["dead"] = True
                self.xp += o["v"]
        self.orbs = [o for o in self.orbs if not o.get("dead")]

        for t in self.floating_texts:
            t["y"] += t["vy"] * dt
            t["life"] -= dt
        self.floating_texts = [t for t in self.floating_texts if t["life"] > 0]

        # ПРОВЕРКА: ЛЕТЯТ ЛИ КАПЛИ В ИГРОКА (Кровь на шляпу)
        aim = math.atan2(my + self.camera.y - self.player.y, mx + self.camera.x - self.player.x)
        hat_x = self.player.x - math.cos(aim) * 3.5
        hat_y = self.player.y - math.sin(aim) * 3.5
        for p in self.blood.sparks[:]:
            if p.get("blood"):
                dist = math.hypot(p["x"] - hat_x, p["y"] - hat_y)
                # Капля должна пролетать над полями шляпы, а не над телом
                if dist < 17 and 10 < p.get("z", 0) < 45:
                    # Проверяем, летит ли она В СТОРОНУ игрока
                    dot = p["vx"] * (self.player.x - p["x"]) + p["vy"] * (self.player.y - p["y"])
                    if dot > 0:
                        angle = math.atan2(p["vy"], p["vx"])
                        self.player.add_hat_blood(angle)
                        self.blood.sparks.remove(p)
                        continue

        # Кровь, которая долетела до стены дома
        for p in self.blood.sparks[:]:
            if not p.get("blood"):
                continue
            for b in self.solid_buildings:
                walls, _ = decor.building_parts(b)
                hit = any(decor.circle_rect_hit_rect(p["x"], p["y"], p.get("r", 2), wr)
                          for wr in walls)
                if hit:
                    wx = max(b["x"] - b["w"] / 2 + 8, min(p["x"], b["x"] + b["w"] / 2 - 8))
                    wy = b["y"] + b["h"] / 2 - 5
                    self.blood.add_wall_splat(wx, wy, p.get("r", 2),
                                              math.atan2(p["vy"], p["vx"]))
                    self.hit_flashes.append({"x": wx, "y": wy, "life": 0.07, "max": 0.07})
                    if p in self.blood.sparks:
                        self.blood.sparks.remove(p)
                    break

        self.blood.update(dt)
        self.atm.update(self, dt)
        self._check_levelup()

    def _draw_mode_hud(self, surf):
        cx = WIDTH // 2
        if self.mode == "waves":
            if self.wave_state == "rest":
                text(surf, "ВОЛНА %d · СЛЕДУЮЩАЯ ЧЕРЕЗ %d" % (self.wave + 1, max(0, int(self.wave_timer) + 1)),
                     "md", cx, 70, (255, 214, 92), center=True)
            else:
                left = self.wave_left + len(self.zombies)
                text(surf, "ВОЛНА %d · ОСТАЛОСЬ %d" % (self.wave, left), "md", cx, 70, (255, 120, 90), center=True)
        elif self.mode == "dawn":
            left = max(0, self.cfg["goal_time"] - self.dawn_t)
            text(surf, "ДО РАССВЕТА  %s" % menu.fmt_time(left), "md", cx, 70, (255, 214, 130), center=True)
        elif self.mode != "free":
            text(surf, self.cfg["name"], "sm", cx, 70, (212, 200, 176), center=True)

    def draw(self, surf):
        if self.state in ("menu", "modes"):
            self.draw_menu_scene(surf)
            if self.state == "menu":
                menu.draw_menu(surf, self)
            else:
                ov = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
                ov.fill((0, 0, 0, 150))
                surf.blit(ov, (0, 0))
                menu.draw_modes(surf, self)
            return
        surf.fill(SAND)
        cx, cy = self.camera.x, self.camera.y
        if self.shake > 0:
            amp = min(1.0, self.shake / 0.16) * 4
            cx += random.uniform(-amp, amp)
            cy += random.uniform(-amp, amp)
        
        decor.draw_floors(surf, self.decor, cx, cy, self.player.x, self.player.y)
        self.blood.draw_ground(surf, cx, cy)
        decor.draw_all(surf, self.decor, cx, cy, self.player.x, self.player.y)
        self.blood.draw_dust(surf, cx, cy)
        for tw in self.tumbleweeds:
            decor.draw_tumbleweed(surf, tw, cx, cy)

        for sh in self.shells:
            sx = int(sh["x"] - cx)
            sy = int(sh["y"] - cy - sh["z"])
            if not (-20 < sx < WIDTH + 20 and -20 < sy < HEIGHT + 20):
                continue
            if sh["z"] > 0:
                pygame.draw.ellipse(surf, (110, 88, 58), (sx - 2, int(sh["y"] - cy) - 1, 4, 2))
            ca, sa = math.cos(sh["rot"]), math.sin(sh["rot"])
            pts = [(sx + ca * 4 - sa * 2, sy + sa * 4 + ca * 2),
                   (sx + ca * 4 + sa * 2, sy + sa * 4 - ca * 2),
                   (sx - ca * 4 + sa * 2, sy - sa * 4 - ca * 2),
                   (sx - ca * 4 - sa * 2, sy - sa * 4 + ca * 2)]
            pygame.draw.polygon(surf, (214, 174, 76), pts)
            pygame.draw.line(surf, (120, 88, 34), pts[0], pts[3], 1)

        for c in self.crates:
            box_x, box_y = int(c["x"] - cx), int(c["y"] - cy)
            if -50 < box_x < WIDTH + 50 and -50 < box_y < HEIGHT + 50:
                
                if c["type"] == "gun":
                    pygame.draw.rect(surf, (85, 107, 47), (box_x - 15, box_y - 15, 30, 30))
                    pygame.draw.rect(surf, (30, 30, 30), (box_x - 15, box_y - 15, 30, 30), 3)
                    pygame.draw.line(surf, (220, 220, 220), (box_x - 10, box_y - 5), (box_x + 10, box_y - 5), 2)
                    pygame.draw.line(surf, (220, 220, 220), (box_x, box_y - 5), (box_x + 2, box_y + 2), 2)
                elif c["type"] == "melee":
                    pygame.draw.rect(surf, (139, 0, 0), (box_x - 15, box_y - 15, 30, 30))
                    pygame.draw.rect(surf, (30, 30, 30), (box_x - 15, box_y - 15, 30, 30), 3)
                    pygame.draw.line(surf, (200, 200, 200), (box_x - 6, box_y + 6), (box_x + 8, box_y - 8), 3)
                else:
                    pygame.draw.rect(surf, (160, 82, 45), (box_x - 15, box_y - 15, 30, 30))
                    pygame.draw.rect(surf, (100, 40, 20), (box_x - 15, box_y - 15, 30, 30), 3)
                    pygame.draw.line(surf, (120, 60, 30), (box_x - 13, box_y - 13), (box_x + 13, box_y + 13), 4)
                    pygame.draw.line(surf, (120, 60, 30), (box_x + 13, box_y - 13), (box_x - 13, box_y + 13), 4)
                    for sx, sy in [(-11, -11), (11, -11), (-11, 11), (11, 11)]:
                        pygame.draw.circle(surf, (30, 30, 30), (box_x + sx, box_y + sy), 2)

                if math.hypot(self.player.x - c["x"], self.player.y - c["y"]) < 100:
                    if c["type"] == "gun": t_str = "ВЗЯТЬ: оружие" if self.touch.enabled else "[E] Оружие"
                    elif c["type"] == "melee": t_str = "ВЗЯТЬ: ближний бой" if self.touch.enabled else "[E] Ближний бой"
                    else: t_str = "Наступи, чтобы взять"
                    
                    if c["type"] != "xp":
                        text(surf, t_str, "sm", box_x, box_y - 45, (255, 255, 100), center=True)

        for o in self.orbs:
            ox, oy = int(o["x"] - cx), int(o["y"] - cy)
            pygame.draw.circle(surf, (255, 220, 90), (ox, oy), 7)
        
        self.blood.draw_limbs_ground(surf, cx, cy)
        for c in self.corpses:
            c.draw(surf, cx, cy)
        
        for z in self.zombies: z.draw(surf, self.player.x, self.player.y, cx, cy)
        for r in self.raiders: r.draw(surf, cx, cy)
        for b in self.bullets: b.draw(surf, cx, cy)
        
        mx, my = self.aim_screen()
        self.player.draw(surf, cx, cy, mx + cx, my + cy)
        
        self.blood.draw_air(surf, cx, cy)

        for t in self.floating_texts:
            fx, fy = int(t["x"] - cx), int(t["y"] - cy)
            text(surf, t["text"], "md", fx, fy, t["color"], center=True)

        # крыши домов перекрывают всё, что внутри, если игрок снаружи
        decor.draw_roofs(surf, self.decor, cx, cy, self.player.x, self.player.y)
        self.blood.draw_walls(surf, cx, cy)
        self.atm.draw_fog(surf, cx, cy)
        self._draw_lighting(surf, cx, cy)
        for z in self.zombies:
            if abs(z.x - self.player.x) < 1000 and abs(z.y - self.player.y) < 800:
                z.draw_eyes(surf, cx, cy, 1.0 if z.state == "chase" else 0.65)
        self.atm.draw_post(surf, self)

        if self.flash > 0:
            ov = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
            ov.fill((200, 30, 30, int(90 * (self.flash / 0.28))))
            surf.blit(ov, (0, 0))

        if not self.admin_open:
            ui.draw_hud(surf, self)
            self._draw_mode_hud(surf)
            if self.state == "playing":
                self.touch.draw(surf, self)

        if self.state == "playing" and not self.admin_open and (not self.touch.enabled or self.touch.fire):
            pygame.draw.circle(surf, (255, 50, 50), (mx, my), 12, 2)
            pygame.draw.line(surf, (255, 50, 50), (mx - 18, my), (mx + 18, my), 2)
            pygame.draw.line(surf, (255, 50, 50), (mx, my - 18), (mx, my + 18), 2)

        if self.admin_open: 
            ui.draw_admin_panel(surf, self)
        elif self.state == "paused": 
            menu.draw_pause(surf, self)
        elif self.state == "levelup": 
            ui.draw_levelup(surf, self)
        elif self.state in ("gameover", "victory"):
            menu.draw_end(surf, self, self.state == "victory")
