"""Экраны: главное меню, выбор режима, пауза, конец игры. Фон меню — живая сцена с зомби."""
import math
import random
import pygame
from .config import WIDTH, HEIGHT, MOBILE
from .utils import text
from .fonts import get as get_font
from .modes import MODES, BY_ID
from . import savedata


def fmt_time(sec):
    sec = int(sec)
    return "%d:%02d" % (sec // 60, sec % 60)


def wrap(s, size, width):
    font = get_font(size)
    words, lines, cur = s.split(), [], ""
    for w in words:
        t = (cur + " " + w).strip()
        if font.size(t)[0] <= width:
            cur = t
        else:
            lines.append(cur)
            cur = w
    if cur:
        lines.append(cur)
    return lines


def draw_button(surf, rect, label, hover=False, primary=False, size="lg"):
    base = (112, 24, 20) if primary else (58, 40, 24)
    if hover:
        base = tuple(min(255, c + 26) for c in base)
    sh = rect.move(0, 5)
    pygame.draw.rect(surf, (14, 8, 4), sh, border_radius=14)
    pygame.draw.rect(surf, base, rect, border_radius=14)
    pygame.draw.rect(surf, (255, 214, 92) if hover or primary else (196, 156, 82), rect, 3, border_radius=14)
    # доски
    for i in (1, 2):
        yy = rect.y + rect.h * i // 3
        pygame.draw.line(surf, tuple(max(0, c - 14) for c in base), (rect.x + 12, yy), (rect.right - 12, yy), 1)
    text(surf, label, size, rect.centerx, rect.centery, (255, 240, 200), center=True)


def _col(n, w, h, gap, cy):
    return [pygame.Rect(WIDTH // 2 - w // 2, cy + i * (h + gap), w, h) for i in range(n)]


# ------------------------------------------------------------------ главное меню
def menu_buttons():
    n = 2 if MOBILE else 3
    rects = _col(n, 380, 78, 20, 360)
    ids = [("play", "ИГРАТЬ"), ("modes", "РЕЖИМЫ"), ("quit", "ВЫХОД")][:n]
    return [(i, r, l) for (i, l), r in zip(ids, rects)]


def draw_menu(surf, game):
    t = game.menu_t
    cx = WIDTH // 2
    # заголовок: кровавый, с дрожью при вспышках молний
    jit = int(game.atm.flash * 4)
    ox = random.randint(-jit, jit) if jit else 0
    text(surf, "ДИКИЙ ЗАПАД", "xxl", cx + ox, 92, (214, 60, 46), center=True)
    text(surf, "КРОВАВЫЙ ВИХРЬ", "xl", cx + ox, 160, (255, 226, 190), center=True)
    # подтёки
    for i, dx in enumerate((-250, -120, 30, 170, 260)):
        ln = 14 + 10 * (1 + math.sin(t * 0.8 + i * 2.1))
        pygame.draw.line(surf, (150, 22, 18), (cx + dx, 188), (cx + dx, 188 + ln), 3)
        pygame.draw.circle(surf, (150, 22, 18), (cx + dx, int(188 + ln)), 3)
    mode = BY_ID[game.mode]
    text(surf, "РЕЖИМ: " + mode["name"], "md", cx, 262, (255, 214, 92), center=True)
    text(surf, mode["goal"], "sm", cx, 292, (212, 200, 176), center=True)
    mouse = pygame.mouse.get_pos()
    for bid, r, label in menu_buttons():
        draw_button(surf, r, label, r.collidepoint(mouse) and not MOBILE, primary=(bid == "play"))
    text(surf, "v2 • ночь • зомби слышат бег", "sm", cx, HEIGHT - 26, (150, 140, 120), center=True)


# ------------------------------------------------------------------ выбор режима
def mode_cards():
    n = len(MODES)
    gap = 16
    w = (WIDTH - 60 - gap * (n - 1)) // n
    return [pygame.Rect(30 + i * (w + gap), 150, w, 410) for i in range(n)]


def back_button():
    return pygame.Rect(WIDTH // 2 - 130, HEIGHT - 100, 260, 64)


def draw_modes(surf, game):
    cx = WIDTH // 2
    text(surf, "РЕЖИМЫ", "xl", cx, 70, (255, 226, 190), center=True)
    text(surf, "Нажми на карточку, чтобы выбрать", "sm", cx, 112, (212, 200, 176), center=True)
    mouse = pygame.mouse.get_pos()
    for m, r in zip(MODES, mode_cards()):
        sel = m["id"] == game.mode
        hover = r.collidepoint(mouse) and not MOBILE
        bg = (86, 24, 20) if sel else ((70, 50, 30) if hover else (46, 32, 22))
        pygame.draw.rect(surf, (12, 6, 2), r.move(0, 6), border_radius=16)
        pygame.draw.rect(surf, bg, r, border_radius=16)
        pygame.draw.rect(surf, (255, 214, 92) if sel else (170, 134, 70), r, 4 if sel else 2, border_radius=16)
        nsize = "md" if get_font("md").size(m["name"])[0] <= r.w - 18 else "sm"
        lines = wrap(m["name"], nsize, r.w - 18)
        y = r.y + 24
        for ln in lines:
            text(surf, ln, nsize, r.centerx, y, (255, 214, 92) if sel else (255, 240, 200), center=True)
            y += 28
        y += 8
        for ln in wrap(m["desc"], "sm", r.w - 28):
            text(surf, ln, "sm", r.centerx, y, (225, 214, 190), center=True, shadow=False)
            y += 21
        b = savedata.best(m["id"])
        by = r.bottom - 128
        for ln in wrap(m["goal"], "sm", r.w - 24):
            text(surf, ln, "sm", r.centerx, by, (150, 210, 150), center=True, shadow=False)
            by += 20
        if b:
            if m["id"] == "waves":
                rec = "Волна %d" % b.get("wave", 0)
            elif m["id"] == "dawn":
                rec = ("Рассвет за " + fmt_time(b.get("time", 0))) if b.get("won") else "—"
            else:
                rec = "%d уб. • %s" % (b.get("kills", 0), fmt_time(b.get("time", 0)))
            lines_r = wrap("Рекорд: " + rec, "sm", r.w - 24)
            col = (255, 220, 120)
        else:
            lines_r, col = ["Рекорда нет"], (150, 140, 120)
        by += 8
        for ln in lines_r:
            text(surf, ln, "sm", r.centerx, by, col, center=True, shadow=False)
            by += 20
        if sel:
            text(surf, "ВЫБРАН", "sm", r.centerx, r.bottom - 18, (255, 214, 92), center=True)
    draw_button(surf, back_button(), "НАЗАД", back_button().collidepoint(mouse) and not MOBILE, size="md")


# ------------------------------------------------------------------ пауза / конец
def pause_buttons():
    ids = [("resume", "ПРОДОЛЖИТЬ"), ("restart", "ЗАНОВО"), ("menu", "В МЕНЮ")]
    return [(i, r, l) for (i, l), r in zip(ids, _col(3, 340, 66, 16, HEIGHT // 2 - 40))]


def end_buttons():
    ids = [("restart", "ЗАНОВО"), ("menu", "В МЕНЮ")]
    return [(i, r, l) for (i, l), r in zip(ids, _col(2, 340, 66, 16, 520))]


def draw_pause(surf, game):
    ov = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
    ov.fill((0, 0, 0, 170))
    surf.blit(ov, (0, 0))
    text(surf, "ПАУЗА", "xl", WIDTH // 2, HEIGHT // 2 - 110, (255, 255, 255), center=True)
    mouse = pygame.mouse.get_pos()
    for bid, r, label in pause_buttons():
        draw_button(surf, r, label, r.collidepoint(mouse) and not MOBILE, primary=(bid == "resume"), size="md")


def draw_end(surf, game, victory):
    ov = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
    ov.fill((10, 30, 10, 205) if victory else (40, 0, 0, 205))
    surf.blit(ov, (0, 0))
    cx = WIDTH // 2
    if victory:
        text(surf, "РАССВЕТ!", "xl", cx, 110, (255, 214, 120), center=True)
        text(surf, "Ты пережил эту ночь", "md", cx, 170, (240, 230, 200), center=True)
    else:
        text(surf, "ТЫ ПАЛ...", "xl", cx, 110, (225, 70, 60), center=True)
    y = 235
    text(surf, "Режим: " + BY_ID[game.mode]["name"], "md", cx, y, (255, 214, 92), center=True)
    y += 50
    if game.mode == "waves":
        text(surf, "Дошёл до волны: %d" % game.wave, "lg", cx, y, (255, 232, 190), center=True)
        y += 44
    text(surf, "Уровень: %d" % game.level, "lg", cx, y, (255, 232, 190), center=True)
    text(surf, "Зомби убито: %d" % game.kills, "lg", cx, y + 44, (255, 232, 190), center=True)
    text(surf, "Продержался: %s" % fmt_time(game.game_time), "lg", cx, y + 88, (255, 232, 190), center=True)
    if getattr(game, "new_record", False):
        text(surf, "НОВЫЙ РЕКОРД!", "lg", cx, y + 140, (120, 255, 120), center=True)
    mouse = pygame.mouse.get_pos()
    for bid, r, label in end_buttons():
        draw_button(surf, r, label, r.collidepoint(mouse) and not MOBILE, primary=(bid == "restart"), size="md")
