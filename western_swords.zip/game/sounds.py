"""Звук: настоящие CC0-записи + синтезированные слои (ветер, сердцебиение, грозы, зомби).
Стерео, позиционный звук (громкость по расстоянию + панорама). Нет микшера — игра молчит."""
import math
import random
from pathlib import Path
import pygame

SR = 44100
_sounds = {}
_ok = False
_loops = {}
_DIR = Path(__file__).resolve().parent.parent / "assets" / "sounds"
_listener = [0.0, 0.0]


def _load(name, files):
    bank = []
    for f in files:
        p = _DIR / f
        if p.exists():
            try:
                bank.append(pygame.mixer.Sound(str(p)))
            except Exception:
                pass
    if bank:
        _sounds[name] = bank


def init():
    global _ok
    if _ok:
        return
    try:
        pygame.mixer.quit()
        pygame.mixer.init(SR, -16, 2, 512)
        pygame.mixer.set_num_channels(40)
        pygame.mixer.set_reserved(4)          # 0..3 — постоянные петли (ветер, дрон, пила)
        _load("pistol", ["pistol.ogg"])
        _load("revolver", ["revolver.ogg"])
        _load("smg", ["smg.ogg"])
        _load("shotgun", ["shotgun.ogg"])
        _load("sawnoff", ["sawnoff.ogg"])
        _load("sniper", ["sniper.ogg"])
        _load("reload_start", ["reload_start.ogg"])
        _load("reload_end", ["reload_end.ogg"])
        _load("cock", ["cock.ogg"])
        _load("empty", ["empty.ogg"])
        _load("shell", ["shell.ogg"])
        _load("hit_flesh", ["hit1.ogg", "hit2.ogg", "hit3.ogg"])
        _load("swing", ["swing1.ogg", "swing2.ogg", "swing3.ogg"])
        _load("step", ["step1.ogg", "step2.ogg", "step3.ogg"])
        _load("glass", ["glass1.ogg", "glass2.ogg", "glass3.ogg", "glass4.ogg"])
        _load("wood", ["wood1.ogg", "wood2.ogg", "wood3.ogg", "wood4.ogg"])
        _load("growl", ["zombie10.ogg", "zombie11.ogg", "zombie12.ogg"])
        _load("bite", ["zombie13.ogg", "zombie24.ogg"])
        # --- новые слои (assets/sounds/*.ogg, создаются tools/make_sounds.py) ---
        for gun in ("pistol", "revolver", "smg", "shotgun", "sawnoff", "sniper"):
            _load("echo_" + gun, ["echo_%s.ogg" % gun])
        _load("boom", ["boom.ogg"])
        _load("amb_wind", ["amb_wind.ogg"])
        _load("amb_drone", ["amb_drone.ogg"])
        _load("heartbeat", ["heartbeat.ogg"])
        _load("breath", ["breath.ogg"])
        _load("thunder", ["thunder1.ogg", "thunder2.ogg"])
        _load("z_alert", ["z_alert1.ogg", "z_alert2.ogg"])
        _load("z_moan", ["z_moan1.ogg", "z_moan2.ogg", "z_moan3.ogg"])
        _load("creak", ["creak1.ogg", "creak2.ogg"])
        _load("twig", ["twig1.ogg", "twig2.ogg", "twig3.ogg"])
        _load("crunch", ["crunch1.ogg", "crunch2.ogg", "crunch3.ogg"])
        _load("howl", ["howl.ogg"])
        _load("stinger", ["stinger1.ogg", "stinger2.ogg"])
        _load("thud", ["thud1.ogg", "thud2.ogg"])
        _load("tinnitus", ["tinnitus.ogg"])
        _load("saw_start", ["chainsaw_start.ogg"])
        _load("saw_idle", ["chainsaw_idle.ogg"])
        _load("saw_rev", ["chainsaw_rev.ogg"])
        _ok = bool(_sounds)
    except Exception as ex:
        print("[sound] звук отключён:", ex)
        _ok = False


def set_listener(x, y):
    _listener[0], _listener[1] = x, y


def play(name, volume=1.0, pan=0.0):
    """pan: -1 слева … +1 справа."""
    if not _ok:
        return None
    bank = _sounds.get(name)
    if not bank:
        return None
    try:
        ch = random.choice(bank).play()
        if ch is not None:
            v = max(0.0, min(1.0, volume))
            ch.set_volume(v * (1.0 - max(0.0, pan)), v * (1.0 + min(0.0, pan)))
        return ch
    except Exception:
        return None


def play_at(name, x, y, volume=1.0, max_dist=1400.0):
    """Позиционный звук: затухает с расстоянием, смещается по панораме."""
    if not _ok:
        return None
    dx, dy = x - _listener[0], y - _listener[1]
    d = math.hypot(dx, dy)
    if d >= max_dist:
        return None
    fall = (1.0 - d / max_dist) ** 1.6
    pan = max(-0.9, min(0.9, dx / 500.0))
    return play(name, volume * fall, pan)


def loop(slot, name, volume=0.0):
    """Запустить бесконечную петлю в зарезервированном канале."""
    if not _ok or slot in _loops:
        return
    bank = _sounds.get(name)
    if not bank:
        return
    try:
        ch = pygame.mixer.Channel(slot)
        ch.play(bank[0], loops=-1)
        ch.set_volume(volume)
        _loops[slot] = ch
    except Exception:
        pass


def set_loop(slot, volume):
    ch = _loops.get(slot)
    if ch is not None:
        try:
            v = max(0.0, min(1.0, volume))
            ch.set_volume(v)
        except Exception:
            pass


def has(name):
    return _ok and name in _sounds
