"""Иконки оружия из assets/icons (game-icons.net, CC BY 3.0)."""
import pygame
from pathlib import Path

ICON_DIR = Path(__file__).resolve().parent.parent / "assets" / "icons"
_cache = {}


def get(key, size=40, color=(255, 228, 164)):
    """Возвращает загруженную, отмасштабированную и тонированную иконку."""
    cache_key = (key, size, color)
    if cache_key in _cache:
        return _cache[cache_key]

    path = ICON_DIR / f"{key}.png"
    if not path.exists():
        _cache[cache_key] = None
        return None

    img = pygame.image.load(str(path)).convert_alpha()
    img = pygame.transform.smoothscale(img, (size, size))
    tinted = img.copy()
    tinted.fill((*color, 255), special_flags=pygame.BLEND_RGBA_MULT)
    _cache[cache_key] = tinted
    return tinted
