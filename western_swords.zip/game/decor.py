import copy
import math, random, pygame
from .config import WORLD_W, WORLD_H, SAND_D, WOOD, WOOD_L, CACT

# Небольшой городок к северу от точки появления игрока
TOWN = [
    {"t": "saloon", "x": 1890, "y": 1560, "w": 260, "h": 160, "sign": "САЛУН",
     "solid": True, "roof": (116, 60, 42)},
    {"t": "shop", "x": 2180, "y": 1580, "w": 230, "h": 150, "sign": "МАГАЗИН",
     "solid": True, "roof": (104, 82, 50)},
    {"t": "sheriff", "x": 1600, "y": 1600, "w": 200, "h": 140, "sign": "ШЕРИФ",
     "solid": True, "roof": (88, 70, 50)},
    {"t": "barn", "x": 2460, "y": 1610, "w": 230, "h": 155, "sign": "КОНЮШНЯ",
     "solid": True, "roof": (94, 64, 42)},
    {"t": "barrel", "x": 1740, "y": 1500, "s": 1.0},
    {"t": "barrel", "x": 2035, "y": 1485, "s": 0.9},
    {"t": "barrel", "x": 2305, "y": 1560, "s": 1.1},
    {"t": "hitch", "x": 1960, "y": 1680, "s": 1.0},
    {"t": "hitch", "x": 2110, "y": 1690, "s": 1.0},
    {"t": "trough", "x": 2040, "y": 1715, "s": 1.0},
]

GRASS_ZONE = (2600, 2350, 380)


def _avoid_zones():
    zones = []
    for b in TOWN:
        if b.get("solid"):
            zones.append((b["x"] - b["w"] / 2 - 45, b["y"] - b["h"] / 2 - 45,
                          b["w"] + 90, b["h"] + 90))
    return zones


def _is_free(x, y, zones):
    for zx, zy, zw, zh in zones:
        if zx < x < zx + zw and zy < y < zy + zh:
            return False
    return True


def make_decor():
    items = []
    zones = _avoid_zones()

    # Кактусы и камни не должны спавниться внутри зданий
    for _ in range(70):
        while True:
            x = random.randint(40, WORLD_W - 40)
            y = random.randint(50, WORLD_H - 40)
            if _is_free(x, y, zones):
                break
        items.append({"t": "cactus", "x": x, "y": y,
                      "s": random.uniform(0.8, 1.35), "hp": 30, "max_hp": 30, "broken": False})
    for _ in range(90):
        while True:
            x = random.randint(20, WORLD_W - 20)
            y = random.randint(30, WORLD_H - 20)
            if _is_free(x, y, zones):
                break
        items.append({"t": "rock", "x": x, "y": y, "s": random.uniform(0.6, 1.4)})

    # Сухая трава по всей карте и отдельное поле
    for _ in range(150):
        items.append({"t": "grass", "x": random.randint(30, WORLD_W - 30),
                      "y": random.randint(30, WORLD_H - 30), "s": random.uniform(0.7, 1.3)})
    gx, gy, gr = GRASS_ZONE
    for _ in range(170):
        a = random.uniform(0, math.tau)
        d = random.uniform(0, gr)
        items.append({"t": "grass", "x": gx + math.cos(a) * d,
                      "y": gy + math.sin(a) * d, "s": random.uniform(0.9, 1.6)})

    town = copy.deepcopy(TOWN)
    for b in town:
        if b.get("solid"):
            ensure_openings(b)
    items.extend(town)
    items.sort(key=lambda i: i["y"])
    return items


def circle_rect_hit(cx, cy, r, item):
    hw, hh = item["w"] / 2, item["h"] / 2
    nx = max(item["x"] - hw, min(cx, item["x"] + hw))
    ny = max(item["y"] - hh, min(cy, item["y"] + hh))
    return (cx - nx) ** 2 + (cy - ny) ** 2 < r * r


def circle_rect_hit_rect(cx, cy, r, rect):
    nx = max(rect.left, min(cx, rect.right))
    ny = max(rect.top, min(cy, rect.bottom))
    return (cx - nx) ** 2 + (cy - ny) ** 2 < r * r


def ensure_openings(it):
    if "openings" in it:
        return
    w, h = it["w"], it["h"]
    x, y = it["x"], it["y"]
    t = 9
    door = 84
    bottom = y + h / 2 - t - 2
    it["openings"] = [
        {"kind": "door", "x": x - door / 2, "y": bottom, "w": door, "h": t + 10, "broken": False,
         "open": False, "swing": 0.0, "hp": 5, "marks": []},
        {"kind": "window", "x": x - w * 0.30 - 18, "y": bottom, "w": 36, "h": t + 7, "broken": False,
         "hp": 2, "cracks": []},
        {"kind": "window", "x": x + w * 0.30 - 18, "y": bottom, "w": 36, "h": t + 7, "broken": False,
         "hp": 2, "cracks": []},
    ]


def building_parts(it):
    w, h = it["w"], it["h"]
    x, y = it["x"], it["y"]
    t = 9
    left, top = x - w / 2, y - h / 2
    door = 84
    seg = (w - door) / 2
    walls = [
        pygame.Rect(left, top, w, t),
        pygame.Rect(left, top, t, h),
        pygame.Rect(left + w - t, top, t, h),
        pygame.Rect(left, top + h - t, seg, t),
        pygame.Rect(left + w - seg, top + h - t, seg, t),
    ]
    inner = pygame.Rect(left + t, top + t, w - 2 * t, h - 2 * t)
    return walls, inner


def building_hit(cx, cy, r, it):
    walls, _ = building_parts(it)
    return any(circle_rect_hit_rect(cx, cy, r, wr) for wr in walls)


def inside_building(cx, cy, it):
    _, inner = building_parts(it)
    if inner.collidepoint(cx, cy):
        return True
    # игрок в дверном проёме — крышу тоже убираем
    return (abs(cx - it["x"]) < 42 and
            it["y"] + it["h"] / 2 - 40 < cy < it["y"] + it["h"] / 2 + 28)


def ray_wall_dist(x, y, angle, max_len, items):
    """Расстояние от (x, y) до ближайшей стены вдоль луча (или max_len).
    Выбитые окна не мешают — через них оружие можно просунуть."""
    ex, ey = x + math.cos(angle) * max_len, y + math.sin(angle) * max_len
    line = ((x, y), (ex, ey))
    best = max_len
    for it in items:
        if abs(it["x"] - x) > it["w"] / 2 + max_len + 20 or abs(it["y"] - y) > it["h"] / 2 + max_len + 20:
            continue
        walls, _ = building_parts(it)
        for wr in walls:
            hit = wr.clipline(line)
            if not hit:
                continue
            pt = hit[0]
            if any(op.get("broken") and op["kind"] == "window" and
                   pygame.Rect(op["x"], op["y"], op["w"], op["h"]).collidepoint(pt)
                   for op in it.get("openings", ())):
                continue
            d = math.hypot(pt[0] - x, pt[1] - y)
            if d < best:
                best = d
    return best


def damage_opening(op, hits=1, px=None, py=None):
    """Урон окну/двери. Возвращает: 'broken' | 'cracked' | 'hit'."""
    if op.get("broken"):
        return "hit"
    op["hp"] = op.get("hp", 1) - hits
    lx = (px - op["x"]) if px is not None else op["w"] / 2
    ly = (py - op["y"]) if py is not None else op["h"] / 2
    lx = max(2, min(op["w"] - 2, lx))
    ly = max(1, min(op["h"] - 1, ly))
    if op["hp"] <= 0:
        break_opening(op)
        return "broken"
    if op["kind"] == "window":
        # трещины-лучи от точки попадания
        for _ in range(random.randint(5, 7)):
            a = random.uniform(0, math.tau)
            ln = random.uniform(6, 20)
            op.setdefault("cracks", []).append((lx, ly, lx + math.cos(a) * ln, ly + math.sin(a) * ln * 0.6))
        return "cracked"
    op.setdefault("marks", []).append((lx, ly, random.uniform(0, math.tau)))
    if len(op["marks"]) > 12:
        op["marks"].pop(0)
    op["shake"] = 0.18
    return "hit"


def update_openings(items, dt, px, py):
    """Плавное открывание дверей (скрип) и затухание тряски."""
    events = []
    for b in items:
        for op in b.get("openings", ()):
            if op["kind"] != "door":
                continue
            if op.get("shake", 0) > 0:
                op["shake"] = max(0.0, op["shake"] - dt)
            if op.get("broken"):
                continue
            near = math.hypot(px - (op["x"] + op["w"] / 2), py - (op["y"] + op["h"] / 2)) < 75
            if near != op.get("open"):
                op["open"] = near
                events.append((op, near))
            tgt = 1.0 if near else 0.0
            sw = op.get("swing", 0.0)
            op["swing"] = min(tgt, sw + dt * 4.0) if tgt > sw else max(tgt, sw - dt * 3.0)
    return events


def line_blocked(x1, y1, x2, y2):
    """Пересекает ли отрезок стену дома."""
    line = ((x1, y1), (x2, y2))
    for it in TOWN:
        if not it.get("solid"):
            continue
        walls, _ = building_parts(it)
        for wr in walls:
            if wr.clipline(line):
                return True
    return False


def draw_floors(surf, items, cam_x, cam_y, px=None, py=None):
    if px is None:
        return
    for it in items:
        if not it.get("solid"):
            continue
        if not inside_building(px, py, it):
            continue
        x, y = it["x"] - cam_x, it["y"] - cam_y
        if -300 < x < surf.get_width() + 300 and -300 < y < surf.get_height() + 300:
            _draw_floor(surf, it, x, y)


def draw_all(surf, items, cam_x, cam_y, px=None, py=None):
    for it in items:
        x, y = it["x"] - cam_x, it["y"] - cam_y
        if not (-160 < x < surf.get_width() + 160 and -160 < y < surf.get_height() + 160):
            continue
        if it.get("solid"):
            if px is not None and inside_building(px, py, it):
                _draw_interior(surf, it, x, y)
            else:
                _draw_porch(surf, it, x, y)
            continue
        _draw_one(surf, it, x, y)


def draw_roofs(surf, items, cam_x, cam_y, px=None, py=None):
    for it in items:
        if not it.get("solid"):
            continue
        if px is not None and inside_building(px, py, it):
            continue
        x, y = it["x"] - cam_x, it["y"] - cam_y
        if -300 < x < surf.get_width() + 300 and -300 < y < surf.get_height() + 300:
            _draw_roof(surf, it, x, y)


def _draw_roof(surf, it, x, y):
    w, h = it["w"], it["h"]
    roof = it.get("roof", (100, 76, 48))
    pygame.draw.rect(surf, (122, 96, 60), (x - w / 2 + 9, y - h / 2 + 11, w, h), border_radius=6)
    pygame.draw.rect(surf, roof, (x - w / 2, y - h / 2, w, h), border_radius=6)
    for i in range(1, 7):
        yy = y - h / 2 + i * h / 7
        pygame.draw.line(surf, tuple(max(0, c - 24) for c in roof),
                         (x - w / 2 + 4, yy), (x + w / 2 - 4, yy), 2)
    pygame.draw.line(surf, tuple(max(0, c - 42) for c in roof),
                     (x - w / 2 + 5, y), (x + w / 2 - 5, y), 4)
    pygame.draw.rect(surf, tuple(min(255, c + 26) for c in roof),
                     (x - w / 2 + 6, y - h / 2 + 6, w - 12, h * 0.2), border_radius=4)
    # труба
    pygame.draw.rect(surf, (78, 54, 34), (x - w / 2 + 18, y - h / 2 - 14, 16, 22), border_radius=2)
    _draw_openings(surf, it, x, y)


def _draw_porch(surf, it, x, y):
    w, h = it["w"], it["h"]
    pygame.draw.rect(surf, (128, 86, 50), (x - w / 2 - 9, y + h / 2 - 18, w + 18, 23), border_radius=3)
    pygame.draw.rect(surf, (72, 46, 26), (x - w / 2 - 9, y + h / 2 - 18, w + 18, 23), 1, border_radius=3)
    for px in (x - w / 2 - 2, x - w / 6, x + w / 6, x + w / 2 + 2):
        pygame.draw.circle(surf, (64, 42, 26), (int(px), int(y + h / 2 - 4)), 3)


def break_opening(op):
    if op.get("broken") and (op.get("shards") or op.get("splinters") or op.get("plank")):
        return
    op["broken"] = True
    w, h = op["w"], op["h"]
    op["cracks"] = []
    if op["kind"] == "window":
        shapes = []
        for _ in range(16):
            side = random.choice(("t", "b", "l", "r"))
            if side == "t":
                x = random.uniform(2, max(3, w - 2))
                base = (x, 0)
                a = (x + random.uniform(-6, 7), 0)
                b = (x + random.uniform(-5, 9), random.uniform(5, 12))
            elif side == "b":
                x = random.uniform(2, max(3, w - 2))
                base = (x, h)
                a = (x + random.uniform(-6, 7), h)
                b = (x + random.uniform(-5, 9), h - random.uniform(5, 12))
            elif side == "l":
                y = random.uniform(2, max(3, h - 2))
                base = (0, y)
                a = (0, y + random.uniform(-4, 5))
                b = (random.uniform(5, 12), y + random.uniform(-4, 6))
            else:
                y = random.uniform(2, max(3, h - 2))
                base = (w, y)
                a = (w, y + random.uniform(-4, 5))
                b = (w - random.uniform(5, 12), y + random.uniform(-4, 6))
            shapes.append((base, a, b))
        op["shards"] = shapes
    else:
        splinters = []
        for _ in range(7):
            x = random.uniform(1, max(2, w - 1))
            y = random.uniform(1, max(2, h - 1))
            splinters.append(((x, y),
                              (x + random.uniform(4, 13), y + random.uniform(-3, 3)),
                              (x + random.uniform(0, 7), y + random.uniform(5, 12))))
        op["splinters"] = splinters
        op["plank"] = (random.uniform(2, max(3, w * 0.45)),
                       random.uniform(0, h * 0.25),
                       random.uniform(10, 22),
                       random.uniform(-0.45, 0.45))


def _draw_openings(surf, it, x, y):
    for hx, hy in it.get("holes", ()):
        sx = int(x + (hx - it["x"]))
        sy = int(y + (hy - it["y"]))
        pygame.draw.circle(surf, (24, 15, 8), (sx, sy), 2)
        pygame.draw.line(surf, (38, 24, 12), (sx - 3, sy), (sx + 3, sy + 1), 1)
        pygame.draw.line(surf, (38, 24, 12), (sx, sy - 2), (sx + 1, sy + 3), 1)

    for op in it.get("openings", ()):
        ox = x + (op["x"] - it["x"])
        oy = y + (op["y"] - it["y"])
        w, h = op["w"], op["h"]
        if op.get("broken") and not (op.get("shards") or op.get("splinters") or op.get("plank")):
            break_opening(op)

        if op["kind"] == "door":
            if op.get("broken"):
                pygame.draw.rect(surf, (15, 9, 5), (ox, oy, w, h), border_radius=2)
                pygame.draw.rect(surf, (104, 64, 34), (ox - 2, oy - 2, w + 4, h + 4), 3, border_radius=2)
                # рваные доски по краям
                for tri in op.get("splinters", ()):
                    pts = [(ox + px, oy + py) for px, py in tri]
                    pygame.draw.polygon(surf, (86, 52, 28), pts)
                    pygame.draw.polygon(surf, (42, 24, 12), pts, 1)
                # висящая доска
                plx, ply, plen, pang = op.get("plank", (w * 0.2, 0, 14, 0.2))
                ca, sa = math.cos(pang), math.sin(pang)
                pts = [(ox + plx, oy + ply),
                       (ox + plx + ca * plen, oy + ply + sa * plen),
                       (ox + plx + ca * plen - sa * 4, oy + ply + sa * plen + ca * 4),
                       (ox + plx - sa * 4, oy + ply + ca * 4)]
                pygame.draw.polygon(surf, (96, 58, 30), pts)
                pygame.draw.polygon(surf, (40, 22, 11), pts, 1)
            else:
                sw = op.get("swing", 1.0 if op.get("open") else 0.0)
                sh = op.get("shake", 0.0)
                jx = math.sin(sh * 90) * 2.0 * (sh / 0.18) if sh > 0 else 0.0
                pygame.draw.rect(surf, (20, 12, 7), (ox, oy, w, h), border_radius=2)
                if sw < 0.03:
                    r = pygame.Rect(ox + jx, oy, w, h)
                    pygame.draw.rect(surf, (76, 46, 24), r, border_radius=2)
                    pygame.draw.rect(surf, (34, 19, 9), r, 3, border_radius=2)
                    for i in range(1, 4):
                        xx = ox + jx + i * w / 4
                        pygame.draw.line(surf, (56, 32, 16), (xx, oy + 3), (xx, oy + h - 3), 1)
                    pygame.draw.line(surf, (130, 86, 46), (ox + jx + 4, oy + 2), (ox + jx + w - 4, oy + h - 2), 1)
                    pygame.draw.circle(surf, (206, 168, 82), (int(ox + jx + w - 13), int(oy + h / 2)), 2)
                else:
                    # створка вращается вокруг петли слева, наружу
                    ang = sw * 1.35
                    hx, hy = ox, oy + h - 2
                    ex, ey = hx + math.cos(ang) * w, hy + math.sin(ang) * w * 0.9
                    ca, sa = -math.sin(ang), math.cos(ang)
                    pts = [(hx, hy), (ex, ey), (ex + ca * 5, ey + sa * 5), (hx + ca * 5, hy + sa * 5)]
                    pygame.draw.polygon(surf, (78, 46, 24), pts)
                    pygame.draw.polygon(surf, (34, 19, 9), pts, 2)
                    pygame.draw.line(surf, (130, 86, 46), pts[0], pts[1], 1)
                for mx_, my_, _a in op.get("marks", ()):
                    pygame.draw.circle(surf, (18, 10, 5), (int(ox + mx_), int(oy + my_)), 2)
                    pygame.draw.line(surf, (150, 104, 60), (ox + mx_ - 3, oy + my_ - 1), (ox + mx_ + 3, oy + my_ + 2), 1)
        else:
            if op.get("broken"):
                pygame.draw.rect(surf, (16, 22, 24), (ox, oy, w, h), border_radius=2)
                pygame.draw.rect(surf, (54, 38, 24), (ox - 2, oy - 2, w + 4, h + 4), 3, border_radius=2)
                rim = [(ox + 3, oy + 2), (ox + w * 0.22, oy + 5), (ox + w * 0.45, oy + 2),
                       (ox + w * 0.7, oy + 6), (ox + w - 4, oy + 2), (ox + w - 3, oy + h * 0.5),
                       (ox + w - 6, oy + h - 3), (ox + w * 0.55, oy + h - 6), (ox + w * 0.3, oy + h - 3),
                       (ox + 5, oy + h - 5), (ox + 3, oy + h * 0.45)]
                pygame.draw.lines(surf, (150, 212, 232), False, rim, 2)
                for tri in op.get("shards", ()):
                    pts = [(ox + px, oy + py) for px, py in tri]
                    pygame.draw.polygon(surf, (206, 242, 252), pts)
                    pygame.draw.polygon(surf, (112, 178, 204), pts, 1)
                for i in range(4):
                    sx = ox + 4 + i * (w - 8) / 3
                    pygame.draw.line(surf, (228, 248, 255), (sx, oy + 2), (sx + 6, oy + h - 2), 1)
                for bx in (ox + 5, ox + w * 0.45, ox + w - 7):
                    pygame.draw.polygon(surf, (190, 232, 246),
                                        [(bx, oy + h - 1), (bx + 4, oy + h - 6), (bx + 7, oy + h - 1)])
            else:
                pygame.draw.rect(surf, (112, 176, 198), (ox, oy, w, h), border_radius=2)
                pygame.draw.rect(surf, (44, 28, 16), (ox, oy, w, h), 3, border_radius=2)
                pygame.draw.line(surf, (198, 232, 244), (ox + 3, oy + 2), (ox + w - 3, oy + h - 2), 1)
                pygame.draw.line(surf, (70, 118, 138), (ox + w / 2, oy + 1), (ox + w / 2, oy + h - 1), 1)
                pygame.draw.line(surf, (70, 118, 138), (ox + 1, oy + h / 2), (ox + w - 1, oy + h / 2), 1)
                for x1, y1, x2, y2 in op.get("cracks", ()):
                    pygame.draw.line(surf, (236, 250, 255), (ox + x1, oy + y1), (ox + x2, oy + y2), 1)
                    pygame.draw.line(surf, (60, 100, 120), (ox + x1 + 1, oy + y1), (ox + x2 + 1, oy + y2), 1)
                if op.get("cracks"):
                    x1, y1 = op["cracks"][0][:2]
                    pygame.draw.circle(surf, (24, 36, 44), (int(ox + x1), int(oy + y1)), 2)


def _draw_floor(surf, it, x, y):
    w, h = it["w"], it["h"]
    iw, ih = w - 18, h - 18
    left, top = x - iw / 2, y - ih / 2
    pygame.draw.rect(surf, (82, 56, 34), (left, top, iw, ih))
    for i in range(1, int(ih // 16) + 1):
        yy = top + i * 16
        pygame.draw.line(surf, (66, 44, 27), (left + 2, yy), (left + iw - 2, yy), 1)
    for i in range(1, int(iw // 36) + 1):
        xx = left + i * 36
        pygame.draw.line(surf, (70, 48, 28), (xx, top + 2), (xx, top + ih - 2), 1)
    pygame.draw.rect(surf, (48, 30, 18), (left, top, iw, ih), 2)


def _draw_interior(surf, it, x, y):
    walls, _ = building_parts(it)
    for wr in walls:
        sx = x + (wr.x - it["x"])
        sy = y + (wr.y - it["y"])
        pygame.draw.rect(surf, (92, 62, 36), (sx, sy, wr.w, wr.h))
        pygame.draw.rect(surf, (46, 30, 18), (sx, sy, wr.w, wr.h), 1)
    _draw_openings(surf, it, x, y)
    kind = it["t"]
    iw, ih = it["w"] - 26, it["h"] - 26
    ix, iy = x - iw / 2, y - ih / 2

    if kind == "saloon":
        pygame.draw.rect(surf, (108, 68, 36), (ix + 4, iy + 6, iw - 8, 16), border_radius=3)
        pygame.draw.rect(surf, (64, 40, 22), (ix + 4, iy + 6, iw - 8, 16), 2, border_radius=3)
        for i in range(5):
            pygame.draw.circle(surf, (160, 120, 50), (int(ix + 16 + i * 20), int(iy + 13)), 3)
        for cx, cy in ((ix + 22, iy + ih * 0.55), (ix + iw - 24, iy + ih * 0.65)):
            pygame.draw.circle(surf, (96, 62, 34), (int(cx), int(cy)), 12)
            pygame.draw.circle(surf, (130, 88, 44), (int(cx), int(cy)), 12, 2)
    elif kind == "shop":
        pygame.draw.rect(surf, (94, 66, 40), (ix + 4, iy + 6, 18, ih - 12), border_radius=2)
        for i in range(3):
            yy = iy + 16 + i * 26
            pygame.draw.line(surf, (60, 40, 24), (ix + 6, yy), (ix + 20, yy), 2)
            pygame.draw.rect(surf, (150, 116, 60), (ix + 8, yy - 7, 5, 5))
            pygame.draw.rect(surf, (110, 80, 50), (ix + 15, yy - 5, 4, 4))
        pygame.draw.rect(surf, (106, 72, 40), (ix + iw - 30, iy + ih * 0.45, 26, 14), border_radius=2)
    elif kind == "sheriff":
        pygame.draw.rect(surf, (98, 66, 38), (ix + iw * 0.3, iy + ih * 0.45, iw * 0.38, 18), border_radius=2)
        pygame.draw.rect(surf, (58, 38, 22), (ix + iw * 0.3, iy + ih * 0.45, iw * 0.38, 18), 1, border_radius=2)
        for i in range(4):
            xx = ix + iw - 20
            pygame.draw.line(surf, (70, 76, 84), (xx, iy + 12 + i * 12), (xx, iy + 20 + i * 12), 2)
    else:  # barn
        for cx, cy in ((ix + 22, iy + ih * 0.4), (ix + iw - 24, iy + ih * 0.6)):
            pygame.draw.ellipse(surf, (170, 142, 66), (cx - 13, cy - 8, 26, 16))
            pygame.draw.ellipse(surf, (120, 96, 44), (cx - 13, cy - 8, 26, 16), 1)
        pygame.draw.rect(surf, (80, 54, 30), (ix + 4, iy + ih - 20, 20, 14))


def _draw_one(surf, it, x, y):
    t = it["t"]
    s = it.get("s", 1.0)

    if t in ("saloon", "shop", "sheriff", "barn"):
        _draw_building(surf, it, x, y)
        return

    if t == "barrel":
        pygame.draw.ellipse(surf, (54, 36, 20), (x - 9 * s, y + 5 * s, 18 * s, 6 * s))
        pygame.draw.circle(surf, (112, 74, 42), (int(x), int(y)), int(7 * s))
        pygame.draw.circle(surf, (66, 42, 24), (int(x), int(y)), int(7 * s), 1)
        pygame.draw.line(surf, (60, 40, 22), (x - 6 * s, y - 3 * s), (x + 6 * s, y - 3 * s), 1)
        pygame.draw.line(surf, (60, 40, 22), (x - 6 * s, y + 3 * s), (x + 6 * s, y + 3 * s), 1)
        return

    if t == "hitch":
        pygame.draw.line(surf, (72, 46, 24), (x - 22 * s, y - 6), (x + 22 * s, y - 6), 4)
        pygame.draw.line(surf, (130, 88, 48), (x - 22 * s, y - 7), (x + 22 * s, y - 7), 1)
        for px in (x - 17 * s, x + 17 * s):
            pygame.draw.line(surf, (72, 46, 24), (px, y - 11), (px, y + 8), 4)
        return

    if t == "trough":
        pygame.draw.rect(surf, (92, 60, 34), (x - 24 * s, y - 8, 48 * s, 16), border_radius=3)
        pygame.draw.rect(surf, (60, 38, 20), (x - 24 * s, y - 8, 48 * s, 16), 1, border_radius=3)
        pygame.draw.rect(surf, (82, 122, 146), (x - 20 * s, y - 5, 40 * s, 10), border_radius=2)
        return

    if t == "grass":
        for k in range(4):
            dx = (-1.5 + k) * 3 * s
            hh = (8 + (k % 2) * 4) * s
            pygame.draw.line(surf, (164, 144, 84), (x + dx, y + 2), (x + dx - 2 * s, y - hh), 1)
        return

    if t == "cactus":
        if it.get("broken"):
            # лужа сока и рваный пенёк вместо целого кактуса
            pygame.draw.ellipse(surf, (70, 110, 50), (x - 14 * s, y + 8 * s, 28 * s, 6 * s))
            stump = [(x - 8 * s, y + 10 * s), (x - 7 * s, y - 4 * s), (x - 4 * s, y - 13 * s),
                     (x - 1 * s, y - 7 * s), (x + 2 * s, y - 14 * s), (x + 5 * s, y - 4 * s),
                     (x + 8 * s, y + 10 * s)]
            pygame.draw.polygon(surf, (56, 96, 42), stump)
            pygame.draw.polygon(surf, (38, 70, 30), stump, 2)
            pygame.draw.ellipse(surf, (150, 190, 100), (x - 6 * s, y - 15 * s, 12 * s, 5 * s))
            pygame.draw.ellipse(surf, (96, 140, 70), (x - 6 * s, y - 15 * s, 12 * s, 5 * s), 1)
            pygame.draw.line(surf, (90, 130, 60), (x - 3 * s, y - 10 * s), (x - 1 * s, y + 4 * s), 1)
            pygame.draw.line(surf, (90, 130, 60), (x + 2 * s, y - 8 * s), (x + 3 * s, y + 3 * s), 1)
            for dx, dy, rr in ((-14, -2, 3), (11, 4, 2), (6, -16, 2), (-10, 7, 2)):
                pygame.draw.circle(surf, (60, 100, 40), (int(x + dx * s), int(y + dy * s)), max(1, int(rr * s)))
            return

        pygame.draw.ellipse(surf, SAND_D, (x - 20 * s, y + 10 * s, 40 * s, 12 * s))
        dark_cact = (40, 70, 30)
        light_cact = (90, 150, 70)

        pygame.draw.rect(surf, dark_cact, (x - 6 * s, y - 32 * s, 12 * s, 44 * s), border_radius=int(6 * s))
        pygame.draw.rect(surf, light_cact, (x - 6 * s, y - 32 * s, 5 * s, 44 * s), border_radius=int(3 * s))

        pygame.draw.rect(surf, dark_cact, (x - 21 * s, y - 16 * s, 15 * s, 7 * s), border_radius=int(4 * s))
        pygame.draw.rect(surf, light_cact, (x - 21 * s, y - 16 * s, 15 * s, 3 * s), border_radius=int(2 * s))
        pygame.draw.rect(surf, dark_cact, (x - 21 * s, y - 28 * s, 7 * s, 18 * s), border_radius=int(4 * s))
        pygame.draw.rect(surf, light_cact, (x - 21 * s, y - 28 * s, 3 * s, 18 * s), border_radius=int(2 * s))

        pygame.draw.rect(surf, dark_cact, (x + 8 * s, y - 24 * s, 15 * s, 7 * s), border_radius=int(4 * s))
        pygame.draw.rect(surf, light_cact, (x + 8 * s, y - 24 * s, 15 * s, 3 * s), border_radius=int(2 * s))
        pygame.draw.rect(surf, dark_cact, (x + 16 * s, y - 34 * s, 7 * s, 17 * s), border_radius=int(4 * s))
        pygame.draw.rect(surf, light_cact, (x + 16 * s, y - 34 * s, 3 * s, 17 * s), border_radius=int(2 * s))

    elif t == "rock":
        pygame.draw.ellipse(surf, (148, 138, 128), (x - 15 * s, y - 8 * s, 30 * s, 16 * s))
        pygame.draw.ellipse(surf, (176, 166, 156), (x - 10 * s, y - 8 * s, 18 * s, 9 * s))


def make_tumbleweed_frames(r):
    """Заранее рисуем клубок сухих веток и его повороты."""
    size = int(r * 2) + 12
    base = pygame.Surface((size, size), pygame.SRCALPHA)
    c = size / 2
    palette = ((128, 92, 50), (158, 118, 68), (108, 76, 40), (176, 132, 78))

    for _ in range(20):
        a = random.uniform(0, math.tau)
        b = a + random.uniform(0.7, 2.5)
        p1 = (c + math.cos(a) * r * random.uniform(0.45, 0.95),
              c + math.sin(a) * r * random.uniform(0.45, 0.95))
        p2 = (c + math.cos(b) * r * random.uniform(0.45, 0.95),
              c + math.sin(b) * r * random.uniform(0.45, 0.95))
        mid = (c + math.cos((a + b) / 2) * r * random.uniform(-0.25, 0.55),
               c + math.sin((a + b) / 2) * r * random.uniform(-0.25, 0.55))
        pygame.draw.lines(base, (44, 30, 16), False, [p1, mid, p2], 3)
        pygame.draw.lines(base, random.choice(palette), False, [p1, mid, p2], 1)

    for _ in range(14):
        a = random.uniform(0, math.tau)
        rr = r * random.uniform(0.15, 0.8)
        x1, y1 = c + math.cos(a) * rr, c + math.sin(a) * rr
        x2 = x1 + math.cos(a + 1.2) * r * 0.35
        y2 = y1 + math.sin(a + 1.2) * r * 0.35
        pygame.draw.line(base, (58, 40, 22), (x1, y1), (x2, y2), 2)
        pygame.draw.line(base, (150, 110, 60), (x1, y1), (x2, y2), 1)

    for _ in range(10):
        a = random.uniform(0, math.tau)
        rr = r * random.uniform(0.3, 0.9)
        pygame.draw.circle(base, (120, 88, 46),
                           (int(c + math.cos(a) * rr), int(c + math.sin(a) * rr)), 1)

    return [pygame.transform.rotate(base, -deg) for deg in range(0, 360, 10)]


def draw_tumbleweed(surf, tw, cam_x, cam_y):
    x, y = tw["x"] - cam_x, tw["y"] - cam_y
    z = tw.get("z", 0.0)
    r = tw["r"]
    if not (-80 < x < surf.get_width() + 80 and -80 < y < surf.get_height() + 80):
        return

    # тень на земле
    pygame.draw.ellipse(surf, (116, 88, 54),
                        (x - r * 0.8, y - r * 0.22 + 2, r * 1.6, r * 0.45))
    sy = y - z
    frames = tw.get("frames")
    if frames:
        idx = int(math.degrees(tw.get("rot", 0.0)) / 10) % len(frames)
        img = frames[idx]
        surf.blit(img, img.get_rect(center=(int(x), int(sy))))
    else:
        pygame.draw.circle(surf, (124, 88, 50), (int(x), int(sy)), int(r), 2)
        pygame.draw.circle(surf, (92, 64, 34), (int(x), int(sy)), int(r), 1)
