import math, random, pygame
from .config import WEAPONS, WORLD_W, WORLD_H
from .bullet import Bullet
from .corpse import render_body, _new_shape

class Raider:
    def __init__(self, x, y, hp, speed, r, weapon_key):
        self.x, self.y = x, y
        self.hp, self.max_hp = hp, hp
        self.speed, self.r = speed, r
        self.weapon_key = weapon_key
        self.weapon = WEAPONS[weapon_key]
        self.shoot_timer = random.uniform(1.0, 2.0)
        self.hit_cd = 0.0
        self.facing = 0.0
        self.walk = 0.0
        self.attack = 0.0
        self.last_hit_angle = 0.0
        self.last_splash_angle = 0.0
        self.last_dmg = 30
        self.bleed_timer = 0.0
        self.bleed_spawn = 0.0
        self.limbs = {"head": True, "l_arm": True, "r_arm": True, "l_leg": True, "r_leg": True}
        self.shape = _new_shape(True)

    def update(self, dt, px, py, bullets, active=True):
        dx, dy = px - self.x, py - self.y
        d = math.hypot(dx, dy) or 1
        self.facing = math.atan2(dy, dx)
        if not active:
            self.attack = max(0.0, self.attack - dt * 4.0)
            self.hit_cd = max(0.0, self.hit_cd - dt)
            return d
        moving = False
        
        # Держат дистанцию
        if d > 350:
            self.x += dx / d * self.speed * dt
            self.y += dy / d * self.speed * dt
            moving = True
        elif d < 200:
            self.x -= dx / d * self.speed * dt
            self.y -= dy / d * self.speed * dt
            moving = True

        # Не даём бандитам уйти за край карты
        self.x = max(40, min(WORLD_W - 40, self.x))
        self.y = max(40, min(WORLD_H - 40, self.y))

        self.walk += dt * (self.speed * 0.09) if moving else 0.0
        self.attack = max(0.0, self.attack - dt * 4.0)
        self.hit_cd = max(0.0, self.hit_cd - dt)
        self.shoot_timer -= dt
        
        # Стреляют, если игрок в радиусе 600
        if self.shoot_timer <= 0 and d < 600:
            self.shoot_timer = 1.2
            self.attack = 1.0
            angle = self.facing + random.uniform(-0.15, 0.15) # Разброс
            b = Bullet(self.x, self.y, angle, self.weapon["speed"]*0.8, 15, 0, (255, 50, 50), is_enemy=True)
            bullets.append(b)
            
        return d

    def take_hit(self, damage, hit_angle, blood_sys, can_dismember=True, is_melee=False,
                 weapon_key="", strength=1.0):
        if is_melee and self.hit_cd > 0: return False
        if is_melee: self.hit_cd = 0.1
        self.last_hit_angle = hit_angle
        self.last_splash_angle = hit_angle
        self.last_weapon = weapon_key
        self.last_dmg = damage
        self.hp -= damage
        if self.hp > 0:
            self.bleed_timer = min(10.0, self.bleed_timer + 1.5 + damage * 0.02)
        return False

    def draw(self, surf, cam_x, cam_y):
        x, y = self.x - cam_x, self.y - cam_y
        if not (-80 < x < surf.get_width() + 80 and -80 < y < surf.get_height() + 80):
            return

        style = {"skin": (204, 156, 112), "shirt": (160, 60, 60),
                 "pants": (52, 48, 44), "raider": True}
        spr = render_body(style, self.limbs, self.shape, 0.0, self.facing,
                          self.walk, self.r / 14.0, self.attack)
        surf.blit(spr, spr.get_rect(center=(int(x), int(y))))

        if self.hp < self.max_hp:
            bw = self.r * 2
            pygame.draw.rect(surf, (50, 20, 20), (x - bw / 2, y - self.r - 15, bw, 4))
            pygame.draw.rect(surf, (205, 55, 55), (x - bw / 2, y - self.r - 15, bw * self.hp / self.max_hp, 4))
