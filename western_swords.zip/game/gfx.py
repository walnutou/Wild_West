"""Мини-«художник»: рисует фигуры в локальных координатах (персонаж смотрит вправо),
сам поворачивает их и сглаживает (рисует в 2x и уменьшает) — никакой пиксельной лесенки."""
import math
import pygame


def shade(col, f):
    """f<1 — темнее, f>1 — светлее."""
    return tuple(max(0, min(255, int(c * f))) for c in col[:3])


def mix(a, b, t):
    return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))


class Painter:
    def __init__(self, size, S=2, angle=0.0, scale=1.0):
        self.size, self.S, self.k = size, S, scale
        self.surf = pygame.Surface((size * S, size * S), pygame.SRCALPHA)
        self.c = size * S / 2
        self.ca, self.sa = math.cos(angle), math.sin(angle)
        self.xs, self.xo = 1.0, 0.0   # сжатие/сдвиг вдоль оси прицела (оружие у стены)

    def xform(self, scale=1.0, offset=0.0):
        self.xs, self.xo = scale, offset

    def pt(self, x, y):
        S = self.S * self.k
        x = x * self.xs + self.xo
        return (self.c + (x * self.ca - y * self.sa) * S,
                self.c + (x * self.sa + y * self.ca) * S)

    def poly(self, pts, col, outline=None, ow=1.0):
        P = [self.pt(*p) for p in pts]
        if len(P) < 3:
            return
        pygame.draw.polygon(self.surf, col, P)
        if outline:
            pygame.draw.polygon(self.surf, outline, P, max(1, int(ow * self.S)))

    def ellipse(self, cx, cy, rx, ry, col, outline=None, ow=1.0, rot=0.0, n=30, ring=0.0):
        cr, sr = math.cos(rot), math.sin(rot)
        pts = []
        for i in range(n):
            a = i * math.tau / n
            ex, ey = math.cos(a) * rx, math.sin(a) * ry
            pts.append((cx + ex * cr - ey * sr, cy + ex * sr + ey * cr))
        if ring:
            P = [self.pt(*p) for p in pts]
            pygame.draw.polygon(self.surf, col, P, max(1, int(ring * self.S)))
        else:
            self.poly(pts, col, outline, ow)

    def circle(self, x, y, r, col, outline=None, ow=1.0):
        c = self.pt(x, y)
        pygame.draw.circle(self.surf, col, c, r * self.S * self.k)
        if outline:
            pygame.draw.circle(self.surf, outline, c, r * self.S * self.k, max(1, int(ow * self.S)))

    def line(self, p0, p1, w, col):
        a, b = self.pt(*p0), self.pt(*p1)
        pygame.draw.line(self.surf, col, a, b, max(1, int(w * self.S * self.k)))
        r = w * self.S * self.k / 2
        pygame.draw.circle(self.surf, col, a, r)
        pygame.draw.circle(self.surf, col, b, r)

    def thick(self, p0, p1, w, col, outline=None):
        """Толстый отрезок с круглыми концами и тёмным контуром."""
        if outline:
            self.line(p0, p1, w + 1.8, outline)
        self.line(p0, p1, w, col)

    def rect(self, x, y, w, h, col, outline=None, ow=1.0):
        self.poly([(x, y), (x + w, y), (x + w, y + h), (x, y + h)], col, outline, ow)

    def result(self):
        return pygame.transform.smoothscale(self.surf, (self.size, self.size))
