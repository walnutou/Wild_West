class Camera:
    def __init__(self, width, height):
        self.x = 0
        self.y = 0
        self.w = width
        self.h = height

    def update(self, target_x, target_y, world_w, world_h):
        self.x = target_x - self.w // 2
        self.y = target_y - self.h // 2
        self.x = max(0, min(self.x, world_w - self.w))
        self.y = max(0, min(self.y, world_h - self.h))
