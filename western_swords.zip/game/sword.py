import math, pygame
from .config import SWORD_INNER
from .utils import seg_dist

def endpoints(px, py, rotation, count, length):
    out = []
    for i in range(count):
        a = rotation + i * math.tau / count
        ca, sa = math.cos(a), math.sin(a)
        out.append((px + ca * SWORD_INNER, py + sa * SWORD_INNER,
                    px + ca * (SWORD_INNER + length), py + sa * (SWORD_INNER + length)))
    return out

def hits(px, py, rotation, count, length, tx, ty, tr):
    for x1, y1, x2, y2 in endpoints(px, py, rotation, count, length):
        if seg_dist(tx, ty, x1, y1, x2, y2) < tr + 12:
            return True
    return False

_trail_cache = {}

def draw(surf, px, py, rotation, count, length, trail, cam_x, cam_y):
    w, h = surf.get_width(), surf.get_height()
    
    # Если мечей слишком много, шлейф вообще не рисуем (спасаем ФПС и глаза)
    if count <= 8 and trail:
        if 'surf' not in _trail_cache or _trail_cache['size'] != (w, h):
            _trail_cache['surf'] = pygame.Surface((w, h), pygame.SRCALPHA)
            _trail_cache['size'] = (w, h)
        ts = _trail_cache['surf']
        ts.fill((0, 0, 0, 0))
        
        # Чем больше мечей, тем короче шлейф (чтобы не сливалось в пятно)
        max_len = max(3, 12 - count)
        current_trail = trail[-max_len:]
        
        for old_rot, alpha in current_trail:
            a_val = int(max(0.0, min(1.0, alpha)) * 120)
            if a_val <= 0: continue
            
            # Толщина шлейфа тоже уменьшается
            width = max(1, a_val // 40)
            
            for i in range(count):
                ang = old_rot + i * math.tau / count
                ca, sa = math.cos(ang), math.sin(ang)
                x1 = int(px + ca * SWORD_INNER - cam_x)
                y1 = int(py + sa * SWORD_INNER - cam_y)
                x2 = int(px + ca * (SWORD_INNER + length) - cam_x)
                y2 = int(py + sa * (SWORD_INNER + length) - cam_y)
                pygame.draw.line(ts, (120, 180, 255, a_val), (x1, y1), (x2, y2), width)
        
        surf.blit(ts, (0, 0))
    
    # Рисуем сами клинки
    for i in range(count):
        a = rotation + i * math.tau / count
        ca, sa = math.cos(a), math.sin(a)
        pxv, pyv = -sa, ca
        
        x1 = px + ca * SWORD_INNER - cam_x
        y1 = py + sa * SWORD_INNER - cam_y
        x2 = px + ca * (SWORD_INNER + length) - cam_x
        y2 = py + sa * (SWORD_INNER + length) - cam_y
        
        # Рукоять
        hx, hy = x1 - ca * 14, y1 - sa * 14
        pygame.draw.line(surf, (70, 45, 25), (hx, hy), (x1, y1), 7)
        pygame.draw.line(surf, (130, 85, 45), (hx, hy), (x1, y1), 3)
        
        # Золотая гарда
        gx1, gy1 = x1 + pxv * 14, y1 + pyv * 14
        gx2, gy2 = x1 - pxv * 14, y1 - pyv * 14
        pygame.draw.line(surf, (190, 140, 50), (gx1, gy1), (gx2, gy2), 6)
        pygame.draw.line(surf, (255, 220, 110), (gx1, gy1), (gx2, gy2), 3)
        
        # Клинок
        w_blade = 8
        blade = [(x1 + pxv * w_blade, y1 + pyv * w_blade),
                 (x1 - pxv * w_blade, y1 - pyv * w_blade),
                 (x2, y2)]
        pygame.draw.polygon(surf, (150, 175, 210), blade)
        
        half = [(x1 + pxv * w_blade, y1 + pyv * w_blade),
                (x1, y1),
                (x2, y2)]
        pygame.draw.polygon(surf, (220, 235, 255), half)
        pygame.draw.polygon(surf, (70, 100, 140), blade, 2)
