import pygame
from .config import WIDTH, HEIGHT
from .utils import text
from . import icons
from .config import TOUCH

OPT_W, OPT_H, OPT_GAP = 270, 210, 28

def option_rects():
    total = 3 * OPT_W + 2 * OPT_GAP
    x0 = (WIDTH - total) // 2
    y0 = 250
    return [pygame.Rect(x0 + i * (OPT_W + OPT_GAP), y0, OPT_W, OPT_H) for i in range(3)]

def draw_hud(surf, game):
    bw = 230
    pygame.draw.rect(surf, (46, 32, 22), (20, 18, bw, 24), border_radius=7)
    hp_w = int(bw * max(0.0, game.player.hp) / game.player.max_hp)
    if hp_w > 0:
        pygame.draw.rect(surf, (196, 52, 46), (20, 18, hp_w, 24), border_radius=7)
    pygame.draw.rect(surf, (250, 226, 180), (20, 18, bw, 24), 2, border_radius=7)
    text(surf, f"HP {int(game.player.hp)}/{game.player.max_hp}", "sm", 26, 22)
    
    if game.player.armor > 0:
        pygame.draw.rect(surf, (46, 32, 22), (20, 46, bw, 14), border_radius=5)
        arm_w = int(bw * game.player.armor / game.player.max_armor)
        pygame.draw.rect(surf, (100, 180, 255), (20, 46, arm_w, 14), border_radius=5)
        pygame.draw.rect(surf, (250, 226, 180), (20, 46, bw, 14), 1, border_radius=5)
        text(surf, "БРОНЯ", "sm", 26, 46, shadow=False)

    # Шкала стамины
    st_y = 68 if game.player.armor > 0 else 50
    pygame.draw.rect(surf, (46, 32, 22), (20, st_y, bw, 10), border_radius=5)
    st_w = int(bw * game.player.stamina / game.player.max_stamina)
    if st_w > 0:
        color = (100, 255, 100) if game.player.stamina > 30 else (255, 100, 100)
        pygame.draw.rect(surf, color, (20, st_y, st_w, 10), border_radius=5)
    pygame.draw.rect(surf, (250, 226, 180), (20, st_y, bw, 10), 2, border_radius=5)

    # Шкала опыта
    xp_y = st_y + 16
    pygame.draw.rect(surf, (46, 32, 22), (20, xp_y, bw, 14), border_radius=5)
    xp_w = int(bw * game.xp / game.xp_needed)
    if xp_w > 0:
        pygame.draw.rect(surf, (232, 190, 62), (20, xp_y, xp_w, 14), border_radius=5)
    pygame.draw.rect(surf, (250, 226, 180), (20, xp_y, bw, 14), 2, border_radius=5)
    
    text(surf, f"УР. {game.level}", "md", 20, xp_y + 20, (255, 232, 160))
    
    p = game.player
    has_guns = game.cfg["guns"]
    if has_guns:
        wpn_name = game.player.weapon["name"].upper()
        icon = icons.get(game.player.active_gun, 46)
        if icon:
            panel = pygame.Rect(WIDTH - 82, 12, 62, 62)
            pygame.draw.rect(surf, (52, 36, 22), panel, border_radius=12)
            pygame.draw.rect(surf, (196, 156, 82), panel, 2, border_radius=12)
            surf.blit(icon, icon.get_rect(center=panel.center))
        text(surf, wpn_name, "lg", WIDTH - 96, 20, (255, 220, 100), right=True)
        if p.reload_t > 0:
            text(surf, "ПЕРЕЗАРЯДКА...", "md", WIDTH - 96, 56, (255, 150, 90), right=True)
        else:
            low = p.ammo <= max(1, p.weapon["mag"] // 5)
            text(surf, f"{p.ammo}/{p.weapon['mag']}" + ("" if TOUCH else "  [R]"), "md", WIDTH - 96, 56, (255, 110, 90) if low else (255, 240, 200), right=True)

    if p.melee_weapon:
        m_name = p.melee_weapon["name"].upper()
        m_icon = icons.get(p.active_melee, 28, (178, 255, 176))
        my0 = 78 if has_guns else 14
        if m_icon:
            mpanel = pygame.Rect(WIDTH - 66, my0, 40, 40)
            pygame.draw.rect(surf, (42, 52, 34), mpanel, border_radius=9)
            pygame.draw.rect(surf, (132, 190, 122), mpanel, 1, border_radius=9)
            surf.blit(m_icon, m_icon.get_rect(center=mpanel.center))
        text(surf, (m_name if TOUCH else f"[SPACE / ПКМ] {m_name}"), "md", WIDTH - 78, my0 + 10, (150, 255, 150), right=True)

    if not p.melee_weapon and has_guns:
        lbl = "ПИНОК (кнопка УДАР)" if TOUCH else "ПИНОК [ПКМ / ПРОБЕЛ]  −18 стамины"
        text(surf, lbl, "sm", WIDTH - 20, 80, (150, 255, 150) if p.stamina >= 18 else (170, 120, 110), right=True)

    ty = 120 if has_guns else 62
    text(surf, f"Время: {int(game.game_time)}с", "sm", WIDTH - 20, ty, (230, 240, 255), right=True)
    text(surf, f"Убито: {game.kills}", "sm", WIDTH - 20, ty + 20, (230, 240, 255), right=True)
    if game.cfg["flash"] and not TOUCH:
        text(surf, "[F] фонарь: " + ("вкл" if game.flash_on else "выкл"), "sm", WIDTH - 20, ty + 40,
             (255, 236, 160) if game.flash_on else (170, 170, 170), right=True)

def draw_levelup(surf, game):
    from . import upgrades
    ov = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
    ov.fill((12, 6, 0, 195))
    surf.blit(ov, (0, 0))
    text(surf, "НОВЫЙ УРОВЕНЬ!", "xl", WIDTH // 2, 110, (255, 214, 92), center=True)
    hint = "Выбери улучшение" if TOUCH else "Выбери улучшение (1, 2 или 3)"
    text(surf, hint, "md", WIDTH // 2, 175, (242, 232, 210), center=True)

    mouse = pygame.mouse.get_pos()
    for i, r in enumerate(option_rects()):
        if i >= len(game.choices):
            break
        up = game.choices[i]
        hover = r.collidepoint(mouse) and not TOUCH
        bg = (58, 40, 24) if not hover else (86, 62, 36)
        pygame.draw.rect(surf, bg, r, border_radius=14)
        pygame.draw.rect(surf, (255, 214, 92) if hover else (196, 156, 82), r, 3, border_radius=14)

        pygame.draw.circle(surf, (255, 214, 92), (r.centerx, r.y + 32), 19)
        text(surf, str(i + 1), "lg", r.centerx, r.y + 32, (40, 25, 10), center=True, shadow=False)
        text(surf, up["tag"], "sm", r.centerx, r.y + 68, upgrades.TAG_COLORS[up["tag"]], center=True)
        text(surf, up["title"], "md", r.centerx, r.y + 96, (255, 240, 200), center=True)
        text(surf, upgrades.line(up), "lg", r.centerx, r.y + 130, (255, 214, 92), center=True)
        text(surf, up["desc"], "sm", r.centerx, r.y + 175, (212, 200, 176), center=True)

def draw_pause(surf):
    ov = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
    ov.fill((0, 0, 0, 150))
    surf.blit(ov, (0, 0))
    text(surf, "ПАУЗА", "xl", WIDTH // 2, HEIGHT // 2 - 20, (255, 255, 255), center=True)
    text(surf, "Нажми ESC, чтобы продолжить", "md", WIDTH // 2, HEIGHT // 2 + 40, (200, 200, 200), center=True)

def draw_gameover(surf, game):
    ov = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
    ov.fill((40, 0, 0, 200))
    surf.blit(ov, (0, 0))
    text(surf, "ТЫ ПАЛ...", "xl", WIDTH // 2, 200, (225, 70, 60), center=True)
    text(surf, f"Уровень: {game.level}", "lg", WIDTH // 2, 290, (255, 232, 190), center=True)
    text(surf, f"Зомби убито: {game.kills}", "lg", WIDTH // 2, 335, (255, 232, 190), center=True)
    text(surf, f"Продержался: {int(game.game_time)} сек", "lg", WIDTH // 2, 380, (255, 232, 190), center=True)
    text(surf, "Нажми R или кликни мышью, чтобы начать заново", "md", WIDTH // 2, 470, (230, 220, 200), center=True)

def draw_inventory(surf, game):
    from .config import WEAPONS, MELEE_WEAPONS
    ov = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
    ov.fill((0, 0, 0, 200))
    surf.blit(ov, (0, 0))
    
    text(surf, "ИНВЕНТАРЬ (B - ЗАКРЫТЬ)", "xl", WIDTH // 2, 50, (255, 255, 255), center=True)
    
    # Огнестрел
    text(surf, "ОГНЕСТРЕЛ (1-9)", "lg", WIDTH // 4, 120, (255, 220, 100), center=True)
    for i, gun_key in enumerate(game.player.guns):
        y_pos = 180 + i * 40
        is_active = (gun_key == game.player.active_gun)
        col = (100, 255, 100) if is_active else (200, 200, 200)
        prefix = "> " if is_active else ""
        text(surf, f"{prefix}{i+1}. {WEAPONS[gun_key]['name']}", "md", WIDTH // 4, y_pos, col, center=True)

    # Ближний бой
    text(surf, "БЛИЖНИЙ БОЙ (F1-F9)", "lg", (WIDTH // 4) * 3, 120, (150, 255, 150), center=True)
    if not game.player.melee_inventory:
        text(surf, "Пусто", "md", (WIDTH // 4) * 3, 180, (150, 150, 150), center=True)
    else:
        for i, melee_key in enumerate(game.player.melee_inventory):
            y_pos = 180 + i * 40
            is_active = (melee_key == game.player.active_melee)
            col = (100, 255, 100) if is_active else (200, 200, 200)
            prefix = "> " if is_active else ""
            text(surf, f"{prefix}{i+1}. {MELEE_WEAPONS[melee_key]['name']}", "md", (WIDTH // 4) * 3, y_pos, col, center=True)

    text(surf, "Нажми на цифру, чтобы выбрать оружие", "sm", WIDTH // 2, HEIGHT - 50, (180, 180, 180), center=True)

def draw_admin_panel(surf, game):
    from .config import WEAPONS, MELEE_WEAPONS
    ov = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
    ov.fill((8, 6, 4, 238)) # Темный фон
    surf.blit(ov, (0, 0))
    
    text(surf, "АДМИН-ПАНЕЛЬ (TAB - ЗАКРЫТЬ)", "lg", WIDTH // 2, 28, (255, 50, 50), center=True)

    col1, col2, col3 = 210, 520, 830

    # 1 колонка: Огнестрел
    text(surf, "ОГНЕСТРЕЛ (1-6)", "md", col1, 100, (255, 220, 100), center=True)
    guns = list(WEAPONS.keys())
    for i, key in enumerate(guns):
        y = 148 + i * 30
        ic = icons.get(key, 24)
        if ic: surf.blit(ic, (col1 - 132, y))
        text(surf, f"{i+1}. {WEAPONS[key]['name']}", "md", col1 - 100, y - 2, (200, 200, 200))

    # 2 колонка: Ближний бой
    text(surf, "БЛИЖНИЙ БОЙ (F1-F6)", "md", col2, 100, (150, 255, 150), center=True)
    melee = list(MELEE_WEAPONS.keys())
    for i, key in enumerate(melee):
        y = 148 + i * 30
        ic = icons.get(key, 24, (178, 255, 176))
        if ic: surf.blit(ic, (col2 - 132, y))
        text(surf, f"F{i+1}. {MELEE_WEAPONS[key]['name']}", "md", col2 - 100, y - 2, (200, 200, 200))

    # 3 колонка: Читы
    text(surf, "ЧИТЫ", "md", col3, 100, (100, 200, 255), center=True)
    text(surf, "H - Восстановить HP", "md", col3 - 100, 148, (200, 200, 200))
    text(surf, "G - Броня 100%", "md", col3 - 100, 178, (200, 200, 200))
    text(surf, "K - +1000 Опыта", "md", col3 - 100, 208, (200, 200, 200))

    text(surf, "Нажми соответствующую клавишу, чтобы выдать предмет", "sm", WIDTH // 2, HEIGHT - 50, (180, 180, 180), center=True)
