import math, random, pygame
from .config import SAND_D
from .effects import Limb
from .corpse import render_body, _new_shape

_SPR_CACHE = {}


class Zombie:
    def __init__(self, x, y, hp, speed, r, ztype, dmg, xp):
        self.x, self.y = x, y
        self.hp, self.max_hp = hp, hp
        self.speed, self.r = speed, r
        self.type, self.dmg, self.xp = ztype, dmg, xp
        self.hit_cd, self.dmg_cd = 0.0, 0.0
        self.wob = random.uniform(0, 6.28)
        self.facing = 0
        self.limbs = {"head": True, "l_arm": True, "r_arm": True, "l_leg": True, "r_leg": True}
        self.last_splash_angle = 0 # Угол брызг при смерти
        self.shape = _new_shape(False)
        self.attack = 0.0       # 0..1 — бросок/укус
        self.windup = 0.0       # время до укуса
        self.bite_ready = False
        self.growl_ready = False
        self.last_hit_angle = 0.0
        self.bloody_timer = 0.0
        self.footprint_timer = 0.0
        self.bleed_timer = 0.0
        self.bleed_spawn = 0.0
        self.jaw = "normal"
        self.hit_recoil = 0.0
        self.hit_dir = 0.0
        self.wounds = []
        self.investigate = None
        self.search = 0.0
        self.state = "wander"
        self.hurry = 0.8
        self.t = random.uniform(0, 10)
        self.wander_to = None
        self.wander_wait = random.uniform(0.0, 4.0)
        self.stagger = 0.0
        self.kx = self.ky = 0.0
        self.alert_ready = False
        self.idle_snd = random.uniform(4.0, 14.0)
        self.sway_seed = random.uniform(0, 6.28)

    nav = None      # функция обхода зданий: nav(zombie, tx, ty) -> (wx, wy)
    _navc = None
    boost = 1.0     # >1, когда игрок светит фонарём: зомби быстрее и реагируют быстрее

    def _turn(self, target, dt, rate=7.0):
        rate *= self.boost
        d = (target - self.facing + math.pi) % math.tau - math.pi
        self.facing += max(-rate * dt, min(rate * dt, d))

    def _slow_factor(self):
        spd = 1.0
        if not self.limbs["l_leg"] and not self.limbs["r_leg"]: spd *= 0.2
        elif not self.limbs["l_leg"] or not self.limbs["r_leg"]: spd *= 0.6
        if self.stagger > 0:
            spd *= 0.25
        return spd * self.boost

    def update(self, dt, px, py, active=True, noises=()):
        dx, dy = px - self.x, py - self.y
        d = math.hypot(dx, dy) or 1
        self.hit_cd = max(0.0, self.hit_cd - dt)
        self.dmg_cd = max(0.0, self.dmg_cd - dt)
        self.hit_recoil = max(0.0, self.hit_recoil - dt)
        self.stagger = max(0.0, self.stagger - dt)
        self.t += dt
        self.alert_ready = False

        # откидывание от попадания — тело качнулось и отъехало
        if abs(self.kx) + abs(self.ky) > 3:
            self.x += self.kx * dt
            self.y += self.ky * dt
            fr = max(0.0, 1.0 - 7.0 * dt)
            self.kx *= fr
            self.ky *= fr

        # слух: бег слышно по всей карте, шаги — вблизи, выстрелы — очень далеко
        heard = None
        for nx, ny, nr, kind in noises:
            nd = math.hypot(nx - self.x, ny - self.y)
            if nd < nr:
                if heard is None or kind == "run":
                    heard = (nx, ny, kind)
        if heard is not None:
            if self.state == "wander" or self.state == "search":
                self.alert_ready = True
            self.state = "investigate"
            self.investigate = (heard[0], heard[1])
            self.hurry = 1.0 if heard[2] == "run" else 0.8
            self.search = 6.0

        if active:
            self.state = "chase"
            self.last_seen = (px, py)
            self.investigate = None
            self.search = 0.0
            self._turn(math.atan2(dy, dx), dt, 9.0)
            reach = self.r + 15 + 4          # 15 — радиус игрока
            near = d <= reach

            if self.windup > 0:               # замах → укус
                self.windup -= dt * self.boost
                self.attack = min(1.0, 1.0 - max(0.0, self.windup) / 0.3)
                if self.windup <= 0:
                    self.bite_ready = True
                    self.dmg_cd = 1.0
            else:
                self.attack = max(0.0, self.attack - dt * 4.0)
                if near and self.dmg_cd <= 0 and self.stagger <= 0:
                    self.windup = 0.3
                    self.growl_ready = True

            if not near and self.windup <= 0:
                spd = self.speed * self._slow_factor() * (0.82 + 0.3 * abs(math.sin(self.wob * 0.5)))
                self.x += dx / d * spd * dt
                self.y += dy / d * spd * dt
                self.wob += dt * spd * 0.05
            return d

        # --- не видит игрока ---
        self.windup = 0.0
        self.bite_ready = False
        self.growl_ready = False
        self.attack = max(0.0, self.attack - dt * 4.0)

        if self.state == "chase":     # потерял из виду — идёт туда, где видел
            self.state = "investigate"
            self.investigate = getattr(self, "last_seen", None)
            self.hurry = 0.9
        if self.state == "investigate" and self.investigate is not None:
            ix, iy = self.investigate
            tdist = math.hypot(ix - self.x, iy - self.y)
            wx, wy = self.nav(self, ix, iy) if self.nav else (ix, iy)   # огибает дом, а не упирается в стену
            idx, idy = wx - self.x, wy - self.y
            nd = math.hypot(idx, idy) or 1
            if tdist > 26:
                self._turn(math.atan2(idy, idx), dt, 6.0)
                spd = self.speed * self.hurry * self._slow_factor()
                self.x += idx / nd * spd * dt
                self.y += idy / nd * spd * dt
                self.wob += dt * spd * 0.05
            else:
                self.investigate = None
                self.state = "search"
                self.search = 3.5
            return d

        if self.state == "search":
            self.search -= dt
            self.wob += dt * 0.6
            self.facing += math.sin(self.t * 1.3) * dt * 0.8
            if self.search <= 0:
                self.state = "wander"
                self.wander_wait = random.uniform(0.5, 2.5)
            return d

        # бродит без цели, шаркая
        if self.wander_wait > 0:
            self.wander_wait -= dt
            self.wob += dt * 0.5
            if self.wander_wait <= 0:
                a = random.uniform(0, math.tau)
                ln = random.uniform(80, 280)
                self.wander_to = (self.x + math.cos(a) * ln, self.y + math.sin(a) * ln)
        elif self.wander_to is not None:
            wx, wy = self.wander_to
            wdx, wdy = wx - self.x, wy - self.y
            wd = math.hypot(wdx, wdy) or 1
            if wd < 12:
                self.wander_to = None
                self.wander_wait = random.uniform(1.5, 5.0)
            else:
                self._turn(math.atan2(wdy, wdx), dt, 3.0)
                spd = self.speed * 0.22 * self._slow_factor()
                self.x += wdx / wd * spd * dt
                self.y += wdy / wd * spd * dt
                self.wob += dt * spd * 0.05
        else:
            self.wander_wait = random.uniform(0.5, 2.0)
        self.x = max(30, min(4000 - 30, self.x))
        self.y = max(30, min(4000 - 30, self.y))
        return d

    def take_hit(self, damage, hit_angle, blood_sys, can_dismember=True, is_melee=False,
                 weapon_key="", strength=1.0):
        # Кулдаун защищает только от повторных ударов ближнего боя,
        # иначе дробь тратила бы на зомби только одну дробинку из пяти.
        if is_melee and self.hit_cd > 0: return False
        if is_melee: self.hit_cd = 0.1
        self.last_hit_angle = hit_angle
        self.last_splash_angle = hit_angle
        self.last_weapon = weapon_key
        self.hit_recoil = 0.18
        self.hit_dir = hit_angle
        # шатается и отлетает назад от каждого попадания
        self.stagger = min(1.1, max(self.stagger, 0.35) + 0.12 + min(0.5, damage / 160.0))
        if weapon_key == "chainsaw":
            push = 6.0                                   # пила держит зомби на месте — не отбрасывает
        elif is_melee:
            push = min(150.0, 30.0 + damage * 1.2)
        else:
            push = min(80.0, 12.0 + damage * 0.9)       # пуля чуть толкает, а не швыряет
        push *= (0.55 if self.type == "tank" else 1.0)
        self.kx += math.cos(hit_angle) * push
        self.ky += math.sin(hit_angle) * push

        if damage >= 15:
            if self.jaw == "normal" and random.random() < min(0.35, 0.08 * max(1.0, strength)):
                self.jaw = "broken"
            elif self.jaw == "broken" and random.random() < min(0.30, 0.05 * max(1.0, strength)):
                self.jaw = "gone"
                blood_sys.limbs.append(Limb(self.x, self.y, "jaw", (80, 120, 60), soft=True))

        if not is_melee:
            self.wounds.append({"a": (hit_angle - self.facing) + random.uniform(-0.35, 0.35),
                                "d": random.uniform(self.r * 0.3, self.r * 0.8)})
            if len(self.wounds) > 10:
                self.wounds.pop(0)

        diff = (hit_angle - self.facing) % math.tau
        color = (80, 120, 60) if self.type != "fast" else (150, 120, 60)
        is_headshot = False
        lethal = damage >= self.hp

        if not can_dismember and not is_melee and self.limbs["head"]:
            # пули ничего не отрывают: попал спереди — это просто выстрел в голову
            if diff < math.pi / 3 or diff > math.tau - math.pi / 3:
                is_headshot = True
                damage *= 1.5
        if can_dismember and self.limbs["head"]:
            heavy = self.last_weapon in ("chainsaw", "axe", "machete")
            if heavy and lethal:
                # Тяжёлое оружие отрывает голову даже спереди
                head_cut = random.random() < (0.8 if self.last_weapon == "chainsaw" else 0.55)
            else:
                head_cut = diff < math.pi/3 or diff > math.tau - math.pi/3
            if head_cut:
                is_headshot = True
                damage *= 1.5
                self.limbs["head"] = False
                blood_sys.limbs.append(Limb(self.x, self.y, "head", color, soft=True, angle=hit_angle))
            else:
                if diff < math.pi/4 or diff > math.tau - math.pi/4:
                    if self.limbs["l_arm"]:
                        self.limbs["l_arm"] = False
                        blood_sys.limbs.append(Limb(self.x, self.y, "arm", color, soft=True, angle=hit_angle))
                elif diff < 3*math.pi/4:
                    if self.limbs["l_leg"]:
                        self.limbs["l_leg"] = False
                        blood_sys.limbs.append(Limb(self.x, self.y, "leg", color, soft=True, angle=hit_angle))
                elif diff < 5*math.pi/4:
                    if self.limbs["r_arm"]:
                        self.limbs["r_arm"] = False
                        blood_sys.limbs.append(Limb(self.x, self.y, "arm", color, soft=True, angle=hit_angle))
                else:
                    if self.limbs["r_leg"]:
                        self.limbs["r_leg"] = False
                        blood_sys.limbs.append(Limb(self.x, self.y, "leg", color, soft=True, angle=hit_angle))
                    
        self.hp -= damage
        self.last_dmg = damage
        if self.hp > 0:
            # рана продолжает кровоточить и оставляет кровавый след
            self.bleed_timer = min(10.0, self.bleed_timer + 1.5 + damage * 0.02)
            self.bloody_timer = max(self.bloody_timer, 5.0)
        return is_headshot

    def try_bite(self):
        if self.dmg_cd > 0: return 0
        self.dmg_cd = 1.0
        return self.dmg

    def draw(self, surf, px, py, cam_x, cam_y):
        x, y = self.x - cam_x, self.y - cam_y
        if not (-80 < x < surf.get_width() + 80 and -80 < y < surf.get_height() + 80):
            return

        if self.type == "fast": skin, shirt = (170, 130, 60), (92, 70, 40)
        elif self.type == "tank": skin, shirt = (60, 90, 50), (44, 52, 44)
        else: skin, shirt = (90, 130, 70), (58, 46, 34)
        style = {"skin": skin, "shirt": shirt, "pants": (34, 34, 52)}
        fq = int(round((self.facing % math.tau) / math.tau * 48)) % 48
        wq = int((self.wob * 1.6) % math.tau / math.tau * 12) % 12
        aq = int(self.attack * 4)
        key = (id(self.shape), fq, wq, aq, tuple(self.limbs.values()), self.jaw)
        spr = _SPR_CACHE.get(key)
        if spr is None:
            if len(_SPR_CACHE) > 900:
                _SPR_CACHE.clear()
            spr = render_body(style, self.limbs, self.shape, 0.0, fq / 48 * math.tau,
                              wq / 12 * math.tau, self.r / 14.0, aq / 4.0, jaw=self.jaw)
            _SPR_CACHE[key] = spr
        k = self.hit_recoil / 0.18 if self.hit_recoil > 0 else 0.0
        ox = math.cos(self.hit_dir) * 5.0 * k
        oy = math.sin(self.hit_dir) * 5.0 * k
        # покачивание: при ходьбе — шаткая походка, после попаданий — сильное мотание из стороны в сторону
        st = min(1.0, self.stagger / 0.7)
        walk_sway = math.sin(self.wob * 1.6 + self.sway_seed) * (3.0 + 2.0 * (self.state == "wander"))
        hit_sway = math.sin(self.t * 15.0 + self.sway_seed) * 17.0 * st
        deg = walk_sway + hit_sway
        sx_ = math.cos(self.facing + 1.57) * (math.sin(self.wob * 0.8 + self.sway_seed) * 1.8 +
                                              math.sin(self.t * 13.0) * 3.2 * st)
        sy_ = math.sin(self.facing + 1.57) * (math.sin(self.wob * 0.8 + self.sway_seed) * 1.8 +
                                              math.sin(self.t * 13.0) * 3.2 * st)
        if abs(deg) > 0.5:
            spr = pygame.transform.rotate(spr, deg)
        surf.blit(spr, spr.get_rect(center=(int(x + ox + sx_), int(y + oy + sy_))))
        self._sway_off = (ox + sx_, oy + sy_)

        # следы от пуль
        for w in self.wounds:
            a = self.facing + w["a"]
            wx = x + math.cos(a) * w["d"]
            wy = y + math.sin(a) * w["d"]
            pygame.draw.circle(surf, (126, 8, 10), (int(wx), int(wy)), 3)
            pygame.draw.circle(surf, (28, 0, 0), (int(wx), int(wy)), 1)
            pygame.draw.circle(surf, (176, 34, 32), (int(wx), int(wy)), 3, 1)

        if self.hp < self.max_hp:
            bw = self.r * 2
            pygame.draw.rect(surf, (50, 20, 20), (x - bw / 2, y - self.r - 15, bw, 4))
            pygame.draw.rect(surf, (205, 55, 55), (x - bw / 2, y - self.r - 15, bw * self.hp / self.max_hp, 4))

    def draw_eyes(self, surf, cam_x, cam_y, intensity=1.0):
        """Красные глаза светятся поверх тьмы — зомби видно издалека только по ним."""
        if not self.limbs["head"] or self.hp <= 0:
            return
        x, y = self.x - cam_x, self.y - cam_y
        if not (-40 < x < surf.get_width() + 40 and -40 < y < surf.get_height() + 40):
            return
        ox, oy = getattr(self, "_sway_off", (0, 0))
        sc = self.r / 14.0
        f = self.facing
        fx, fy = math.cos(f), math.sin(f)
        px_, py_ = -fy, fx
        hx = x + ox + fx * 11.5 * sc
        hy = y + oy + fy * 11.5 * sc
        pulse = 0.75 + 0.25 * math.sin(self.t * 5.0 + self.sway_seed)
        a = int(255 * intensity * pulse)
        for side in (-1, 1):
            ex = hx + px_ * 2.7 * sc * side
            ey = hy + py_ * 2.7 * sc * side
            glow = pygame.Surface((14, 14), pygame.SRCALPHA)
            pygame.draw.circle(glow, (255, 30, 10, int(70 * intensity * pulse)), (7, 7), 6)
            pygame.draw.circle(glow, (255, 60, 20, a), (7, 7), 2)
            surf.blit(glow, (int(ex) - 7, int(ey) - 7))
