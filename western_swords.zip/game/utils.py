import math
from .fonts import get as get_font

def clamp(v, a, b):
    return max(a, min(b, v))

def seg_dist(px, py, x1, y1, x2, y2):
    dx, dy = x2 - x1, y2 - y1
    L2 = dx * dx + dy * dy
    if L2 == 0:
        return math.hypot(px - x1, py - y1)
    t = ((px - x1) * dx + (py - y1) * dy) / L2
    t = clamp(t, 0.0, 1.0)
    return math.hypot(px - (x1 + t * dx), py - (y1 + t * dy))

def text(surf, s, size, x, y, color=(255, 255, 255), center=False, shadow=True, right=False):
    font = get_font(size)
    img = font.render(s, True, color)
    rect = img.get_rect()
    
    # Позиционирование
    if right:
        rect.topright = (x, y)
    elif center:
        rect.center = (x, y)
    else:
        rect.topleft = (x, y)
        
    if shadow:
        sh = font.render(s, True, (35, 22, 10))
        surf.blit(sh, rect.move(2, 2))
    surf.blit(img, rect)
    return rect
