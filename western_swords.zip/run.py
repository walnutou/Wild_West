#!/usr/bin/env python3
import os
import sys
import venv
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parent
VENV_DIR = ROOT / ".venv"
MARKER = VENV_DIR / ".installed"

def venv_python():
    return VENV_DIR / ("Scripts/python.exe" if os.name == "nt" else "bin/python")

def setup_venv(py):
    if not py.exists():
        print("[run] Создаю виртуальное окружение...")
        venv.create(VENV_DIR, with_pip=True)
    
    if not MARKER.exists():
        print("[run] Устанавливаю pygame-ce...")
        subprocess.check_call([str(py), "-m", "pip", "install", "--upgrade", "pip"])
        subprocess.check_call([str(py), "-m", "pip", "install", "pygame-ce"])
        MARKER.write_text("ok", encoding="utf-8")

def fix_fonts():
    # Автоматически заменяем шрифт на тот, что есть в Linux
    f = ROOT / "game" / "fonts.py"
    if f.exists():
        txt = f.read_text(encoding="utf-8")
        if '"arial"' in txt:
            txt = txt.replace('"arial"', '"dejavusans,liberationsans,notosans,ubuntu,arial"')
            f.write_text(txt, encoding="utf-8")
            print("[run] Шрифты адаптированы под Linux (квадратики убраны).")

def main():
    in_venv = False
    try:
        in_venv = Path(sys.prefix).resolve() == VENV_DIR.resolve()
    except OSError:
        pass

    if not in_venv:
        py = venv_python()
        setup_venv(py)
        fix_fonts()
        print("[run] Запускаю игру...")
        
        # Принудительно ставим X11 для Hyprland (но не ломаем Windows/Wayland без XWayland)
        env = os.environ.copy()
        if os.name != "nt" and env.get("DISPLAY"):
            env["SDL_VIDEODRIVER"] = "x11"
        env["PYGAME_HIDE_SUPPORT_PROMPT"] = "1"
        
        sys.exit(subprocess.call([str(py), str(Path(__file__).resolve())] + sys.argv[1:], env=env))

    # Мы внутри venv, запускаем игру
    sys.path.insert(0, str(ROOT))
    from game.main import run
    run()
    
if __name__ == "__main__":
    main()