import subprocess, sys, venv, os
from pathlib import Path

ROOT = Path(__file__).resolve().parent
VENV_DIR = ROOT / ".venv"
REQ = ROOT / "requirements.txt"
MARKER = VENV_DIR / ".installed"


def venv_python():
    return VENV_DIR / ("Scripts/python.exe" if os.name == "nt" else "bin/python")


def ensure_venv():
    py = venv_python()
    if not py.exists():
        print(f"[setup] Создаю venv: {VENV_DIR}")
        venv.create(VENV_DIR, with_pip=True)
    return py


def install_deps(py):
    if MARKER.exists():
        return
    subprocess.check_call([str(py), "-m", "pip", "install", "--upgrade", "pip"])
    subprocess.check_call([str(py), "-m", "pip", "install", "-r", str(REQ)])
    MARKER.write_text("ok", encoding="utf-8")


def main():
    py = ensure_venv()
    install_deps(py)
    sys.exit(subprocess.call([str(py), str(ROOT / "run.py")] + sys.argv[1:]))


if __name__ == "__main__":
    main()
