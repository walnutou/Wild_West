from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent
game_path = ROOT / "game" / "game.py"
game_code = game_path.read_text(encoding="utf-8")

# Находим начало функции _bullet_blocked_by_walls и заменяем её до конца файла
pattern = re.compile(r"(    def _bullet_blocked_by_walls\(self, b, px, py\):).*", re.DOTALL)

new_function = '''    def _bullet_blocked_by_walls(self, b, px, py):
        line = ((px, py), (b.x, b.y))
        for bld in self.solid_buildings:
            for op in bld.get("openings", ()):
                if op.get("broken"):
                    continue
                r = pygame.Rect(op["x"], op["y"], op["w"], op["h"])
                hit = r.clipline(line)
                if hit:
                    # Ломаем дверь/окно
                    decor.break_opening(op)
                    kind = "wood" if op["kind"] == "door" else "glass"
                    pt = hit[0]
                    self.blood.add_debris(pt[0], pt[1], kind, 8)
                    self.hit_flashes.append({"x": pt[0], "y": pt[1], "life": 0.1, "max": 0.1})
                    sounds.play(kind, 0.6)
                    
                    # Пуля теряет урон или исчезает
                    if b.is_enemy:
                        if b in self.bullets:
                            self.bullets.remove(b)
                        return True
                    else:
                        b.damage *= 0.5 # Игрок тоже теряет часть урона об стену
                        if b in self.bullets:
                            self.bullets.remove(b)
                        return True
        return False
'''

if pattern.search(game_code):
    game_code = pattern.sub(new_function, game_code)
    game_path.write_text(game_code, encoding="utf-8")
    print("✅ Патч готов! Ошибка SyntaxError в конце game.py исправлена.")
    print("Функция _bullet_blocked_by_walls переписана с нуля.")
    print("Запускай: ./run.py")
else:
    print("❌ Ошибка: не удалось найти функцию _bullet_blocked_by_walls.")